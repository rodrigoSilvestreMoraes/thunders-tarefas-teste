﻿using ErrorOr;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Notifications.GetNotifications;
using VibeBisBff.Application.Usecases.Notifications.GetNotReadNotifications;
using VibeBisBff.Application.Usecases.Notifications.PushNotification;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Notifications;

namespace VibeBisBff.Api.Controllers.V2;

[ApiController]
[RouteWithVersion("notifications", ApiVersions.V2)]
[Authorize]
public class NotificationsController : VertemApiController
{
    private readonly IGetNotificationsUseCase _getNotificationsUseCase;
    private readonly IPushNotificationUseCase _pushNotificationUseCase;
    private readonly IGetNotReadNotificationsUseCase _getNotReadNotificationsUseCase;

    public NotificationsController(IGetNotificationsUseCase getNotificationsUseCase,
        IPushNotificationUseCase pushNotificationUseCase,
        IGetNotReadNotificationsUseCase getNotReadNotificationsUseCase)
    {
        _getNotificationsUseCase = getNotificationsUseCase;
        _pushNotificationUseCase = pushNotificationUseCase;
        _getNotReadNotificationsUseCase = getNotReadNotificationsUseCase;
    }

    /// <summary>
    /// Responsável por listar as notificações in-app do usuário
    /// </summary>
    /// <param name="offset">Quantidade de registros que são pulados na paginação, equivalente ao número da página não calculado</param>
    /// <param name="limit">A quantos registros será limitado o retorno</param>
    /// <returns></returns>
    [HttpGet]
    [ProducesResponseType(typeof(List<NotificationResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult<List<NotificationResponseDto>>> Get([FromQuery] int offset = 0,
        [FromQuery] int limit = 10) =>
        Ok(await _getNotificationsUseCase.Execute(offset, limit));

    /// <summary>
    /// Retorna as notificações não lidas
    /// </summary>
    /// <returns></returns>
    [HttpGet("not-read")]
    [ProducesResponseType(typeof(List<NotificationResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult<List<NotificationResponseDto>>> GetNotRead() =>
        Ok(await _getNotReadNotificationsUseCase.Execute());

    /// <summary>
    /// Marca uma ou mais notificações como lida(s)
    /// </summary>
    /// <param name="ids">Ids das notificações que devem ser marcadas como lidas</param>
    /// <param name="cancellationToken"></param>
    /// <returns>Para qualquer ID informado, retorna NoContent sendo um ID válido ou não de notificação</returns>
    [HttpPost("push")]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult> Push([FromBody] List<string> ids, CancellationToken cancellationToken)
    {
        var result = await _pushNotificationUseCase.Execute(ids, cancellationToken);

        return result.IsError ? Ok(result) : NoContent();
    }
}
