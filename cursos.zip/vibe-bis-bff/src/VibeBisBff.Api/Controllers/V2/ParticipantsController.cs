﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Participants.Login.V2.ResendOtp;
using VibeBisBff.Application.Usecases.Participants.Login.V2.SendOtp;
using VibeBisBff.Application.Usecases.Participants.Login.V2.ValidateOtp;
using VibeBisBff.Application.Usecases.Participants.Register;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Participants.V2.Request;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;
using ParticipantsDto = VibeBisBff.Dto.Participants;

namespace VibeBisBff.Api.Controllers.V2;

[ApiController]
[RouteWithVersion("participants", ApiVersions.V2)]
[Authorize]
public class ParticipantsController : VertemApiController
{
    private readonly ISendOtpLoginUseCase _sendOtpLoginUseCase;
    private readonly IResendOtpLoginUseCase _resendOtpLoginUseCase;
    private readonly IValidateOtpLoginUseCase _validateOtpLoginUseCase;
    private readonly IParticipantsRegisterUseCase _participantsRegisterUseCase;

    public ParticipantsController(
        ISendOtpLoginUseCase sendOtpLoginUseCase,
        IResendOtpLoginUseCase resendOtpLoginUseCase,
        IValidateOtpLoginUseCase validateOtpLoginUseCase,
        IParticipantsRegisterUseCase participantsRegisterUseCase)
    {
        _sendOtpLoginUseCase = sendOtpLoginUseCase;
        _resendOtpLoginUseCase = resendOtpLoginUseCase;
        _validateOtpLoginUseCase = validateOtpLoginUseCase;
        _participantsRegisterUseCase = participantsRegisterUseCase;
    }

    [HttpPost("login")]
    [ProducesResponseType(typeof(ParticipantsDto.SendOtpResponseDto), StatusCodes.Status200OK)]
    [AllowAnonymous]
    public async Task<ActionResult> LoginOtp([FromBody] ParticipantLoginDto participantLoginDto)
    => Ok(await _sendOtpLoginUseCase.Execute(participantLoginDto));

    [HttpPost("login/otp/validate")]
    [ProducesResponseType(typeof(AccessTokenResponseDto), StatusCodes.Status200OK)]
    [AllowAnonymous]
    public async Task<ActionResult> LoginOtpValidate([FromBody] ParticipantLoginOtpDto participantLoginOtpDto)
     => Ok(await _validateOtpLoginUseCase.Execute(participantLoginOtpDto));

    [HttpPost("login/otp/resend")]
    [ProducesResponseType(typeof(ParticipantsDto.SendOtpResponseDto), StatusCodes.Status200OK)]
    [AllowAnonymous]
    public async Task<ActionResult> LoginOtpResend([FromBody] ParticipantLoginDto participantLoginDto)
    => Ok(await _resendOtpLoginUseCase.Execute(participantLoginDto));


    /// <summary>
    ///  Endpoint para o cadastro de novos usuários
    /// </summary>
    /// <param name="participantsRegisterRequestDto">Campos com dados do usuário a ser cadastrado</param>
    /// <param name="ip">Ip do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="device">Nome do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="latitude">Latitude do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="longitude">Longitude do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="language">Linguagem do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="deviceType">Tipo de dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="operationalSystem">Sistema operacional do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="userAgent">Software de origem no dispotivo (app) obrigatoriamente informado para aceite dos termos</param>
    /// <returns>Dados para continuar fluxo de cadastro</returns>
    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<ActionResult<ParticipantsDto.ParticipantRegisterResponseDto>> Register(
        [FromBody] ParticipantsDto.ParticipantsRegisterRequestDto participantsRegisterRequestDto,
        [FromHeader(Name = "Ip")] string ip,
        [FromHeader(Name = "Device")] string device,
        [FromHeader(Name = "Latitude")] string latitude,
        [FromHeader(Name = "Longitude")] string longitude,
        [FromHeader(Name = "Language")] string language,
        [FromHeader(Name = "Device-Type")] string deviceType,
        [FromHeader(Name = "Operational-System")]
        string operationalSystem,
        [FromHeader(Name = "User-Agent")] string userAgent
    )
    {
        var result = await _participantsRegisterUseCase.ExecuteV2(participantsRegisterRequestDto,
            new ParticipantsRegisterRequestHeaderDto
            {
                Device = device,
                Ip = ip,
                UserAgent = userAgent,
                Latitude = latitude,
                Longitude = longitude,
                OperationalSystem = operationalSystem,
                Language = language,
                DeviceType = deviceType
            });

        return Ok(result);
    }


}
