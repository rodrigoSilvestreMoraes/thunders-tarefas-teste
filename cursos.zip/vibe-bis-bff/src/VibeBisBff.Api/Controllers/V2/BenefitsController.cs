﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Dto.Benefit;
using ErrorOr;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Benefits.BenefitRedemption.V2;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Benefit.BenefitRedemption;
using VibeBisBff.Dto.Benefit.V2;
using VibeBisBff.Application.Usecases.Benefits.GetBenefits.V2.GetBenefits;
using VibeBisBff.Application.Usecases.Benefits.GetBenefits.V2.GetBenefitDetail;

namespace VibeBisBff.Api.Controllers.V2;

[RouteWithVersion("benefits", ApiVersions.V2)]
[Authorize]
public class BenefitsController : VertemApiController
{
    private readonly IGetBenefitsUseCaseV2 _getBenefitsUseCase;
    private readonly IGetBenefitDetailUseCase _getBenefitDetailUseCase;
    private readonly IBenefitRedemptionUseCase _benefitRedemptionUseCase;

    public BenefitsController(IGetBenefitsUseCaseV2 getBenefitsUseCase,
        IGetBenefitDetailUseCase getBenefitDetailUseCase,
        IBenefitRedemptionUseCase benefitRedemptionUseCase)
    {
        _getBenefitsUseCase = getBenefitsUseCase;
        _getBenefitDetailUseCase = getBenefitDetailUseCase;
        _benefitRedemptionUseCase = benefitRedemptionUseCase;
    }

    [HttpGet]
    [ProducesResponseType(typeof(BenefitResponseDto[]), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult<ErrorOr<List<BenefitResponseDto>>>> GetBenefits(
        [FromQuery] GetBenefitsRequestDto getBenefitsRequestDto) =>
        Ok(await _getBenefitsUseCase.Execute(getBenefitsRequestDto));

    /// <summary>
    /// Responsável por iniciar o fluxo de resgate de benefícios
    /// </summary>
    /// <param name="benefitRedemptionRequestDto">Dados adicionais necessários para o resgate, atualmente somente o id do fornecedor (vendorId)</param>
    /// <param name="id">ID do benefício que será resgatado</param>
    /// <returns>Quando tiver Has2Fa, devolverá o código OTP e quando não tiver, devolverá o voucher gerado como benefício</returns>
    [ProducesResponseType(typeof(BenefitRedemptionResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(void), StatusCodes.Status429TooManyRequests)]
    [HttpPost("{id}/redemption")]
    public async Task<ActionResult> Redemption([FromBody] BenefitRedemptionRequestDto benefitRedemptionRequestDto,
        [FromRoute] string id)
    {
        var response =
            await _benefitRedemptionUseCase.Execute(benefitRedemptionRequestDto.VendorId.ToString().PadLeft(14, '0'), id);

        return response.Value?.Otp?.IsTooManyRequest ?? false
            ? TooManyRequest(Error.Failure(description: ErrorConstants.TOO_MANY_CODES_REQUESTS))
            : Ok(response);
    }

    [HttpGet("detail/{benefitId}")]
    [ProducesResponseType(typeof(BenefitDetailV2Dto), StatusCodes.Status200OK)]
    public async Task<ActionResult<BenefitDetailV2Dto>> GetDetail([FromRoute] string benefitId, CancellationToken cancellationToken) =>
        Ok(await _getBenefitDetailUseCase.Execute(benefitId, cancellationToken));

}
