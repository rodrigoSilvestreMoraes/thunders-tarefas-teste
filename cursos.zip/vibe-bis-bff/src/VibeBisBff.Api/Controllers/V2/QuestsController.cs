﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Quests;
using VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestsAvailable;
using VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestsAccomplished;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestDetail;
using VibeBisBff.Dto.Quests.V2;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Dto;


namespace VibeBisBff.Api.Controllers.V2;

[ApiController]
[RouteWithVersion("quests", ApiVersions.V2)]
[Authorize]
public class QuestsController : VertemApiController
{
    private readonly IGetQuestsAvailableUseCase _getQuestsV2Usecase;
    private readonly IGetQuestsAccomplishedUseCase _getQuestsAccomplishedUseCase;
    private readonly IGetQuestDetailUseCase _getQuestDetailUseCase;

    public QuestsController(
        IGetQuestsAvailableUseCase getQuestsV2Usecase,
        IGetQuestsAccomplishedUseCase getQuestsAccomplishedUseCase,
        IGetQuestDetailUseCase getQuestDetailUseCase)
    {
        _getQuestsV2Usecase = getQuestsV2Usecase;
        _getQuestsAccomplishedUseCase = getQuestsAccomplishedUseCase;
        _getQuestDetailUseCase = getQuestDetailUseCase;
    }

    [HttpGet("available")]
    [ProducesResponseType(typeof(List<QuestsV2Dto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<QuestsV2Dto>>> GetQuests(
        [FromHeader(Name = Constants.Geolocation.LATITUDE_HEADER)] decimal latitude,
        [FromHeader(Name = Constants.Geolocation.LONGITUDE_HEADER)] decimal longitude,
        [FromHeader(Name = Constants.Geolocation.GRANT_HEADER)] bool geolocationEnable,
        [FromQuery] string name,
        [FromQuery] PagingDataDto pagingData) =>
        Ok(await _getQuestsV2Usecase.Execute(name, pagingData, new GeolocationFilterRequestDto(latitude, longitude, geolocationEnable)));

    [HttpGet("accomplished")]
    [ProducesResponseType(typeof(List<QuestsV2Dto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<QuestsV2Dto>>> GetQuestsAccomplished([FromQuery] PagingDataDto pagingData) =>
        Ok(await _getQuestsAccomplishedUseCase.Execute(pagingData));


    [HttpGet("detail/{questId}")]
    [ProducesResponseType(typeof(QuestDetailV2Dto), StatusCodes.Status200OK)]
    public async Task<ActionResult<QuestDetailV2Dto>> GetDetail([FromRoute] string questId, CancellationToken cancellationToken) =>
        Ok(await _getQuestDetailUseCase.Execute(questId, cancellationToken));
}
