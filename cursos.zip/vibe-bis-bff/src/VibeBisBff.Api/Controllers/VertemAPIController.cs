﻿using System.Diagnostics.CodeAnalysis;
using System.Net;
using ErrorOr;
using Microsoft.AspNetCore.Mvc;

namespace VibeBisBff.Api.Controllers;

record ErrorResponse(int Status, List<Error> Errors);

[ExcludeFromCodeCoverage]
[ApiController]
[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status500InternalServerError)]
[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
[Produces("application/json", new string[] { })]
[Consumes("application/json", new string[] { })]
public class VertemApiController : ControllerBase
{
    private static readonly HttpStatusCode[] SuccessStatusCodes = new[] { HttpStatusCode.OK, HttpStatusCode.Created };

    [NonAction]
    protected ActionResult Created(object? value)
    {
        return Present(value, HttpStatusCode.Created);
    }

    [NonAction]
    protected ActionResult<TValue> Created<TValue>(ErrorOr<TValue> result)
    {
        return PresentWithErrorOr(result, HttpStatusCode.Created);
    }

    [NonAction]
    protected new ActionResult Ok(object? value)
    {
        return Present(value, HttpStatusCode.OK);
    }

    [NonAction]
    protected ActionResult TooManyRequest(object? value)
    {
        return Present(value, HttpStatusCode.TooManyRequests);
    }

    [NonAction]
    protected ActionResult Ok<TValue>(ErrorOr<TValue> result)
    {
        return PresentWithErrorOr(result, HttpStatusCode.OK);
    }

    [NonAction]
    protected ActionResult NotFound<TValue>(ErrorOr<TValue> result)
    {
        return PresentWithErrorOr(result, HttpStatusCode.NotFound);
    }

    [NonAction]
    protected ActionResult NoContent(object? result)
    {
        return Present(result, HttpStatusCode.NoContent);
    }

    [NonAction]
    protected ActionResult<TValue> NoContent<TValue>(ErrorOr<TValue> result)
    {
        return PresentWithErrorOr(result, HttpStatusCode.NoContent);
    }

    [NonAction]
    protected ActionResult GetOkResultWithoutEmptyObjectBody(ErrorOr<Success> result) =>
        result.IsError ? Ok(result) : Ok();

    private ActionResult Present(object? value, HttpStatusCode statusCode)
    {
        switch (value)
        {
            case null:
                return new StatusCodeResult((int)statusCode);
            case IErrorOr errorOr:
                return Present(errorOr, value, statusCode);
            case Error error:
                return PresentWithErrorOr((ErrorOr<Success>)error, statusCode);
        }

        if (statusCode == HttpStatusCode.NoContent)
            return new NoContentResult();

        return new ObjectResult(value) { StatusCode = (int)statusCode };
    }

    private static ActionResult Present(IErrorOr error, object originalResult,
        HttpStatusCode statusCode = HttpStatusCode.UnprocessableEntity)
    {
        if (error == null)
            throw new ArgumentNullException(nameof(error));

        if (error.IsError)
        {
            var finalStatusCode =
                (int)(SuccessStatusCodes.Contains(statusCode) ? HttpStatusCode.UnprocessableEntity : statusCode);

            return new ObjectResult(new ErrorResponse(
                    finalStatusCode,
                    error.Errors
                ))
                { StatusCode = finalStatusCode };
        }

        return new ObjectResult(originalResult) { StatusCode = (int)statusCode };
    }

    private ActionResult PresentWithErrorOr<TValue>(ErrorOr<TValue> result, HttpStatusCode statusCode)
    {
        if (result.IsError)
        {
            return Present(result,
                SuccessStatusCodes.Contains(statusCode) ? HttpStatusCode.UnprocessableEntity : statusCode);
        }

        return Present(result.Value, statusCode);
    }

    protected static string FormatAccessToken(string authorization)
        => authorization.Replace("Bearer ", "");
}
