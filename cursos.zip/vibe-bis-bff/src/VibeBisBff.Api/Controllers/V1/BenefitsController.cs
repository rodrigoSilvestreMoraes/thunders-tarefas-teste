﻿using ErrorOr;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Benefits.BenefitRedemption.V1;
using VibeBisBff.Application.Usecases.Benefits.GetBenefits.V1;
using VibeBisBff.Application.Usecases.Benefits.GetVoucher;
using VibeBisBff.Application.Usecases.Benefits.RedemptionConfirmation;
using VibeBisBff.Application.Usecases.Benefits.ResendRedemptionOtpCode;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Dto.Benefit;
using VibeBisBff.Dto.Benefit.BenefitRedemption;
using VibeBisBff.Dto.Shop;

namespace VibeBisBff.Api.Controllers.V1;

[Authorize]
[ApiController]
[RouteWithVersion("benefits")]
public class BenefitsController : VertemApiController
{
    private readonly IGetBenefitsUseCase _getBenefitsUsecase;
    private readonly IBenefitRedemptionUseCase _benefitRedemptionUseCase;
    private readonly IResendRedemptionOtpCodeUseCase _resendRedemptionOtpCodeUseCase;
    private readonly IBenefitRedemptionConfirmationUseCase _benefitRedemptionConfirmationUseCase;
    private readonly IGetVoucherUseCase _getVoucherUseCase;

    public BenefitsController(IGetBenefitsUseCase getBenefitsUsecase,
        IBenefitRedemptionUseCase benefitRedemptionUseCase,
        IResendRedemptionOtpCodeUseCase resendRedemptionOtpCodeUseCase,
        IBenefitRedemptionConfirmationUseCase benefitRedemptionConfirmationUseCase,
        IGetVoucherUseCase getVoucherUseCase)
    {
        _getBenefitsUsecase = getBenefitsUsecase;
        _benefitRedemptionUseCase = benefitRedemptionUseCase;
        _resendRedemptionOtpCodeUseCase = resendRedemptionOtpCodeUseCase;
        _benefitRedemptionConfirmationUseCase = benefitRedemptionConfirmationUseCase;
        _getVoucherUseCase = getVoucherUseCase;
    }

    /// <summary>
    /// Retorna a listagem de benefícios disponíveis ou resgatados para o usuário
    /// </summary>
    /// <param name="getBenefitsRequestDto"></param>
    /// <returns>Benefícios agrupados por categorias</returns>
    [Obsolete("Utilizar a V2")]
    [HttpGet]
    [ProducesResponseType(typeof(BenefitResponseDto[]), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult<ErrorOr<List<BenefitResponseDto>>>> GetBenefits([FromQuery] GetBenefitsRequestDto getBenefitsRequestDto) =>
        Ok(await _getBenefitsUsecase.Execute(getBenefitsRequestDto));

    /// <summary>
    /// Responsável por iniciar o fluxo de resgate de benefícios
    /// </summary>
    /// <param name="benefitRedemptionRequestDto">Dados adicionais necessários para o resgate, atualmente somente o id do fornecedor (vendorId)</param>
    /// <param name="id">ID do benefício que será resgatado</param>
    /// <param name="authorization"></param>
    /// <returns>pinId para continuidade do 2FA para resgate de benefícios via OTP por SMS</returns>
    [ProducesResponseType(typeof(BenefitRedemptionAndResendCodeResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(void), StatusCodes.Status429TooManyRequests)]
    [HttpPost("{id}/redemption")]
    public async Task<ActionResult> Redemption([FromBody] BenefitRedemptionRequestDto benefitRedemptionRequestDto,
        [FromRoute] string id,
        [FromHeader] string authorization)
    {
        var response = await _benefitRedemptionUseCase.Execute(benefitRedemptionRequestDto, id, FormatAccessToken(authorization));

        if (response.IsError)
            return Ok(response);

        return response.Value.IsTooManyRequest
            ? TooManyRequest(Error.Failure(description: ErrorConstants.TOO_MANY_CODES_REQUESTS))
            : Ok(new BenefitRedemptionAndResendCodeResponseDto(response.Value.OtpId));
    }

    /// <summary>
    /// Responsável pelo reenvio do código OTP para continuidade do fluxo 2FA no resgate de benefícios
    /// </summary>
    /// <returns>Novo pinId</returns>
    [HttpPost("redemption/resend-pin")]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status429TooManyRequests)]
    [ProducesResponseType(typeof(BenefitRedemptionAndResendCodeResponseDto), StatusCodes.Status200OK)]
    public async Task<ActionResult> ResendRedemptionPin()
    {
        var response = await _resendRedemptionOtpCodeUseCase.Execute();

        if (response.IsError)
            return Ok(response);

        return response.Value.IsTooManyRequest
            ? TooManyRequest(Error.Failure(description: ErrorConstants.TOO_MANY_CODES_REQUESTS))
            : Ok(new BenefitRedemptionAndResendCodeResponseDto(response.Value.OtpId));
    }

    /// <summary>
    /// Responsável pela verificação do código OTP recebido pelo usuário para conclusão do fluxo de 2FA e finalização do resgate do benefício
    /// </summary>
    /// <param name="benefitRedemptionPinVerificationRequestDto"></param>
    /// <returns>Voucher do beneficio gerado</returns>
    [HttpPost("redemption/pin-verification")]
    [ProducesResponseType(typeof(VoucherResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult> RedemptionPinVerification([FromBody] BenefitRedemptionPinVerificationRequestDto benefitRedemptionPinVerificationRequestDto) =>
        Ok(await _benefitRedemptionConfirmationUseCase.Execute(benefitRedemptionPinVerificationRequestDto));

    /// <summary>
    ///  Responsável por retornar o voucher correspondente ao benefício resgatado
    /// </summary>
    /// <param name="orderId">ID do pedido de resgate de benefício</param>
    /// <returns>Voucher correspondente ao benefício resgatado</returns>
    [HttpGet("redeemed/{orderId}/voucher")]
    [ProducesResponseType(typeof(VoucherResponseDto), StatusCodes.Status200OK)]
    public async Task<ActionResult<VoucherResponseDto>> GetVoucher([FromRoute] string orderId) =>
        Ok(await _getVoucherUseCase.Execute(orderId));
}
