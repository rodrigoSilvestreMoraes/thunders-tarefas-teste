﻿using ErrorOr;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Banners.GetShowcase;
using VibeBisBff.CrossCuting.Dto.Engagement;

namespace VibeBisBff.Api.Controllers.V1;

[ApiController]
[Authorize]
[RouteWithVersion("banner-showcases")]
public class BannerShowcaseController : VertemApiController
{
    private readonly IGetAvailableShowcaseUseCase _getAvailableShowcaseUseCase;
    public BannerShowcaseController(IGetAvailableShowcaseUseCase getAvailableShowcaseUseCase) => _getAvailableShowcaseUseCase = getAvailableShowcaseUseCase;

    [HttpGet("available")]
    [ProducesResponseType(typeof(List<ShowcaseResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult> GetAllAvailable([FromQuery] string identifier, CancellationToken cancellationToken) =>
        Ok(await _getAvailableShowcaseUseCase.Execute(identifier, cancellationToken));
}
