﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.External.RedeemCredit;
using VibeBisBff.CrossCuting.Dto.External.Request;
using VibeBisBff.CrossCuting.Dto.External.Response;

namespace VibeBisBff.Api.Controllers.V1;

[ApiController]
[RouteWithVersion("external")]
public class ExternalController : VertemApiController
{
    private readonly IRedeemCreditUseCase _redeemCreditUseCase;

    public ExternalController(IRedeemCreditUseCase redeemCreditUseCase) => _redeemCreditUseCase = redeemCreditUseCase;

    [HttpPost("redeem-credit")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(RedeemCreditResponseDto), StatusCodes.Status200OK)]
    public async Task<ActionResult<RedeemCreditResponseDto>> RedeemCredit([FromBody] RedeemCreditRequestDto request,
        CancellationToken cancellationToken) =>
        Ok(await _redeemCreditUseCase.Execute(request, cancellationToken));
}
