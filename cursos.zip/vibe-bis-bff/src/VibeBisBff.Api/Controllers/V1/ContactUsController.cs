﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.ContactUs.Send;
using VibeBisBff.Dto.ContactUs;

namespace VibeBisBff.Api.Controllers.V1;

[RouteWithVersion("contact-us")]
[ApiController]
public class ContactUsController : VertemApiController
{
    private readonly ISendContactUsLoggedOutUserUseCase _sendContactUsLoggedOutUserUseCase;
    private readonly ISendContactUsLoggedUserUseCase _sendContactUsLoggedUserUseCase;

    public ContactUsController(ISendContactUsLoggedOutUserUseCase sendContactUsLoggedOutUserUseCase,
        ISendContactUsLoggedUserUseCase sendContactUsLoggedUserUseCase)
    {
        _sendContactUsLoggedOutUserUseCase = sendContactUsLoggedOutUserUseCase;
        _sendContactUsLoggedUserUseCase = sendContactUsLoggedUserUseCase;
    }

    /// <summary>
    /// Responsável por permitir o fluxo de contato com o suporte para usuários não logados
    /// </summary>
    /// <param name="contactUsLoggedOutUserRequest"></param>
    /// <returns></returns>
    [HttpPost("logged-out-user/send"), Obsolete("O fluxo de suporte por esse endpoint foi descontinuado, deve ser usado diretamente o fluxo pelo ServiceNow"), AllowAnonymous]
    public async Task<IActionResult> Send([FromBody] ContactUsLoggedOutUserRequestDto contactUsLoggedOutUserRequest) =>
        GetOkResultWithoutEmptyObjectBody(await _sendContactUsLoggedOutUserUseCase.Execute(contactUsLoggedOutUserRequest));

    /// <summary>
    /// Responsável por permitir o fluxo de contato com o suporte para usuários não logados
    /// </summary>
    /// <param name="contactUsLoggedUserRequest"></param>
    /// <returns></returns>
    [Authorize]
    [Obsolete("O fluxo de suporte por esse endpoint foi descontinuado, deve ser usado diretamente o fluxo pelo ServiceNow")]
    [HttpPost("logged-user/send")]
    [Consumes("multipart/form-data")]
    public async Task<IActionResult> Send([FromForm] ContactUsLoggedUserRequestDto contactUsLoggedUserRequest) =>
        GetOkResultWithoutEmptyObjectBody(await _sendContactUsLoggedUserUseCase.Execute(contactUsLoggedUserRequest));
}
