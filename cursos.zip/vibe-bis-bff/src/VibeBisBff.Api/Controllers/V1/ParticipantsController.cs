﻿using System.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflow;
using VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflowConfirmNewKeyPin;
using VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflowNewKey;
using VibeBisBff.Application.Usecases.Participants.ChangeParticipantsAddress;
using VibeBisBff.Application.Usecases.Participants.ChangePassword;
using VibeBisBff.Application.Usecases.Participants.Delete;
using VibeBisBff.Application.Usecases.Participants.ForgotPasswordNewPassword;
using VibeBisBff.Application.UseCases.Participants.GetDetails;
using VibeBisBff.Application.Usecases.Participants.GetExtract;
using VibeBisBff.Application.UseCases.Participants.GetUseTerms;
using VibeBisBff.Application.Usecases.Participants.Login;
using VibeBisBff.Application.Usecases.Participants.RefreshToken;
using VibeBisBff.Application.Usecases.Participants.Register;
using VibeBisBff.Application.UseCases.Participants.RegisterConfirmCode;
using VibeBisBff.Application.Usecases.Participants.RegisterResendConfirmationCode;
using VibeBisBff.Application.Usecases.Participants.ValidateChangeKeyWorkflow;
using VibeBisBff.Application.Usecases.Participants.ValidateRegisterKey;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Participants;
using SendOtpResponseDto = VibeBisBff.Dto.Participants.SendOtpResponseDto;
using ErrorOr;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Participants.EmailOtpValidation;
using VibeBisBff.Application.Usecases.Participants.EmailOtpValidationConfirm;
using VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.AddFavoriteVendorCategories;
using VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.GetFavoriteVendorCategoriesIdentificationInfo;
using VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.ListFavoriteVendorCategories;
using VibeBisBff.Application.Usecases.Participants.GetBalance;
using VibeBisBff.Application.Usecases.Participants.UpsertPushNotificationToken;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCuting.Dto.Participants.Response;

namespace VibeBisBff.Api.Controllers.V1;

[ApiController]
[RouteWithVersion("participants")]
[Authorize]
public class ParticipantsController : VertemApiController
{
    private readonly IParticipantsLoginUsecase _participantsLoginUseCase;
    private readonly IRefreshTokenUseCase _refreshTokenUseCase;
    private readonly IParticipantsRegisterUseCase _participantsRegisterUseCase;
    private readonly IGetParticipantsUseTermsUseCase _getParticipantsUseTermsUseCase;
    private readonly IGetParticipantDetailsUseCase _getParticipantDetailsUseCase;
    private readonly IChangeParticipantsAddressUseCase _changeParticipantsAddressUseCase;
    private readonly IParticipantsRegisterConfirmCodeUseCase _registerConfirmCodeUseCase;
    private readonly IUpsertPushNotificationTokenUseCase _upsertPushNotificationTokenUseCase;

    private readonly IParticipantsRegisterResendConfirmationCodeUseCase
        _participantsRegisterResendConfirmationCodeUseCase;

    private readonly IValidateRegisterKeyUseCase _validateRegisterKeyUseCase;
    private readonly IStartChangeKeyWorkflow _startChangeKeyWorkflow;
    private readonly IValidateChangeKeyWorkflow _validateChangeKeyWorkflow;
    private readonly IChangeKeyWorkflowNewKeyUseCase _changeKeyWorkflowNewKeyUseCase;
    private readonly IChangeKeyWorkflowConfirmNewKeyPin _changeKeyWorkflowConfirmNewKeyPin;
    private readonly IChangePasswordUseCase _changePasswordUseCase;
    private readonly IDeleteParticipantUseCase _deleteParticipantUseCase;
    private readonly IGetParticipantExtractUseCase _getParticipantExtractUseCase;
    private readonly IGetParticipantBalanceUseCase _getParticipantBalanceUseCase;
    private readonly IEmailOtpValidationUseCase _emailOtpValidationUseCase;
    private readonly IEmailOtpValidationConfirmUseCase _emailOtpValidationConfirmUseCase;
    private readonly IAddFavoriteVendorCategoriesUseCase _favoriteVendorCategoriesUseCase;
    private readonly IListFavoriteVendorCategoriesUseCase _listFavoriteVendorCategoriesUseCase;

    private readonly IGetFavoriteVendorCategoriesIdentificationInfoUseCase
        _getFavoriteVendorCategoriesIdentificationInfoUseCase;

    public ParticipantsController(
        IParticipantsRegisterUseCase participantsRegisterUseCase,
        IGetParticipantsUseTermsUseCase getParticipantsUseTermsUseCase,
        IGetParticipantDetailsUseCase getParticipantDetailsUseCase,
        IParticipantsRegisterResendConfirmationCodeUseCase participantsRegisterResendConfirmationCodeUseCase,
        IParticipantsLoginUsecase participantsLoginUseCase,
        IRefreshTokenUseCase refreshTokenUseCase,
        IValidateRegisterKeyUseCase validateRegisterKeyUseCase,
        IChangeParticipantsAddressUseCase changeParticipantsAddressUseCase,
        IParticipantsRegisterConfirmCodeUseCase registerConfirmCodeUseCase,
        IStartChangeKeyWorkflow startChangeKeyWorkflow,
        IValidateChangeKeyWorkflow validateChangeKeyWorkflow,
        IForgotPasswordNewPasswordUseCase forgotPasswordNewPasswordUseCase,
        IChangeKeyWorkflowNewKeyUseCase changeKeyWorkflowNewKeyUseCase,
        IChangeKeyWorkflowConfirmNewKeyPin changeKeyWorkflowConfirmNewKeyPin,
        IDeleteParticipantUseCase deleteParticipantUseCase,
        IChangePasswordUseCase changePasswordUseCase,
        IGetParticipantExtractUseCase getParticipantExtractUseCase,
        IUpsertPushNotificationTokenUseCase upsertPushNotificationTokenUseCase,
        IGetParticipantBalanceUseCase getParticipantBalanceUseCase,
        IEmailOtpValidationUseCase emailOtpValidationUseCase,
        IEmailOtpValidationConfirmUseCase emailOtpValidationConfirmUseCase,
        IAddFavoriteVendorCategoriesUseCase favoriteVendorCategoriesUseCase,
        IListFavoriteVendorCategoriesUseCase listFavoriteVendorCategoriesUseCase,
        IGetFavoriteVendorCategoriesIdentificationInfoUseCase getFavoriteVendorCategoriesIdentificationInfoUseCase)
    {
        _participantsLoginUseCase = participantsLoginUseCase;
        _refreshTokenUseCase = refreshTokenUseCase;
        _validateRegisterKeyUseCase = validateRegisterKeyUseCase;
        _participantsRegisterUseCase = participantsRegisterUseCase;
        _getParticipantsUseTermsUseCase = getParticipantsUseTermsUseCase;
        _getParticipantDetailsUseCase = getParticipantDetailsUseCase;
        _changeParticipantsAddressUseCase = changeParticipantsAddressUseCase;
        _startChangeKeyWorkflow = startChangeKeyWorkflow;
        _validateChangeKeyWorkflow = validateChangeKeyWorkflow;
        _changeKeyWorkflowNewKeyUseCase = changeKeyWorkflowNewKeyUseCase;
        _changeKeyWorkflowConfirmNewKeyPin = changeKeyWorkflowConfirmNewKeyPin;
        _changePasswordUseCase = changePasswordUseCase;
        _registerConfirmCodeUseCase = registerConfirmCodeUseCase;
        _participantsRegisterResendConfirmationCodeUseCase = participantsRegisterResendConfirmationCodeUseCase;
        _deleteParticipantUseCase = deleteParticipantUseCase;
        _getParticipantExtractUseCase = getParticipantExtractUseCase;
        _upsertPushNotificationTokenUseCase = upsertPushNotificationTokenUseCase;
        _getParticipantBalanceUseCase = getParticipantBalanceUseCase;

        _emailOtpValidationUseCase = emailOtpValidationUseCase;
        _emailOtpValidationConfirmUseCase = emailOtpValidationConfirmUseCase;
        _favoriteVendorCategoriesUseCase = favoriteVendorCategoriesUseCase;
        _listFavoriteVendorCategoriesUseCase = listFavoriteVendorCategoriesUseCase;
        _getFavoriteVendorCategoriesIdentificationInfoUseCase = getFavoriteVendorCategoriesIdentificationInfoUseCase;
    }

    /// <summary>
    ///  Endpoint para consulta de detalhes do participante logado
    /// </summary>
    /// <returns>Detalhe do participante</returns>
    [Produces("application/json")]
    [ProducesResponseType(typeof(ParticipantDetailDto), StatusCodes.Status200OK)]
    [HttpGet("detail")]
    public async Task<ActionResult<ParticipantDetailDto>> GetDetails()
        => Ok(await _getParticipantDetailsUseCase.Execute());


    /// <summary>
    /// Endpoint para validar a disponibilidade os campos de usuário no cadastro
    /// </summary>
    /// <param name="requestDto"></param>
    /// <response code="409">Conflict - Quando a chave informada não está disponível para uso</response>
    /// <response code="200">Ok - Quando a chave informada está disponível para uso</response>
    [HttpPost("register/validate-key")]
    [Produces("application/json")]
    [AllowAnonymous]
    public async Task<IActionResult> ValidateRegisterKey([FromBody] ValidateKeyRequestDto? requestDto)
    {
        var result = await _validateRegisterKeyUseCase.Execute(requestDto);

        if (result.IsError || result.Value)
            return result.IsError ? Ok(result.IsError) : Ok();

        return Conflict();
    }

    /// <summary>
    /// Endpoint para a consulta do saldo atual em vibes do participante logado
    /// </summary>
    /// <returns></returns>
    [HttpGet("balance")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(decimal), StatusCodes.Status200OK)]
    public async Task<decimal> GetBalance() => await _getParticipantBalanceUseCase.Execute();

    /// <summary>
    ///  Endpoint para o cadastro de novos usuários
    /// </summary>
    /// <param name="participantsRegisterRequestDto">Campos com dados do usuário a ser cadastrado</param>
    /// <param name="ip">Ip do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="device">Nome do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="latitude">Latitude do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="longitude">Longitude do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="language">Linguagem do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="deviceType">Tipo de dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="operationalSystem">Sistema operacional do dispositivo obrigatoriamente informado para aceite dos termos</param>
    /// <param name="userAgent">Software de origem no dispotivo (app) obrigatoriamente informado para aceite dos termos</param>
    /// <returns>Dados para continuar fluxo de cadastro</returns>
    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<ActionResult<ParticipantRegisterResponseDto>> Register(
        [FromBody] ParticipantsRegisterRequestDto participantsRegisterRequestDto,
        [FromHeader(Name = "Ip")] string ip,
        [FromHeader(Name = "Device")] string device,
        [FromHeader(Name = "Latitude")] string latitude,
        [FromHeader(Name = "Longitude")] string longitude,
        [FromHeader(Name = "Language")] string language,
        [FromHeader(Name = "Device-Type")] string deviceType,
        [FromHeader(Name = "Operational-System")]
        string? operationalSystem,
        [FromHeader(Name = "User-Agent")] string userAgent
    )
    {
        var result = await _participantsRegisterUseCase.Execute(participantsRegisterRequestDto,
            new ParticipantsRegisterRequestHeaderDto
            {
                Device = device,
                Ip = ip,
                UserAgent = userAgent,
                Latitude = latitude,
                Longitude = longitude,
                OperationalSystem = operationalSystem,
                Language = language,
                DeviceType = deviceType
            });

        return Ok(result);
    }

    /// <summary>
    ///  Endpoint para consulta dos termos de uso
    /// </summary>
    /// <returns>Dados para continuar fluxo de cadastro</returns>
    [AllowAnonymous]
    [HttpGet("use-terms")]
    public async Task<GetParticipantUseTermsDto> GetUseTerms([FromQuery] ApplicationType appType = ApplicationType.Vibe,
        [FromQuery] string? tenantConfigId = null)
        => await _getParticipantsUseTermsUseCase.Execute(appType, tenantConfigId);

    /// <summary>
    /// Responsável por confirmar o código de telefone enviado por SMS
    /// </summary>
    /// <param name="pinId">Código de identificação do fluxo de OTP por SMS para confirmação do código de telefone. Esse código é gerado no endpoint de cadastro ou reenvio de código</param>
    /// <param name="confirmOptCodeRequestDto"></param>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpPost("register/{pinId}/confirm-code")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<IActionResult> ConfirmRegisterCode([FromRoute] string pinId,
        [FromBody] ConfirmOptCodeRequestDto confirmOptCodeRequestDto)
    {
        await _registerConfirmCodeUseCase.Execute(confirmOptCodeRequestDto, pinId);

        return NoContent();
    }

    /// <summary>
    ///  Responsável pela alteração de endereço do participante
    /// </summary>
    /// <param name="newAddress"></param>
    /// <returns></returns>
    [HttpPost("change-address")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult> ChangeAddress([FromBody] ParticipantAddressDto newAddress)
    {
        var response = await _changeParticipantsAddressUseCase.Execute(newAddress);

        return response.IsError ? Ok(response) : NoContent();
    }

    /// <summary>
    /// Responsável por deletar o participante logado, quando este decide se desvincular do app
    /// </summary>
    [HttpDelete("delete")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task Delete() =>
        await _deleteParticipantUseCase.Execute();

    /// <summary>
    ///  Responsável pela troca de senha do usuário
    /// </summary>
    /// <param name="participantsChangePassword"></param>
    /// <returns></returns>
    [HttpPost("change-password")]
    public async Task<ActionResult> ChangeAddress([FromBody] ParticipantsChangePassword participantsChangePassword)
    {
        var response = await _changePasswordUseCase.Execute(participantsChangePassword);

        return response.IsError ? Ok(response) : NoContent();
    }

    /// <summary>
    /// Responsável por atualizar o token de notificação push do dispositivo do participante
    /// </summary>
    /// <param name="upsertPushNotificationTokenRequestDto"></param>
    /// <returns></returns>
    [HttpPost("push-token")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<IActionResult> UpsertPushNotificationToken(
#pragma warning disable CS1573 // Parameter has no matching param tag in the XML comment (but other parameters do)
        [FromBody] UpsertPushNotificationTokenRequestDto upsertPushNotificationTokenRequestDto,
        CancellationToken cancellationToken)
#pragma warning restore CS1573 // Parameter has no matching param tag in the XML comment (but other parameters do)
    {
        var response =
            await _upsertPushNotificationTokenUseCase.Execute(upsertPushNotificationTokenRequestDto, cancellationToken);

        return response.IsError ? Ok(response) : StatusCode((int)HttpStatusCode.Created);
    }

    /// <summary>
    ///  Responsável por reenviar o código de confirmação de cadastro
    /// </summary>
    /// <param name="digitalAccountId">Identificador do usuário devolvido no endpoint de cadastro</param>
    /// <param name="requestDto"></param>
    /// <returns></returns>
    [AllowAnonymous]
    [ProducesResponseType(typeof(SendOtpResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    [HttpPost("register/{digitalAccountId}/resend-confirmation-code")]
    public async Task<ActionResult<SendOtpResponseDto>> ResendRegisterConfirmationCode(
        [FromRoute] string digitalAccountId, [FromBody] ResendRegisterOtpRequestDto requestDto)
    {
        var result = await _participantsRegisterResendConfirmationCodeUseCase.Execute(digitalAccountId, requestDto);

        return Ok(result);
    }

    /// <summary>
    /// Responsável por iniciar o fluxo de recuperação de senha do participant não logado
    /// </summary>
    /// <param name="forgotPasswordRequestDto"></param>
    [HttpPost("forgot-password")]
    [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    [AllowAnonymous]
    public async Task<ActionResult> ForgotPassword([FromBody] ForgotPasswordRequestDto forgotPasswordRequestDto)
    {
        var response = await _startChangeKeyWorkflow.ExecuteWithParticipantDocument(
            forgotPasswordRequestDto.Username,
            ChangeKeyWorkflowType.ForgotPassword,
            forgotPasswordRequestDto.AppType,
            forgotPasswordRequestDto.TenantConfigId
        );

        return GetActionResultWithPossibleTooManyRequestsResponse(response);
    }


    [HttpPost("forgot-password/new-password")]
    [AllowAnonymous]
    public async Task<ActionResult> ForgotPasswordPinVerification(
        [FromBody] ForgotPasswordPinVerificationRequestDto forgotPasswordPinVerificationRequestDto)
    {
        var response = await _validateChangeKeyWorkflow.Execute(
            forgotPasswordPinVerificationRequestDto.ChangeKeyWorkflowId,
            forgotPasswordPinVerificationRequestDto.Pin,
            forgotPasswordPinVerificationRequestDto.NewPassword,
            forgotPasswordPinVerificationRequestDto.AppType,
            forgotPasswordPinVerificationRequestDto.TenantConfigId
        );

        return response.IsError
            ? Ok(response)
            : NoContent();
    }

    [HttpPost("login")]
    [ProducesResponseType(typeof(AccessTokenResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(NotPhoneValidatedResponseDto), StatusCodes.Status423Locked)]
    [AllowAnonymous]
    public async Task<ActionResult> Login([FromBody] ParticipantsLoginDto participantsLoginRequest)
    {
        var (accessTokenResponseDto, notPhoneValidatedResponseDto) =
            await _participantsLoginUseCase.Execute(participantsLoginRequest);

        return notPhoneValidatedResponseDto is not null
            ? StatusCode(StatusCodes.Status423Locked, notPhoneValidatedResponseDto)
            : Ok(accessTokenResponseDto);
    }

    [AllowAnonymous]
    [HttpPost("refresh-token")]
    public async Task<ActionResult> RefreshToken([FromBody] RefreshTokenRequestDto refreshTokenRequest) =>
        Ok(await _refreshTokenUseCase.Execute(refreshTokenRequest));

    [HttpPost("change-key")]
    public async Task<ActionResult> ChangeKey([FromBody] StartChangeKeyRepositoryDto startChangeKeyRepositoryDto)
    {
        var response = await _startChangeKeyWorkflow.Execute(
            startChangeKeyRepositoryDto.Workflow
        );

        return GetActionResultWithPossibleTooManyRequestsResponse(response);
    }

    [HttpPost("change-key/validate-pin")]
    public async Task<ActionResult> ChangeKeyValidatePin(
        [FromBody] ChangeKeyPinVerificationDto changeKeyPinVerificationDto) =>
        Ok(await _validateChangeKeyWorkflow.Execute(
            changeKeyPinVerificationDto.ChangeKeyWorkflowId,
            changeKeyPinVerificationDto.Pin,
            null
        ));

    [HttpPost("change-key/new-key")]
    public async Task<ActionResult> ChangeKeyNewKey([FromBody] ChangeKeyNewKeyDto changeKeyNewKeyDto)
    {
        var response = await _changeKeyWorkflowNewKeyUseCase.Execute(
            changeKeyNewKeyDto.ChangeKeyWorkflowId,
            changeKeyNewKeyDto.NewKey);

        if (response.IsError)
            return Ok(response);

        return Ok();
    }

    [HttpPost("change-key/validate-new-key")]
    public async Task<ActionResult> ChangeKeyValidateNewKey(
        [FromBody] ChangeKeyValidateNewKeyDto request)
    {
        var response = await _changeKeyWorkflowConfirmNewKeyPin.Execute(request);
        return response.IsError
            ? Ok(response)
            : Ok();
    }

    [HttpGet("extract")]
    [ProducesResponseType(typeof(List<ParticipantExtractResponseDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<ParticipantExtractResponseDto>>> Extract([FromQuery] DateTime? start = null,
        [FromQuery] DateTime? end = null,
        [FromQuery] ParticipantExtractType? type = null) =>
        Ok(await _getParticipantExtractUseCase.Execute(start, end, type));

    [HttpPost("validate-email/otp")]
    public async Task<IActionResult> SendOtpCheckEmail() =>
        Ok(await _emailOtpValidationUseCase.Execute());

    [HttpPost("validate-email/otp/validate")]
    public async Task<IActionResult> ValidateOtpCheckEmail([FromBody] EmailOtpCodeDto emailOtpCodeDto)
    {
        var result = await _emailOtpValidationConfirmUseCase.Execute(emailOtpCodeDto);

        return result.IsError ? Ok(result) : NoContent();
    }

    [HttpPost("categories/favorite")]
    public async Task<IActionResult> SaveFavoriteCategories([FromBody] AddFavoriteVendorCategoryRequestDto requestDto,
        CancellationToken cancellationToken)
    {
        var result = await _favoriteVendorCategoriesUseCase.Execute(requestDto, cancellationToken);

        return result.IsError ? Ok(result) : NoContent();
    }

    [HttpGet("categories/favorite")]
    [ProducesResponseType(typeof(List<FavoriteCategoryDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> ListFavoriteCategories([FromQuery] PagingDataDto pagination,
        CancellationToken cancellationToken)
        => Ok(await _listFavoriteVendorCategoriesUseCase.Execute(pagination, cancellationToken));

    [HttpGet("categories/favorite/identification-info")]
    [ProducesResponseType(typeof(List<CategoryDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<CategoryDto>>> GetFavoriteCategoriesIdentificationInfo(
        CancellationToken cancellationToken) =>
        Ok(await _getFavoriteVendorCategoriesIdentificationInfoUseCase.Execute(cancellationToken));

    private ActionResult GetActionResultWithPossibleTooManyRequestsResponse(ErrorOr<string> response) =>
        response.IsError switch
        {
            true when response.Errors.Any(x => x.Code == "TooManyRequest") => TooManyRequest(
                Error.Failure(description: ErrorConstants.TOO_MANY_CODES_REQUESTS)),
            true => Ok(response),
            _ => Ok(response.Value)
        };
}
