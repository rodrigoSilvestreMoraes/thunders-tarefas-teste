﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Quiz.GetQuizSurvey;
using VibeBisBff.Application.Usecases.Quiz.RegisterQuiz;
using VibeBisBff.CrossCuting.Dto.Quiz;
using VibeBisBff.CrossCuting.Dto.Quiz.Register;
using ErrorOr;

namespace VibeBisBff.Api.Controllers.V1;

[Authorize]
[ApiController]
[RouteWithVersion("quiz")]
public class QuizController : VertemApiController
{
    private readonly IRegisterQuizUseCase _registerQuizUseCase;
    private readonly IGetQuizSurveyUseCase _getQuizUseCase;

    public QuizController(IRegisterQuizUseCase registerQuizUseCase,
        IGetQuizSurveyUseCase getQuizUseCase)
    {
        _getQuizUseCase = getQuizUseCase;
        _registerQuizUseCase = registerQuizUseCase;
    }

    [HttpGet("{id}")]
    [ProducesResponseType(typeof(QuizDetailView), StatusCodes.Status200OK)]
    public async Task<ActionResult<QuizDetailView>> Get([FromRoute] string id, CancellationToken cancellationToken)
    {
        var response = await _getQuizUseCase.Execute(id, cancellationToken);

        if (response.Value == null && !response.IsError)
            return NotFound("Nenhum quiz com o ID informado foi encontrado");

        return Ok(response);
    }

    [HttpPost("register")]
    [ProducesResponseType(typeof(QuizRegisterAnswerResponse), StatusCodes.Status200OK)]
    public async Task<ErrorOr<QuizRegisterAnswerResponse>> Register([FromBody] QuizRegisterAnswerRequest request,
        CancellationToken cancellationToken) =>
        await _registerQuizUseCase.Execute(request, cancellationToken);
}
