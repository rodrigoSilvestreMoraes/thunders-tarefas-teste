﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Application.Usecases.Participants.GetExtract;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Participants;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Participants.GetBalance;
using VibeBisBff.Dto.Wallet;
using VibeBisBff.Application.Usecases.Wallet.GetExpiration;
using VibeBisBff.Dto;
using VibeBisBff.CrossCuting.Dto;

namespace VibeBisBff.Api.Controllers.V1;

[ApiController]
[RouteWithVersion("wallets")]
[Authorize]
public class WalletsController : VertemApiController
{
    private readonly IGetParticipantExtractUseCase _getParticipantExtractUseCase;
    private readonly IGetParticipantBalanceUseCase _getParticipantBalanceUseCase;
    private readonly IGetExpirationUseCase _getExpirationUseCase;

    public WalletsController(
        IGetExpirationUseCase getExpirationUseCase,
        IGetParticipantExtractUseCase getParticipantExtractUseCase,
        IGetParticipantBalanceUseCase getParticipantBalanceUseCase)
    {
        _getExpirationUseCase = getExpirationUseCase;
        _getParticipantExtractUseCase = getParticipantExtractUseCase;
        _getParticipantBalanceUseCase = getParticipantBalanceUseCase;
    }


    /// <summary>
    /// Endpoint para a consulta do saldo atual em vibes do participante logado
    /// </summary>
    /// <returns></returns>
    [HttpGet("balance")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(decimal), StatusCodes.Status200OK)]
    public async Task<decimal> GetBalance() => await _getParticipantBalanceUseCase.Execute();

    [HttpGet("extract")]
    [ProducesResponseType(typeof(List<ParticipantExtractResponseDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<ParticipantExtractResponseDto>>> Extract([FromQuery] DateTime? start = null,
        [FromQuery] DateTime? end = null,
        [FromQuery] ParticipantExtractType? type = null) =>
        Ok(await _getParticipantExtractUseCase.Execute(start, end, type));

    [HttpGet("expiration")]
    [ProducesResponseType(typeof(PagingDataResponseDto<ExtractExpirationPointsResponseDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<PagingDataResponseDto<ExtractExpirationPointsResponseDto>>> GetBalanceExpiring([FromQuery] ExtractExpirationPointsRequestDto request,
       [FromQuery] PagingDataDto pagingDataDto)
        => Ok(await _getExpirationUseCase.Execute(request, pagingDataDto));
}
