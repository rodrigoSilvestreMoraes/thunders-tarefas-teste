﻿using ErrorOr;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Version.GetVersion;
using VibeBisBff.CrossCuting.Dto.Version;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.Api.Controllers.V1;

[ApiController]
[RouteWithVersion("version")]
public class VersionController : VertemApiController
{
    private readonly IGetVersionUseCase _getVersionUseCase;

    public VersionController(IGetVersionUseCase getVersionUseCase) => _getVersionUseCase = getVersionUseCase;

    [HttpGet]
    [AllowAnonymous]
    [ProducesResponseType(typeof(VersionResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult<VersionResponseDto>> GetVersion([FromQuery] ApplicationType? applicationType,
        [FromQuery] string tenantConfigId, CancellationToken cancellationToken)
    {
        var minimumAppVersion = await _getVersionUseCase.Execute(appType: applicationType,
            tenantConfigId: tenantConfigId,
            cancellationToken: cancellationToken);

        if (minimumAppVersion.IsError &&
            minimumAppVersion.Errors.Exists(
                error => error.Code == Constants.ErrorCodes.NO_MINIMUM_APP_VERSION_FOUND))
            return NotFound(minimumAppVersion);

        return Ok(minimumAppVersion);
    }
}
