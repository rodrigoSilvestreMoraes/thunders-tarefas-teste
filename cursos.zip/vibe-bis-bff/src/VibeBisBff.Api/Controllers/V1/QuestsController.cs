﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer.Dto;
using VibeBisBff.Application.Usecases.Quests.AccomplishedQuest;
using VibeBisBff.Application.Usecases.Quests.GetAccomplishedQuestSpending;
using VibeBisBff.Application.Usecases.Quests.GetQuestById;
using VibeBisBff.Application.Usecases.Quests.SendReceipt;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Quests;
using VibeBisBff.Dto.Quests.Webhook;
using VibeBisBff.Application.UseCases.Quests.GetQuests.V1;
using VibeBisBff.Application.Usecases.Quests.GetReceipts;

namespace VibeBisBff.Api.Controllers.V1;

[ApiController]
[RouteWithVersion("quests")]
[Authorize]
public class QuestsController : VertemApiController
{
    private readonly IGetQuestsUsecase _getQuestsUsecase;
    private readonly IAccomplishedQuestUseCase _accomplishedQuestUseCase;
    private readonly ISendReceiptUseCase _sendReceiptUseCase;
    private readonly IGetReceiptsUsecase _getReceiptsUsecase;
    private readonly IGetAccomplishedQuestSpendingUseCase _getAccomplishedQuestSpendingUseCase;
    private readonly IGetQuestByIdUseCase _getQuestByIdUseCase;

    public QuestsController(IGetQuestsUsecase getQuestsUsecase,
        IAccomplishedQuestUseCase accomplishedQuestUseCase,
        ISendReceiptUseCase sendReceiptUseCase,
        IGetReceiptsUsecase getReceiptsUsecase,
        IGetAccomplishedQuestSpendingUseCase getAccomplishedQuestSpendingUseCase,
        IGetQuestByIdUseCase getQuestByIdUseCase)
    {
        _getQuestsUsecase = getQuestsUsecase;
        _accomplishedQuestUseCase = accomplishedQuestUseCase;
        _sendReceiptUseCase = sendReceiptUseCase;
        _getReceiptsUsecase = getReceiptsUsecase;
        _getAccomplishedQuestSpendingUseCase = getAccomplishedQuestSpendingUseCase;
        _getQuestByIdUseCase = getQuestByIdUseCase;
    }

    [HttpGet]
    [ProducesResponseType(typeof(List<QuestsDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<QuestsDto>>> GetQuests([FromQuery] QuestsStatus status) =>
        Ok(await _getQuestsUsecase.Execute(status));

    /// <summary>
    /// Busca uma missão pelo ID
    /// </summary>
    /// <param name="id"></param>
    /// <param name="cancellationToken"></param>
    /// <returns>Missão correspondente ao ID informado</returns>
    [HttpGet("{id}")]
    [ProducesResponseType(typeof(List<QuestsDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<QuestsV2Dto>> GetQuestById([FromRoute] string id, CancellationToken cancellationToken) =>
        Ok(await _getQuestByIdUseCase.Execute(id, cancellationToken));

    /// <summary>
    /// Webhook para receber a notificação de que uma quest foi concluída
    /// </summary>
    /// <param name="accomplishedQuestWebhookRequestDto"></param>
    /// <returns></returns>
    [HttpPost("webhook/accomplished-quest")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> HandleQuestAccomplishedWebhook([FromBody] AccomplishedQuestWebhookRequestDto accomplishedQuestWebhookRequestDto, CancellationToken cancellationToken)
    {
        await _accomplishedQuestUseCase.Execute(accomplishedQuestWebhookRequestDto, cancellationToken);
        return NoContent();
    }

    [HttpGet("accomplished-quest/{questId}/spending")]
    [ProducesResponseType(typeof(AccomplishedQuestSpendingResponseDto), StatusCodes.Status200OK)]
    public async Task<ActionResult<AccomplishedQuestSpendingResponseDto>> AccomplishedQuestSpending([FromRoute] string questId) =>
       Ok(await _getAccomplishedQuestSpendingUseCase.Execute(questId));


    [HttpPost("receipt")]
    public async Task<IActionResult> Receipt([FromBody] SendReceiptRequestDto sendReceiptRequestDto) =>
        Ok(await _sendReceiptUseCase.Execute(sendReceiptRequestDto));

    [Obsolete("O endpoint foi depreciado, mas atende as versões antigas do app. Será desenvolvida uma V2 com paginação corretamente")]
    [HttpGet("receipts/invoice/search")]
    [ProducesResponseType(typeof(ReceiptResponseDto), StatusCodes.Status200OK)]
    public async Task<ActionResult<ReceiptResponseDto>> GetReceipts([FromQuery] int offset = 0, [FromQuery] int limit = 3,
        [FromQuery] DateTime? start = null, [FromQuery] DateTime? end = null) =>
        Ok(await _getReceiptsUsecase.Execute(offset, limit, start, end));
}
