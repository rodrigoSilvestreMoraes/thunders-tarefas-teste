﻿using ErrorOr;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Benefits.BenefitRedemption.V2;
using VibeBisBff.Application.Usecases.Vendors.GetAllVendors;
using VibeBisBff.Application.Usecases.Vendors.GetBannersVendors;
using VibeBisBff.Application.Usecases.Vendors.GetCategories;
using VibeBisBff.Application.Usecases.Vendors.GetShowcaseVendors;
using VibeBisBff.Application.Usecases.Vendors.GetVendorBenefits;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Dto;
using VibeBisBff.Dto.Benefit.BenefitRedemption;
using VibeBisBff.Dto.Vendor.Response;

namespace VibeBisBff.Api.Controllers.V1;

[ApiController]
[Authorize]
[RouteWithVersion("vendors")]
public class VendorController : VertemApiController
{
    private readonly IGetAllVendorsUseCase _getAllVendorsUseCase;
    private readonly IGetVendorsCategoriesUseCase _getVendorsCategoriesUseCase;
    private readonly IGetVendorBenefitsUseCase _getVendorBenefitsUseCase;
    private readonly IGetBannersVendorsUseCase _getBannersVendorsUseCase;
    private readonly IGetShowcaseVendorsUseCase _getShowCaseVendorsUseCase;
    private readonly IBenefitRedemptionUseCase _benefitRedemptionUseCase;

    public VendorController(IGetAllVendorsUseCase getAllVendorsUseCase,
        IGetVendorsCategoriesUseCase getVendorsCategoriesUseCase,
        IGetVendorBenefitsUseCase getVendorBenefitsUseCase,
        IGetBannersVendorsUseCase getBannersVendorsUseCase,
        IGetShowcaseVendorsUseCase getShowCaseVendorsUseCase,
        IBenefitRedemptionUseCase benefitRedemptionUseCase)
    {
        _getAllVendorsUseCase = getAllVendorsUseCase;
        _getVendorsCategoriesUseCase = getVendorsCategoriesUseCase;
        _getVendorBenefitsUseCase = getVendorBenefitsUseCase;
        _getBannersVendorsUseCase = getBannersVendorsUseCase;
        _getShowCaseVendorsUseCase = getShowCaseVendorsUseCase;
        _benefitRedemptionUseCase = benefitRedemptionUseCase;
    }

    [HttpGet("all")]
    [ProducesResponseType(typeof(PagingDataResponseDto<VendorDataDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult> GetAllVendors(
        [FromHeader(Name = Constants.Geolocation.LATITUDE_HEADER)] decimal latitude,
        [FromHeader(Name = Constants.Geolocation.LONGITUDE_HEADER)] decimal longitude,
        [FromHeader(Name = Constants.Geolocation.GRANT_HEADER)] bool geolocationEnable,
        [FromQuery] PagingDataDto pagingData,
        [FromQuery] string name,
        [FromQuery] List<string> categoriesIds,
        CancellationToken cancellationToken) =>
        Ok(await _getAllVendorsUseCase.Execute(pagingData, name, categoriesIds, new GeolocationFilterRequestDto(latitude, longitude, geolocationEnable), cancellationToken));

    [HttpGet("categories")]
    [ProducesResponseType(typeof(List<CategoryDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult> GetCategories(CancellationToken cancellationToken) =>
        Ok(await _getVendorsCategoriesUseCase.Execute(cancellationToken));

    [HttpGet("{id}/benefits")]
    [ProducesResponseType(typeof(List<VendorBenefitDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult> GetBenefitsFromVendor([FromRoute] string id, CancellationToken cancellationToken) =>
        Ok(await _getVendorBenefitsUseCase.Execute(id, cancellationToken));

    [HttpGet("banner")]
    [ProducesResponseType(typeof(List<VendorDataDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult> GetVendorsForBanners(
        [FromHeader(Name = Constants.Geolocation.LATITUDE_HEADER)] decimal latitude,
        [FromHeader(Name = Constants.Geolocation.LONGITUDE_HEADER)] decimal longitude,
        [FromHeader(Name = Constants.Geolocation.GRANT_HEADER)] bool geolocationEnable,
        CancellationToken cancellationToken) =>
        Ok(await _getBannersVendorsUseCase.Execute(new GeolocationFilterRequestDto(latitude, longitude, geolocationEnable), cancellationToken));

    [HttpGet("showcase")]
    [ProducesResponseType(typeof(List<VendorDataDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(List<Error>), StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult> GetVendorsForShowCase(
        [FromHeader(Name = Constants.Geolocation.LATITUDE_HEADER)] decimal latitude,
        [FromHeader(Name = Constants.Geolocation.LONGITUDE_HEADER)] decimal longitude,
        [FromHeader(Name = Constants.Geolocation.GRANT_HEADER)] bool geolocationEnable,
        CancellationToken cancellationToken) =>
        Ok(await _getShowCaseVendorsUseCase.Execute(new GeolocationFilterRequestDto(latitude, longitude, geolocationEnable), cancellationToken));

    /// <summary>
    /// Responsável pelo fluxo de resgate
    /// </summary>
    /// <param name="id">ID do benefício que será resgatado</param>
    /// <param name="vendorId">ID do fornecedor do benefício</param>
    /// <returns>Quando tiver Has2Fa, devolverá o código OTP e quando não tiver, devolverá o voucher gerado como benefício</returns>
    [ProducesResponseType(typeof(BenefitRedemptionResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(void), StatusCodes.Status429TooManyRequests)]
    [HttpPost("{vendorId}/benefits/{id}/redemption")]
    public async Task<ActionResult> Redemption([FromRoute] string id, [FromRoute] string vendorId)
    {
        var response =
            await _benefitRedemptionUseCase.Execute(vendorId, id);

        return response.Value?.Otp?.IsTooManyRequest ?? false
            ? TooManyRequest(Error.Failure(description: ErrorConstants.TOO_MANY_CODES_REQUESTS))
            : Ok(response);
    }
}
