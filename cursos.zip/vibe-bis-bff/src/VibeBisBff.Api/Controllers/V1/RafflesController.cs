﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Application.Usecases.Raffles.GetRaffle;
using VibeBisBff.CrossCuting.Dto.Raffles;
namespace VibeBisBff.Api.Controllers.V1;

[Authorize]
[ApiController]
[RouteWithVersion("raffles")]
public class RafflesController : VertemApiController
{
    private readonly IGetRaffleUseCase _getRaffleUseCase;

    public RafflesController(IGetRaffleUseCase getRaffleUseCase) => _getRaffleUseCase = getRaffleUseCase;

    [HttpGet("active")]
    [ProducesResponseType(typeof(RaffleGroupDto), StatusCodes.Status200OK)]
    public async Task<ActionResult<RaffleGroupDto>> Get() => await _getRaffleUseCase.Execute();
}
