﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VibeBisBff.Api.Infra.Attributes;
using VibeBisBff.Api.Infra.Interceptors;
using VibeBisBff.Application.Usecases.Shop.AddCartItem;
using VibeBisBff.Application.Usecases.Shop.GetCardBrands;
using VibeBisBff.Application.Usecases.Shop.GetInstallments;
using VibeBisBff.Application.Usecases.Shop.GetItems;
using VibeBisBff.Application.Usecases.Shop.GetOrderDetails;
using VibeBisBff.Application.Usecases.Shop.GetOrderPurchaseValue;
using VibeBisBff.Application.Usecases.Shop.GetOrders;
using VibeBisBff.Application.Usecases.Shop.Purchase;
using VibeBisBff.Application.Usecases.Shop.RevisionCartItem;
using VibeBisBff.CrossCuting.Dto.Shop;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;

namespace VibeBisBff.Api.Controllers.V1;

[Authorize]
[ApiController]
[RouteWithVersion("shop")]
public class ShopController : VertemApiController
{
    private readonly IGetShopItemsUseCase _getShopItemsUseCase;
    private readonly IAddCartItemUseCase _addCartItemUseCase;
    private readonly IPurchaseUseCase _purchaseUseCase;
    private readonly IGetOrdersUseCase _getOrdersUseCase;
    private readonly IGetCardBrandsUseCase _getCardBrandsUseCase;
    private readonly IRevisionCartItemUseCase _revisionCartItemUseCase;
    private readonly IGetOrderDetailsUseCase _getOrderDetailsUseCase;
    private readonly IGetOrderPurchaseValueUseCase _getOrderPurchaseValueUseCase;
    private readonly IGetInstallmentsUseCase _getInstallmentsUseCase;

    public ShopController(IGetShopItemsUseCase getShopItemsUseCase,
        IAddCartItemUseCase addCartItemUseCase,
        IRevisionCartItemUseCase revisionCartItemUseCase,
        IGetOrdersUseCase getOrdersUseCase,
        IGetCardBrandsUseCase getCardBrandsUseCase,
        IGetOrderDetailsUseCase getOrderDetailsUseCase,
        IPurchaseUseCase purchaseUseCase,
        IGetOrderPurchaseValueUseCase getOrderPurchaseValueUseCase,
        IGetInstallmentsUseCase getInstallmentsUseCase)
    {
        _getShopItemsUseCase = getShopItemsUseCase;
        _addCartItemUseCase = addCartItemUseCase;
        _revisionCartItemUseCase = revisionCartItemUseCase;
        _getOrdersUseCase = getOrdersUseCase;
        _getCardBrandsUseCase = getCardBrandsUseCase;
        _purchaseUseCase = purchaseUseCase;
        _getOrderDetailsUseCase = getOrderDetailsUseCase;
        _getOrderPurchaseValueUseCase = getOrderPurchaseValueUseCase;
        _getInstallmentsUseCase = getInstallmentsUseCase;
    }

    [HttpGet("card-brands")]
    [ProducesResponseType(typeof(List<CardBrandsResponseDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetCardBrands() =>
        Ok(await _getCardBrandsUseCase.Execute());

    [HttpGet("items")]
    [ProducesResponseType(typeof(List<ShopItemsDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetItems() =>
        Ok(await _getShopItemsUseCase.Execute());

    [HttpPost("cart/add-item")]
    public async Task<IActionResult> AddCartItem([FromBody] AddShopCartItemRequestDto addShopCartItemRequestDto)
    {
        var result = await _addCartItemUseCase.Execute(addShopCartItemRequestDto);
        return result.IsError ? Ok(result) : Ok();
    }

    [HttpGet("cart/revision-purchase")]
    [ProducesResponseType(typeof(List<ProductToRevisionDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult> GetRevisionPurchase() =>
        Ok(await _revisionCartItemUseCase.Execute());

    [HttpPost("cart/purchase")]
    [ProducesResponseType(typeof(long), StatusCodes.Status200OK)]
    [AuditRequestBodyMaskInterceptor]
    public async Task<ActionResult<long>> Purchase([FromBody] CreditCardPaymentRequestDto creditCardPaymentReques) =>
        Ok(await _purchaseUseCase.Execute(creditCardPaymentReques));

    [HttpGet("order/list")]
    [ProducesResponseType(typeof(List<OrderDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<OrderDto>>> GetOrders() =>
        Ok(await _getOrdersUseCase.Execute());

    [HttpGet("order/detail/{parentOrderId}/{vendorOrderId}/{productSkuId}")]
    [ProducesResponseType(typeof(OrderDetailsDto), StatusCodes.Status200OK)]
    public async Task<ActionResult<OrderDetailsDto>> GetOrderDetails([FromRoute] string parentOrderId, [FromRoute] string vendorOrderId, [FromRoute] string productSkuId) =>
      Ok(await _getOrderDetailsUseCase.Execute(parentOrderId, vendorOrderId, productSkuId));

    [HttpGet("cart/purchase-value")]
    [ProducesResponseType(typeof(PurchaseValueResponseDto), StatusCodes.Status200OK)]
    public async Task<ActionResult<PurchaseValueResponseDto>> GetPurchaseValue() =>
        Ok(await _getOrderPurchaseValueUseCase.Execute());

    [HttpGet("cart/installments")]
    [ProducesResponseType(typeof(List<ShopItemInstallmentDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<ShopItemInstallmentDto>>> GetInstallments() =>
        Ok(await _getInstallmentsUseCase.GetInstallments());
}
