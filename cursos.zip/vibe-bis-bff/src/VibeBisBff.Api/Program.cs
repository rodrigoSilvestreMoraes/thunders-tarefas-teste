﻿using Common.Core.Authentication.AspNetCore.Middlewares;
using Vertem.Logs.AspNetCore.DependencyInjection;
using Vertem.WebCommon.Core.Infra.Error;
using VibeBisBff.Api.Infra.Configurations;
using VibeBisBff.Api.Infra.Middlewares;

namespace VibeBisBff.Api;

public class Program
{
    public static async Task Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        builder.Configuration.ConfigureCustomAzureAppConfiguration();
        builder.ConfigureServices();

        var app = builder.Build();

        app.ConfigureVertemLogsHTTP();
        app.AddAuditLoggerMiddleware();
        app.UseMiddleware<ExceptionHandlerMiddleware>();
        app.UseMiddleware<SensitiveErrorExceptionHandler>();
        app.AddExceptionLoggerMiddleware();

        app
            .ConfigurePathBase(builder.Configuration)
            .UseAuthentication()
            .UseRouting()
            .UseCustomSwagger()
            .UseHttpsRedirection();

        app
            .UseAuthorization()
            .UseMiddleware<VertemAuthenticationMiddleware>();

        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
            endpoints.MapHealthChecks("/health");
        });


        await app.RunAsync();
    }
}
