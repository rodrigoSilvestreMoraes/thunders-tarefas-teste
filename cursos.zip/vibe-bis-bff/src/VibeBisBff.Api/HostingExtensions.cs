﻿using System.Text.Json.Serialization;
using Common.Core.Authentication.AspNetCore.Extensions;
using Vertem.WebCommon.Core.Infra.Error;
using VibeBisBff.Api.Infra.Configurations;
using VibeBisBff.IoC.Configuration;
using VibeBisBff.Infra.Cache;

namespace VibeBisBff.Api;

public static class HostingExtensions
{
    public static void ConfigureServices(this WebApplicationBuilder builder)
    {
        ConfigureAuthentication(builder);

        builder.Services.Configure<CookiePolicyOptions>(options =>
        {
            options.CheckConsentNeeded = _ => true;
            options.MinimumSameSitePolicy = SameSiteMode.None;
        });

        builder.Services
            .AddControllers(options => { options.Filters.Add<ErrorOrMvcResultFilter>(); })
            .ConfigureApiBehaviorOptions(options => { options.SuppressMapClientErrors = false; })
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
                options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
            });

        builder.Services
            .AddCustomApp(builder.Configuration)
            .AddCustomMongoDb()
            .AddCustomHealthCheck(builder.Configuration)
            .AddCustomSwagger()
            .AddRedisConfiguration(builder.Configuration)
            .AddVertemLogs(builder.Configuration);
    }

    public static IApplicationBuilder ConfigurePathBase(this IApplicationBuilder app, IConfiguration configuration)
    {
        var pathBase = configuration["HOST_BASE_PATH"];

        if (!string.IsNullOrWhiteSpace(pathBase))
            app.UsePathBase($"{pathBase}");

        return app;
    }

    private static void ConfigureAuthentication(WebApplicationBuilder builder)
    {
        bool.TryParse(builder.Configuration["IsAutomatedTestsEnvironment"], out var isAutomatedTestsEnvironment);

        if (!isAutomatedTestsEnvironment)
            builder.Services.AddVertemAuthentication(
                builder.Configuration["VertemAuthentication:Authority"],
                builder.Configuration["VertemAuthentication:Audience"],
                true);
        else
            builder.Services.AddVertemTestsAuthentication();
    }
}
