﻿using Vertem.Logs.AspNetCore.Attributes;
using Vertem.Logs.Audit.Models;

namespace VibeBisBff.Api.Infra.Interceptors;

public class AuditRequestBodyMaskInterceptorAttribute : AuditInterceptorAttribute
{
    public override void Intercept(AuditLog auditLog)
    {
        auditLog.Request.Body = "**Censurado**";
    }
}
