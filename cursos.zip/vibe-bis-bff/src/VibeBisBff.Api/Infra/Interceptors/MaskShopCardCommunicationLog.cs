﻿using Vertem.Logs.Communication.Interceptors;
using Vertem.Logs.Communication.Models;

namespace VibeBisBff.Api.Infra.Interceptors;

public class MaskShopCardCommunicationLog : CommunicationInterceptor
{
    public override void Intercept(CommunicationLog communicationLog)
    {
        if(ContainsAnyPath(communicationLog, "v1/purchases"))
        {
            communicationLog.Request.Body = "**Censurado**";
        }
    }
}
