﻿using Microsoft.AspNetCore.Mvc;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.Api.Infra.Attributes;

public class RouteWithVersionAttribute : RouteAttribute
{
    public RouteWithVersionAttribute(string template, ApiVersions actionVersion = ApiVersions.V1) : base($"{GetVersionNameByType(actionVersion)}/{template}")
    {}

    private static string GetVersionNameByType(ApiVersions actionVersion) =>
        actionVersion switch
        {
            ApiVersions.V1 => "v1",
            ApiVersions.V2 => "v2",
            _ => "v1"
        };
}
