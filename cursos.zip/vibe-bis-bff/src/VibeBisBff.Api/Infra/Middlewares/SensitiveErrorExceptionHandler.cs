﻿using Common.Core.Exceptions;
using VibeBisBff.CrossCutting.Constants;

namespace VibeBisBff.Api.Infra.Middlewares;

public class SensitiveErrorExceptionHandler
{
    private readonly RequestDelegate _requestDelegate;

    public SensitiveErrorExceptionHandler(RequestDelegate requestDelegate)
    {
        _requestDelegate = requestDelegate;
    }

    public async Task Invoke(HttpContext context)
    {
        try
        {
            await _requestDelegate(context);
        }
        catch (Exception ex)
        {
            if (ex is not BusinessException)
                throw new Exception(ErrorConstants.GENERIC_ERROR);

            throw;
        }
    }
}
