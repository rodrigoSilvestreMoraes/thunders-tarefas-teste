﻿using VibeBisBff.Api.Infra.Swagger;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Diagnostics.CodeAnalysis;
using Vertem.WebCommon.Core.Infra.Swagger;
using WebCommon.Infra.Swagger.SchemaFilters;

namespace VibeBisBff.Api.Infra.Configurations;

[ExcludeFromCodeCoverage]
public static class SwaggerConfiguration
{
    private const string SECURITY_DEFINITION_NAME = "iam";
    public static IServiceCollection AddCustomSwagger(this IServiceCollection services)
    {
        services.AddApiVersioning(options =>
        {
            options.ReportApiVersions = true;
            options.ApiVersionReader = new HeaderApiVersionReader("api-version");
            options.AssumeDefaultVersionWhenUnspecified = true;
            options.DefaultApiVersion = new ApiVersion(1, 0);
        });

        services.AddVersionedApiExplorer(
            options =>
            {
                options.GroupNameFormat = "'v'VVV";
                options.SubstituteApiVersionInUrl = true;

            });

        services.AddSwaggerGen(options =>
        {
            options.CustomOperationIds(e => $"{e.ActionDescriptor.RouteValues["controller"]}_{e.RelativePath}_{e.HttpMethod}");
            options.DescribeAllParametersInCamelCase();
            options.CustomSchemaIdsFullNameOpenApi();
            options.IncludeXmlComments(XmlCommentsFilePath);
            options.SchemaFilter<EnumSchemaFilter>();

            options.SwaggerDoc("VibeDefinition", new OpenApiInfo
            {
                Title = "Vertem.VibeBFF API",
                Description = "API BFF para atender ao App do Vibe",
            });

            options.AddSecurityDefinition(SECURITY_DEFINITION_NAME, new OpenApiSecurityScheme()
            {
                Type = SecuritySchemeType.ApiKey,
                In = ParameterLocation.Header,
                Name = "Authorization",
                Scheme = "Bearer",
                BearerFormat = "JWT",
                Description = "Informe um token JWT do tipo Bearer para autenticação na aplicação",
            });

            options.AddSecurityRequirement(new OpenApiSecurityRequirement()
            {
                {
                    new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference
                        {
                            Type = ReferenceType.SecurityScheme,
                            Id = SECURITY_DEFINITION_NAME
                        }
                    },
                    Array.Empty<string>()
                }
            });
        });

        services.AddTransient<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerOptions>();

        return services;
    }

    public static IApplicationBuilder UseCustomSwagger(this IApplicationBuilder app)
    {
        var host = Environment.GetEnvironmentVariable("HOST");
        var hostBasePath = Environment.GetEnvironmentVariable("HOST_BASE_PATH");
        var hostPort = Environment.GetEnvironmentVariable("HOST_PORT");

        app.UseSwagger(options =>
        {
            if (!string.IsNullOrEmpty(host))
                options.PreSerializeFilters.Add((swagger, httpReq) =>
                {
                    var serverUrl = $"{httpReq.Scheme}://{host}{hostBasePath}";

                    if (!string.IsNullOrEmpty(hostPort))
                        serverUrl = $"{httpReq.Scheme}://{host}:{hostPort}{hostBasePath}";

                    swagger.Servers = new List<OpenApiServer> { new OpenApiServer { Url = serverUrl } };
                });
        });
        app.UseSwaggerUI(c =>
        {
            c.SwaggerEndpoint(
                !string.IsNullOrEmpty(hostBasePath)
                    ? $"{hostBasePath}/swagger/v1/swagger.json"
                    : "/swagger/v1/swagger.json", "v1");
        });

        return app;
    }

    private static string XmlCommentsFilePath
    {
        get
        {
            var programAssembly = typeof(Program).Assembly;
            var basePath = Path.GetDirectoryName(programAssembly.Location);
            var fileName = $"{programAssembly.GetName().Name}.xml";
            return Path.Combine(basePath!, fileName);
        }
    }
}
