﻿using VibeBisBff.Application.Mappers.Engagement;
using VibeBisBff.Application.Mappers.Participant;
using VibeBisBff.Application.Mappers.Quest;
using VibeBisBff.Application.Mappers.Raffle;
using VibeBisBff.Application.Mappers.Receipt;
using VibeBisBff.Application.Mappers.Shop;
using VibeBisBff.Application.Mappers.Tag;
using VibeBisBff.Application.Mappers.Wallets;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Mappers;

namespace VibeBisBff.Api.Infra.Configurations;

public static class AutoMapperConfiguration
{
    public static IServiceCollection AddCustomAutoMapper(this IServiceCollection services)
    {
        services
            .AddAutoMapper(opt =>
            {
                opt.AddProfile<ParticipantProfile>();
                opt.AddProfile<DigitalAccountProfile>();
                opt.AddProfile<ReceiptProfile>();
                opt.AddProfile<ParticipantExtractProfile>();
                opt.AddProfile<ExtractExpirationPointsProfile>();
                opt.AddProfile<BannerShowcaseProfile>();
                opt.AddProfile<QuestProfile>();
                opt.AddProfile<OrderProfile>();
                opt.AddProfile<RaffleProfile>();
                opt.AddProfile<TagProfile>();
            },
            typeof(HostingExtensions));

        return services;
    }
}
