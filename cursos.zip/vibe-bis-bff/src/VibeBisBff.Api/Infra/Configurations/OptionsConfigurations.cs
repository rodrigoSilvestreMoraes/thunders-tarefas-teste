﻿using System.Diagnostics.CodeAnalysis;

using VibeBisBff.CrossCutting.Options;
using VibeBisBff.ExternalServices.Tradeback.Options;
using VibeBisBff.ExternalServices.Tradeback.Promo.Options;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer.Options;
using VibeBisBff.ExternalServices.Tradeback.SpendingBehaviorManagement.Options;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Options;

namespace VibeBisBff.Api.Infra.Configurations;

[ExcludeFromCodeCoverage]
public static class OptionsConfigurations
{
    public static IServiceCollection AddCustomOptions(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<WalletVertemConfigurations>()
            .BindConfiguration("WalletVertem:Configurations");

        services.AddOptions<ADAuthenticationForTradebackOptions>()
            .BindConfiguration("MicrosoftAD");

        services.AddOptions<DigitalAccountAuthenticationOptions>()
            .BindConfiguration("DigitalAccount:Authentication");

        services.AddOptions<ApplicationTypeOptions>()
            .BindConfiguration("ApplicationTypeConfigurations");

        services.AddOptions<VertemIamOptions>()
            .BindConfiguration("VertemIam");

        services.AddOptions<VertemTermsOptions>()
            .BindConfiguration("VertemTerms");

        services.AddOptions<LoginDefaultCredentials>()
            .BindConfiguration("LoginCredential");

        services.AddOptions<VertemMarketplaceOptions>()
            .BindConfiguration("VertemMarketplace").Configure(x =>
            {
                decimal.TryParse(configuration["VertemMarketplace:PercentageInPoints"], out var percentageInPoints);

                x.PercentageInPoints = percentageInPoints;
            });

        services.AddOptions<StorageAccountOptions>()
            .BindConfiguration("StorageAccount");

        services.AddOptions<TradebackPromoOptions>()
            .BindConfiguration("TradebackPromo");

        services.AddOptions<TradebackPromoAdmOptions>()
            .BindConfiguration("TradebackPromoAdm");

        services.AddOptions<TradebackSpendingBehaviorManagementOptions>()
            .BindConfiguration("TradebackParticipantSpendingBehaviorManagement");

        services.AddOptions<TradebackReceiptAuthorizerOptions>()
            .BindConfiguration("TradebackReceiptAuthorizer");

        services.AddOptions<PartnerHubVoucherOptions>()
            .BindConfiguration("PartnerHubVoucher");

        services.AddOptions<VoucherOptions>().Configure(x =>
        {
            int.TryParse(configuration["VoucherOptions:ExpirationDays"], out var expirationDays);

            x.ExpirationDays = expirationDays == 0 ? 7 : expirationDays;
        });

        services.AddOptions<InsiderEventOptions>().BindConfiguration("InsiderEvent");
        services.AddOptions<TradebackAuthorizerV2Options>().BindConfiguration("TradebackAuthorizerV2");
        services.AddOptions<TradebackAuthorizerOptions>().BindConfiguration("TradebackAuthorizer");
        services.AddOptions<TenantConfigOptions>().BindConfiguration("TenantConfig");



        return services;
    }
}
