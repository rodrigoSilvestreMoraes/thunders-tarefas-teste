﻿using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace VibeBisBff.Api.Infra.Configurations;

public static class HealthCheckConfiguration
{
    public static IServiceCollection AddCustomHealthCheck(
        this IServiceCollection services,
        IConfiguration configuration
    )
    {
        services
            .AddHealthChecks()
            .AddMongoDb(
                mongodbConnectionString: configuration["MongoDBConnectionString"]!,
                name: "MongoDB",
                timeout: TimeSpan.FromSeconds(10),
                failureStatus: HealthStatus.Unhealthy
            );

        return services;
    }
}
