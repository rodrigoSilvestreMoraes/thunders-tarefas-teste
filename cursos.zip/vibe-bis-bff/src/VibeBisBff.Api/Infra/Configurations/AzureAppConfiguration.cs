﻿using System.Diagnostics.CodeAnalysis;
using Azure.Core;
using Azure.Identity;
using VibeBisBff.CrossCutting.Constants;

namespace VibeBisBff.Api.Infra.Configurations;

[ExcludeFromCodeCoverage]
public static class AzureAppConfiguration
{
    private const string APP_CONFIGURATION_PREFIX = $"Vertem:{Constants.SERVICE_ID}:";

    public static void ConfigureCustomAzureAppConfiguration(this ConfigurationManager config)
    {
        if (!bool.TryParse(config["UseAzureAppConfigWithKeyVault"], out var result) || !result)
            return;

        config.AddAzureAppConfiguration(options =>
        {
            options
                .Connect(config["AzureAppConfigConnectionString"])
                .ConfigureKeyVault(kv => kv.SetCredential(BuildTokenCredentialForKeyVault(config)))
                .TrimKeyPrefix("APIs:")
                .TrimKeyPrefix(APP_CONFIGURATION_PREFIX)
                .TrimKeyPrefix($"Vertem:VibeCommon:")
                .Select("Vertem:VibeCommon:*")
                .Select($"{APP_CONFIGURATION_PREFIX}*")
                .Select("KeyVaultUrl")
                .Select("APIs:DigitalAccount:*")
                .Select("APIs:VertemTerms:*")
                .Select("APIs:VertemIam:*")
                .Select("StorageAccount:ConnectionString")
                .Select("StorageAccount:VibeContactUsBlobContainer")
                .Select("StorageAccount:ProductImageBaseUrlForBenefits")
                .Select("APIs:MicrosoftAD:*")
                .Select("APIs:TradebackPromo:*")
                .Select("APIs:TradebackPromoAdm:*")
                .Select("APIs:EngagementQuiz:*")
                .Select("APIs:TradebackAuthorizerV2:*")
                .Select("APIs:TradebackAuthorizer:*")
                .Select("APIs:TradebackReceiptAuthorizer:*")
                .Select("APIs:TradebackParticipantSpendingBehaviorManagement:*")
                .Select("APIs:TradebackParticipantSegmentChecker:*")
                .Select("APIs:VertemIam:*")
                .Select("APIs:WalletVertem:*")
                .Select("APIs:VertemMarketplace:*")
                .Select("APIs:VertemNotification:*")
                .Select("ServiceBus:*")
                .Select("APIs:PartnerHubVoucher:*")
                .Select("APIs:InsiderEvent:*")
                .ConfigureRefresh(refresh =>
                {
                    refresh.SetCacheExpiration(TimeSpan.FromMinutes(1));
                    refresh.Register($"{APP_CONFIGURATION_PREFIX}Sentinel", true);
                    refresh.Register("MasterSentinel", true);
                });
        });
    }

    private static TokenCredential BuildTokenCredentialForKeyVault(
        IConfiguration builtConfiguration
    )
    {
        var useWorkloadIdentityCredential = bool.Parse(
            builtConfiguration["UseWorkloadIdentityCredential"]!
        );

        if (!useWorkloadIdentityCredential)
            return new DefaultAzureCredential(new DefaultAzureCredentialOptions
            {
                ExcludeEnvironmentCredential = true,
                ExcludeVisualStudioCredential = true
            });

        return new WorkloadIdentityCredential();
    }
}
