﻿using Azure.Messaging.ServiceBus;
using VibeBisBff.Infra.ServiceBus;

namespace VibeBisBff.Api.Infra.Configurations;

public static class ServiceBusConfiguration
{
    private const string DEFAULT_CONNECTION_STRING_FOR_SWAGGER =
        "Endpoint=sb://foo.servicebus.windows.net/;SharedAccessKeyName=someKeyName;SharedAccessKey=someKeyValue";

    public static void AddCustomServiceBus(this IServiceCollection services, IConfiguration configuration)
    {
        var serviceBusConnectionString = configuration["ServiceBus:Endpoint"] ?? DEFAULT_CONNECTION_STRING_FOR_SWAGGER;

        services.AddSingleton(new ServiceBusClient(serviceBusConnectionString,
            new ServiceBusClientOptions
            {
                TransportType = ServiceBusTransportType.AmqpWebSockets
            }));

        services.AddScoped<IServiceBus, ServiceBus>();
    }
}
