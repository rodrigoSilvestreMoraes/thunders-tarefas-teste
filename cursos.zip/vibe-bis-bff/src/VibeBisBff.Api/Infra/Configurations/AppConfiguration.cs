﻿using System.Diagnostics.CodeAnalysis;
using System.Net;
using FluentValidation;
using Polly;
using Polly.Extensions.Http;
using Vertem.Logs.AspNetCore.DependencyInjection;
using Vertem.Logs.Communication.Interceptors;
using VibeBisBff.Api.Infra.Interceptors;
using VibeBisBff.Application.Notification.Usecases;
using VibeBisBff.Application.Notification.Validations;
using VibeBisBff.Application.Usecases.Banners.GetShowcase;
using VibeBisBff.Application.Usecases.Benefits.BenefitRedemption.V1;
using VibeBisBff.Application.Usecases.Benefits.GetBenefits.V1;
using VibeBisBff.Application.Usecases.Benefits.GetVoucher;
using VibeBisBff.Application.Usecases.Benefits.RedemptionConfirmation;
using VibeBisBff.Application.Usecases.Benefits.ResendRedemptionOtpCode;
using VibeBisBff.Application.Usecases.ContactUs.Send;
using VibeBisBff.Application.Usecases.External.RedeemCredit;
using VibeBisBff.Application.Usecases.Notifications.GetNotifications;
using VibeBisBff.Application.Usecases.Notifications.GetNotReadNotifications;
using VibeBisBff.Application.Usecases.Notifications.PushNotification;
using VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflow;
using VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflowConfirmNewKeyPin;
using VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflowNewKey;
using VibeBisBff.Application.Usecases.Participants.ChangeParticipantsAddress;
using VibeBisBff.Application.Usecases.Participants.ChangePassword;
using VibeBisBff.Application.Usecases.Participants.Delete;
using VibeBisBff.Application.Usecases.Participants.EmailOtpValidation;
using VibeBisBff.Application.Usecases.Participants.EmailOtpValidationConfirm;
using VibeBisBff.Application.Usecases.Participants.ForgotPasswordNewPassword;
using VibeBisBff.Application.Usecases.Participants.GetBalance;
using VibeBisBff.Application.UseCases.Participants.GetDetails;
using VibeBisBff.Application.Usecases.Participants.GetExtract;
using VibeBisBff.Application.UseCases.Participants.GetUseTerms;
using VibeBisBff.Application.Usecases.Participants.Login;
using VibeBisBff.Application.Usecases.Participants.Login.V2.GenerateOtp;
using VibeBisBff.Application.Usecases.Participants.Login.V2.ResendOtp;
using VibeBisBff.Application.Usecases.Participants.Login.V2.SendOtp;
using VibeBisBff.Application.Usecases.Participants.Login.V2.ValidateOtp;
using VibeBisBff.Application.Usecases.Participants.RefreshToken;
using VibeBisBff.Application.Usecases.Participants.Register;
using VibeBisBff.Application.UseCases.Participants.RegisterConfirmCode;
using VibeBisBff.Application.Usecases.Participants.RegisterResendConfirmationCode;
using VibeBisBff.Application.Usecases.Participants.UpsertPushNotificationToken;
using VibeBisBff.Application.Usecases.Participants.ValidateChangeKeyWorkflow;
using VibeBisBff.Application.Usecases.Participants.ValidateRegisterKey;
using VibeBisBff.Application.Usecases.Quests.AccomplishedQuest;
using VibeBisBff.Application.Usecases.Quests.GetAccomplishedQuestSpending;
using VibeBisBff.Application.Usecases.Quests.GetQuestById;
using VibeBisBff.Application.UseCases.Quests.GetQuests.V1;
using VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestsAccomplished;
using VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestsAvailable;
using VibeBisBff.Application.Usecases.Quests.SendReceipt;
using VibeBisBff.Application.Usecases.Quiz.GetQuizSurvey;
using VibeBisBff.Application.Usecases.Quiz.RegisterQuiz;
using VibeBisBff.Application.Usecases.Raffles.GetRaffle;
using VibeBisBff.Application.Usecases.Shop.AddCartItem;
using VibeBisBff.Application.Usecases.Shop.GetCardBrands;
using VibeBisBff.Application.Usecases.Shop.GetInstallments;
using VibeBisBff.Application.Usecases.Shop.GetItems;
using VibeBisBff.Application.Usecases.Shop.GetOrderDetails;
using VibeBisBff.Application.Usecases.Shop.GetOrderPurchaseValue;
using VibeBisBff.Application.Usecases.Shop.GetOrders;
using VibeBisBff.Application.Usecases.Shop.InsertOrder;
using VibeBisBff.Application.Usecases.Shop.Purchase;
using VibeBisBff.Application.Usecases.Shop.RevisionCartItem;
using VibeBisBff.Application.Usecases.Tags.GetTag;
using VibeBisBff.Application.Usecases.Vendors.GetAllVendors;
using VibeBisBff.Application.Usecases.Vendors.GetBannersVendors;
using VibeBisBff.Application.Usecases.Vendors.GetCategories;
using VibeBisBff.Application.Usecases.Vendors.GetShowcaseVendors;
using VibeBisBff.Application.Usecases.Vendors.GetVendorBenefits;
using VibeBisBff.Application.Usecases.Version.GetVersion;
using VibeBisBff.Application.Usecases.Wallet.GetExpiration;
using VibeBisBff.Application.Validations.Benefits;
using VibeBisBff.Application.Validations.ContactUs;
using VibeBisBff.Application.Validations.Paging;
using VibeBisBff.Application.Validations.Participants;
using VibeBisBff.Application.Validations.Quiz;
using VibeBisBff.Application.Validations.Shop;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCuting.Dto.External.Request;
using VibeBisBff.CrossCuting.Dto.Notification;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCuting.Dto.Quiz.Register;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Domain.Entities.Notifications;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.Domain.Repositories.MongoDb.Banners;
using VibeBisBff.Domain.Repositories.MongoDb.Benefit;
using VibeBisBff.Domain.Repositories.MongoDb.Engagement;
using VibeBisBff.Domain.Repositories.MongoDb.PromoCode;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.Domain.Repositories.MongoDb.Raffle;
using VibeBisBff.Domain.Repositories.MongoDb.Shop;
using VibeBisBff.Domain.Repositories.MongoDb.Tag;
using VibeBisBff.Domain.Validations.External;
using VibeBisBff.Domain.Validations.Participant;
using VibeBisBff.Domain.Validations.Wallet;
using VibeBisBff.Dto.Benefit;
using VibeBisBff.Dto.ContactUs;
using VibeBisBff.Dto.Participants;
using VibeBisBff.Dto.Participants.V2.Request;
using VibeBisBff.Dto.Shop;
using VibeBisBff.Dto.Wallet;
using VibeBisBff.ExternalServices.Insider;
using VibeBisBff.ExternalServices.MarketplaceCartItem;
using VibeBisBff.ExternalServices.Microsoft.AD;
using VibeBisBff.ExternalServices.PartnerHub.Voucher;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Tradeback.Authorizer;
using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2;
using VibeBisBff.ExternalServices.Tradeback.ParticipantSegment;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.QuizTransaction;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer;
using VibeBisBff.ExternalServices.Tradeback.SpendingBehaviorManagement;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IamClientCredentials;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Calculator;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Validator;
using VibeBisBff.ExternalServices.Vertem.Terms;
using VibeBisBff.ExternalServices.Vertem.WalletVertem;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Files;
using VibeBisBff.Infra.KeyVault;
using VibeBisBff.Infra.Persistence.MongoDb.Repositories;
using VibeBisBff.Infra.Persistence.MongoDb.Repositories.Banners;
using VibeBisBff.Infra.Persistence.MongoDb.Repositories.Benefit;
using VibeBisBff.Infra.Persistence.MongoDb.Repositories.Engagement;
using VibeBisBff.Infra.Persistence.MongoDb.Repositories.PromoCode;
using VibeBisBff.Infra.Persistence.MongoDb.Repositories.Quest;
using VibeBisBff.Infra.Persistence.MongoDb.Repositories.Raffle;
using VibeBisBff.Infra.Persistence.MongoDb.Repositories.Shop;
using VibeBisBff.Infra.Persistence.MongoDb.Repositories.Tag;
using VibeBisBff.IoC.Configuration;

using VibeBisBff.Infra.Persistence.MongoDb.Repositories.Images;
using VibeBisBff.Domain.Repositories.MongoDb.Images;
using VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestDetail;
using VibeBisBff.Application.Usecases.Benefits.GetBenefits.V2.GetBenefits;
using VibeBisBff.Application.Usecases.Benefits.GetBenefits.V2.GetBenefitDetail;
using VibeBisBff.Application.Usecases.Offers.GetOfferDetail;
using VibeBisBff.Application.Usecases.Offers.GenerateRules;

using VibeBisBff.Domain.Repositories.MongoDb.FavoriteVendor;
using VibeBisBff.Infra.Persistence.MongoDb.Repositories.FavoriteVendor;
using VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.AddFavoriteVendorCategories;
using VibeBisBff.Application.Usecases.Banners.GetShowcaseByListExternalId;
using VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.GetFavoriteVendorCategoriesIdentificationInfo;
using VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.ListFavoriteVendorCategories;
using VibeBisBff.Application.Usecases.Quests.GetReceipts;
using VibeBisBff.ExternalServices.Tradeback.Promo.Adm;


namespace VibeBisBff.Api.Infra.Configurations;

[ExcludeFromCodeCoverage]
public static class AppConfiguration
{
    public static IServiceCollection AddCustomApp(this IServiceCollection services, IConfiguration configuration)
    {
        services
            .AddInfraDependencies(configuration)
            .AddDatabaseRepositoryDependencies()
            .AddBannerShowcaseDependencies()
            .AddCustomAutoMapper()
            .AddCustomOptions(configuration)
            .AddTagsDependencies()
            .AddTenantDependencies()
            .AddBenefitDependencies()
            .AddParticipantsDependencies()
            .AddParticipantsV2Dependencies()
            .AddWalletDependencies()
            .AddLuckyNumbersDependencies()
            .AddVendorsDependencies()
            .AddValidations()
            .AddQuestsDependencies()
            .AddQuizDependencies()
            .AddBannerDependencies()
            .AddShopDependencies()
            .AddContactUsDependencies()
            .AddNotification(configuration)
            .AddNotificationDependencies()
            .AddVersionDependencies()
            .AddAppExternalDependencies()
            .AddOfferDependencies()
            .AddParticipantFavoriteCategories()
            .AddExternalServicesDependencies(configuration);

        services.AddScoped<IAddMarketplaceCartItem, AddMarketplaceCartItem>();

        return services;
    }

    private static IServiceCollection AddQuestsDependencies(this IServiceCollection services)
    {
        services.AddScoped<IGetQuestsUsecase, GetQuestsUsecase>();
        services.AddScoped<IGetQuestsAvailableUseCase, GetQuestsAvailableUseCase>();
        services.AddScoped<IGetQuestsAccomplishedUseCase, GetQuestsAccomplishedUseCase>();
        services.AddScoped<IGetQuestByIdUseCase, GetQuestByIdUseCase>();
        services.AddScoped<IAccomplishedQuestUseCase, AccomplishedQuestUseCase>();
        services.AddScoped<ISendReceiptUseCase, SendReceiptUseCase>();
        services.AddScoped<IGetReceiptsUsecase, GetReceiptsUsecase>();
        services.AddScoped<IGetAccomplishedQuestSpendingUseCase, GetAccomplishedQuestSpendingUseCase>();
        services.AddScoped<IGetQuestDetailUseCase, GetQuestDetailUseCase>();
        services.AddScoped<IAccomplishedQuestsRepository, AccomplishedQuestsRepository>();
        services.AddScoped<IImageAppRepository, ImageAppRepository>();

        return services;
    }

    private static IServiceCollection AddOfferDependencies(this IServiceCollection services)
    {
        services.AddScoped<IGetOfferDetailUseCase, GetOfferDetailUseCase>();
        services.AddScoped<IGenerateRulesUseCase, GenerateRulesUseCase>();

        return services;
    }

    private static IServiceCollection AddTagsDependencies(this IServiceCollection services)
    {
        services.AddScoped<ITagRepository, TagRepository>();
        services.AddScoped<IGetTagUseCase, GetTagUseCase>();

        return services;
    }    

    private static IServiceCollection AddQuizDependencies(this IServiceCollection services)
    {
        services.AddScoped<IValidator<QuizRegisterAnswerRequest>, QuizRegisterValidation>();

        services.AddScoped<IGetQuizSurveyUseCase, GetQuizSurveyUseCase>();
        services.AddScoped<IRegisterQuizUseCase, RegisterQuizUseCase>();

        return services;
    }

    private static IServiceCollection AddBannerShowcaseDependencies(this IServiceCollection services)
    {
        services.AddScoped<IGetAvailableShowcaseUseCase, GetAvailableShowcaseUseCase>();
        services.AddScoped<IGetShowcaseByListExternalIdUseCase, GetShowcaseByListExternalIdUseCase>();
        services.AddScoped<IBannerShowcaseRepository, BannerShowcaseRepository>();
        return services;
    }

    private static IServiceCollection AddValidations(this IServiceCollection services)
    {
        services.AddScoped<IValidator<PagingDataDto>, PagingDataValidation>();
        services.AddScoped<IValidator<ParticipantLoginDto>, ParticipantLoginDtoValidation>();
        services.AddScoped<IValidator<ParticipantLoginOtpDto>, ParticipantLoginOtpDtoValidation>();

        return services;
    }

    private static IServiceCollection AddBannerDependencies(this IServiceCollection services)
    {
        services.AddScoped<IBannerRepository, BannerRepository>();
        return services;
    }

    private static IServiceCollection AddNotificationDependencies(this IServiceCollection services)
    {
        services.AddScoped<IGetNotificationsUseCase, GetNotificationsUseCase>();
        services.AddScoped<IPushNotificationUseCase, PushNotificationUseCase>();
        services.AddScoped<IGetNotReadNotificationsUseCase, GetNotReadNotificationsUseCase>();

        services.AddScoped<INotificationUseCase, NotificationUseCase>();

        services.AddScoped<IValidator<NotificationPush>, NotificationPushValidation>();
        services.AddScoped<IValidator<NotificationEmail>, NotificationEmailValidation>();
        services.AddScoped<IValidator<NotificationRequestDto>, NotificationRequestDtoValidation>();

        return services;
    }

    private static IServiceCollection AddTenantDependencies(this IServiceCollection services)
    {
        services.AddScoped<ITenantConfigRepository, TenantConfigRepository>();
        services.AddScoped<ITenantService, TenantService>();

        return services;
    }

    private static IServiceCollection AddVendorsDependencies(this IServiceCollection services)
    {
        services.AddScoped<IGetAllVendorsUseCase, GetAllVendorsUseCase>();
        services.AddScoped<IGetVendorBenefitsUseCase, GetVendorBenefitsUseCase>();
        services.AddScoped<IGetVendorsCategoriesUseCase, GetVendorsCategoriesUseCase>();
        services.AddScoped<IGetBannersVendorsUseCase, GetBannersVendorsUseCase>();
        services.AddScoped<IGetShowcaseVendorsUseCase, GetShowCaseVendorsUseCase>();

        return services;
    }

    private static IServiceCollection AddLuckyNumbersDependencies(this IServiceCollection serviceCollection)
    {
        serviceCollection.AddScoped<IDistributedPromoCodeRepository, DistributedPromoCodeRepository>();

        return serviceCollection;
    }

    private static IServiceCollection AddShopDependencies(this IServiceCollection services)
    {
        services.AddScoped<IGetShopItemsUseCase, GetShopItemsUseCase>();
        services.AddScoped<IAddCartItemUseCase, AddCartItemUseCase>();
        services.AddScoped<IRevisionCartItemUseCase, RevisionCartItemUseCase>();
        services.AddScoped<IGetOrdersUseCase, GetOrdersUseCase>();
        services.AddScoped<IGetCardBrandsUseCase, GetCardBrandsUseCase>();
        services.AddScoped<IPurchaseUseCase, PurchaseUseCase>();
        services.AddScoped<IGetOrderDetailsUseCase, GetOrderDetailsUseCase>();
        services.AddScoped<IGetOrderPurchaseValueUseCase, GetOrderPurchaseValueUseCase>();
        services.AddScoped<IGetInstallmentsUseCase, GetInstallmentsUseCase>();
        services.AddScoped<IGetVoucherUseCase, GetVoucherUseCase>();
        services.AddScoped<IInsertOrderUseCase, InsertOrderUseCase>();

        services.AddScoped<IPurchaseValueCalculator, PurchaseValueCalculator>();

        services.AddScoped<IValidator<CreditCardPaymentRequestDto>, CreditCardPaymentRequestValidation>();
        services.AddScoped<IValidator<ShippingTrackingRequestDto>, ShippingTrackingRequestValidation>();

        services.AddScoped<IOrderRepository, OrderRepository>();
        services.AddScoped<IRaffleRepository, RaffleRepository>();

        services.AddScoped<IGetRaffleUseCase, GetRaffleUseCase>();

        return services;
    }    

    private static IServiceCollection AddInfraDependencies(this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddHttpContextAccessor();

        services.AddMemoryCache();

        services.AddScoped(provider =>
        {
            var httpContext = provider.GetService<IHttpContextAccessor>().HttpContext;
            return new AuthTokenAccessor(httpContext!.Request.Headers.Authorization);
        });

        services.AddKeyVaultClientManager(configuration);

        services.AddScoped<IUploaderFile, UploaderFile>();

        services.AddCustomServiceBus(configuration);

        return services;
    }

    private static IServiceCollection AddBenefitDependencies(this IServiceCollection services)
    {
        services.AddScoped<IGetBenefitDetailUseCase, GetBenefitDetailUseCase>();
        services.AddScoped<IGetBenefitsUseCase, GetBenefitsUseCase>();
        services.AddScoped<IGetBenefitsUseCaseV2, GetBenefitsUseCaseV2>();
        services.AddScoped<IBenefitRedemptionUseCase, BenefitRedemptionUseCase>();
        services
            .AddScoped<Application.Usecases.Benefits.BenefitRedemption.V2.IBenefitRedemptionUseCase,
                Application.Usecases.Benefits.BenefitRedemption.V2.BenefitRedemptionUseCase>();

        services.AddScoped<IBenefitRedemptionUseCase, BenefitRedemptionUseCase>();
        services
            .AddScoped<Application.Usecases.Benefits.BenefitRedemption.V2.IBenefitRedemptionUseCase,
                Application.Usecases.Benefits.BenefitRedemption.V2.BenefitRedemptionUseCase>();

        services.AddScoped<IBenefitRedemptionConfirmationUseCase, BenefitRedemptionConfirmationUseCase>();
        services.AddScoped<IResendRedemptionOtpCodeUseCase, ResendRedemptionOtpCodeUseCase>();

        services.AddScoped<IAccomplishedBenefitsRepository, AccomplishedBenefitsRepository>();
        services.AddScoped<IValidator<GetBenefitsRequestDto>, GetBenefitsRequestValidation>();
        return services;
    }

    private static IServiceCollection AddParticipantsV2Dependencies(this IServiceCollection services)
    {
        services.AddScoped<ISendOtpLoginUseCase, SendOtpLoginUseCase>();
        services.AddScoped<IResendOtpLoginUseCase, ResendOtpLoginUseCase>();
        services.AddScoped<IGenerateOtpUseCase, GenerateOtpUseCase>();
        services.AddScoped<IValidateOtpLoginUseCase, ValidateOtpLoginUseCase>();

        return services;
    }

    private static IServiceCollection AddParticipantsDependencies(this IServiceCollection services)
    {
        services.AddScoped<IParticipantsRegisterUseCase, ParticipantsRegisterUseCase>();
        services.AddScoped<IGetParticipantsUseTermsUseCase, GetParticipantsUseTermsUseCase>();
        services.AddScoped<IGetParticipantDetailsUseCase, GetParticipantDetailsUseCase>();
        services.AddScoped<IChangeParticipantsAddressUseCase, ChangeParticipantsAddressUseCase>();
        services.AddScoped<IParticipantsRegisterConfirmCodeUseCase, ParticipantsRegisterConfirmCodeUseCase>();
        services
            .AddScoped<IParticipantsRegisterResendConfirmationCodeUseCase,
                ParticipantsRegisterResendConfirmationCodeUseCase>();
        services.AddScoped<IParticipantsLoginUsecase, ParticipantsLoginUsecase>();
        services.AddScoped<IRefreshTokenUseCase, RefreshTokenUseCase>();
        services.AddScoped<IValidateRegisterKeyUseCase, ValidateRegisterKeyUseCase>();
        services.AddScoped<IValidateChangeKeyWorkflow, ValidateChangeKeyWorkflow>();
        services.AddScoped<IStartChangeKeyWorkflow, StartChangeKeyWorkflow>();
        services.AddScoped<IForgotPasswordNewPasswordUseCase, ForgotPasswordNewPasswordUseCase>();
        services.AddScoped<IChangeKeyWorkflowNewKeyUseCase, ChangeKeyWorkflowNewKeyUseCase>();
        services.AddScoped<IChangeKeyWorkflowConfirmNewKeyPin, ChangeKeyWorkflowConfirmNewKeyPin>();
        services.AddScoped<IChangePasswordUseCase, ChangePasswordUseCase>();
        services.AddScoped<IGetParticipantExtractUseCase, GetParticipantExtractUseCase>();
        services.AddScoped<IUpsertPushNotificationTokenUseCase, UpsertPushNotificationTokenUseCase>();
        services.AddScoped<IGetParticipantBalanceUseCase, GetParticipantBalanceUseCase>();

        services.AddScoped<IChangeKeyWorkflowRepository, ChangeKeyWorkflowRepository>();
        services.AddScoped<IDeleteParticipantUseCase, DeleteParticipantUseCase>();

        services.AddScoped<IEmailOtpValidationUseCase, EmailOtpValidationUseCase>();
        services.AddScoped<IEmailOtpValidationConfirmUseCase, EmailOtpValidationConfirmUseCase>();

        services.AddScoped<IValidator<ValidateKeyRequestDto>, ValidateKeyRequestValidation>();
        services.AddScoped<IValidator<ParticipantsRegisterRequestDto>, ParticipantsRegisterRequestValidation>();

        services
            .AddScoped<IValidator<ParticipantsRegisterRequestHeaderDto>, ParticipantsRegisterRequestHeaderValidation>();
        services.AddScoped<IValidator<ResendRegisterOtpRequestDto>, ResendRegisterOtpRequestValidation>();
        services.AddScoped<IValidator<ParticipantsLoginDto>, ParticipantsLoginDtoValidator>();
        services
            .AddScoped<IValidator<UpsertPushNotificationTokenRequestDto>,
                UpsertPushNotificationTokenRequestDtoValidation>();

        services.AddScoped<IAddFavoriteVendorCategoriesUseCase, AddFavoriteVendorCategoriesUseCase>();
        services.AddScoped<IListFavoriteVendorCategoriesUseCase, ListFavoriteVendorCategoriesUseCase>();
        services
            .AddScoped<IGetFavoriteVendorCategoriesIdentificationInfoUseCase,
                GetFavoriteVendorCategoriesIdentificationInfoUseCase>();

        return services;
    }

    private static IServiceCollection AddWalletDependencies(this IServiceCollection services)
    {
        services.AddScoped<IGetExpirationUseCase, GetExpirationUseCase>();

        services.AddScoped<IValidator<ExtractExpirationPointsRequestDto>, ExtractExpirationPointsRequestValidation>();
        services.AddScoped<IValidator<PagingDataDto>, PagingDataValidation>();

        return services;
    }

    private static IServiceCollection AddContactUsDependencies(this IServiceCollection services)
    {
        services.AddScoped<ISendContactUsLoggedUserUseCase, SendContactUsLoggedUserUseCase>();
        services.AddScoped<ISendContactUsLoggedOutUserUseCase, SendContactUsLoggedOutUserUseCase>();

        services.AddScoped<IContactUsRepository, ContactUsRepository>();

        services.AddScoped<IValidator<ContactUsLoggedOutUserRequestDto>, ContactUsLoggedOutUserRequestDtoValidation>();
        services.AddScoped<IValidator<ContactUsLoggedUserRequestDto>, ContactUsLoggedUserRequestDtoValidation>();

        return services;
    }

    private static IServiceCollection AddVersionDependencies(this IServiceCollection services)
    {
        services.AddScoped<IGetVersionUseCase, GetVersionUseCase>();

        return services;
    }

    private static IServiceCollection AddAppExternalDependencies(this IServiceCollection serviceCollection)
    {
        serviceCollection.AddScoped<IRedeemCreditUseCase, RedeemCreditUseCase>();

        serviceCollection.AddScoped<IValidator<RedeemCreditRequestDto>, RedeemCreditRequestValidation>();

        return serviceCollection;
    }

    private static IServiceCollection AddParticipantFavoriteCategories(this IServiceCollection serviceCollection)
    {
        serviceCollection.AddScoped<IFavoriteVendorCategoriesRepository, FavoriteVendorCategoriesRepository>();

        serviceCollection
            .AddScoped<IValidator<AddFavoriteVendorCategoryRequestDto>, AddFavoriteCategoryRequestValidation>();
        return serviceCollection;
    }

    private static void AddExternalServicesDependencies(this IServiceCollection services,
        IConfiguration configuration)
    {
        services
            .AddHttpClient<ITradebackPromoExternalService, TradebackPromoExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["TradebackPromo:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services
            .AddHttpClient<ITradebackPromoAdmExternalService, TradebackPromoAdmExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["TradebackPromoAdm:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services
            .AddHttpClient<IMicrosoftADExternalServices, MicrosoftADExternalServices>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["MicrosoftAD:BaseUrl"]!);
            })
            .AddCommunicationHandler(false)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services
            .AddHttpClient<IWalletVertemExternalService, WalletVertemExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["WalletVertem:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services
            .AddHttpClient<IIdentityAccessManagementExternalService, IdentityAccessManagementExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["VertemIam:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services
            .AddHttpClient<IVertemIamTenantService, VertemIamTenantService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["VertemIam:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services.AddHttpClient<IDigitalAccountExternalService, DigitalAccountExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["DigitalAccount:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services.AddHttpClient<ITermsExternalService, TermsExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["VertemTerms:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services.AddHttpClient<ExternalFileDownloader>()
            .AddCommunicationHandler(false)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services.AddHttpClient<IVertemMarketplaceExternalService, VertemMarketplaceExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["VertemMarketplace:BaseUrl"]!);
            })
            .AddCommunicationHandler(true, new List<CommunicationInterceptor>
            {
                new MaskShopCardCommunicationLog()
            })
            .AddPolicyHandler(_ => GetRetryPolicy(policyBuilder =>
                policyBuilder
                    .OrResult(x => x.StatusCode is HttpStatusCode.BadRequest or HttpStatusCode.UnprocessableEntity)
            ));

        services.AddHttpClient<IReceiptAuthorizerExternalService, ReceiptAuthorizerExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["TradebackReceiptAuthorizer:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services
            .AddHttpClient<ITradebackSpendingBehaviorManagementExternalService,
                TradebackSpendingBehaviorManagementExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["TradebackParticipantSpendingBehaviorManagement:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services.AddHttpClient<IVoucherHubExternalService, VoucherHubExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["PartnerHubVoucher:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services.AddHttpClient<IInsiderExternalService, InsiderExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["InsiderEvent:BaseUrl"]!);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services.AddHttpClient<ITradebackAuthorizerV2ExternalService, TradebackAuthorizerV2ExternalService>(opt =>
        {
            opt.BaseAddress = new Uri(configuration["TradebackAuthorizerV2:BaseUrl"]!);
        }).AddCommunicationHandler(true);

        services.AddHttpClient<IQuizTransactionExternalService, QuizTransactionExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["EngagementQuiz:BaseUrl"]!);
                opt.DefaultRequestHeaders.Add(Constants.Auth.SUBSCRIPTION_KEY,
                    configuration["EngagementQuiz:SubscriptionKey"]);
            })
            .AddCommunicationHandler(true)
            .AddPolicyHandler(_ => GetRetryPolicy());

        services.AddHttpClient<ITradebackAuthorizerExternalService, TradebackAuthorizerExternalService>(opt =>
            {
                opt.BaseAddress = new Uri(configuration["TradebackAuthorizer:BaseUrl"]!);
            })
            .AddCommunicationHandler(true);

        services.AddHttpClient<ITradebackParticipantSegmentExternalService, TradebackParticipantSegmentExternalService>(
                opt => { opt.BaseAddress = new Uri(configuration["TradebackParticipantSegmentChecker:BaseUrl"]!); })
            .AddCommunicationHandler(true);
    }

    private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy(
        Func<PolicyBuilder<HttpResponseMessage>, PolicyBuilder<HttpResponseMessage>>? anotherConditionsToPolicy = null)
    {
        var policyBuilder = HttpPolicyExtensions
            .HandleTransientHttpError();

        policyBuilder = anotherConditionsToPolicy?.Invoke(policyBuilder) ?? policyBuilder;

        return policyBuilder.WaitAndRetryAsync(
            retryCount: 3,
            retryAttempt => TimeSpan.FromMilliseconds(Math.Pow(2, retryAttempt))
        );
    }
}
