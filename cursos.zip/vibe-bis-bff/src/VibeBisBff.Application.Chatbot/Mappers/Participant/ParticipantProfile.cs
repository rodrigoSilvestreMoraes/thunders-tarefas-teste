﻿using AutoMapper;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;

namespace VibeBisBff.Application.Chatbot.Mappers.Participant;
public class ParticipantProfile : Profile
{
    public static DigitalAccountParticipantCreate MapToDigitalAccountCreate(ParticipantsRegisterBaseRequestDto request)
    {
        if (string.IsNullOrEmpty(request.Name))
            request.Name = "    ";

        var response = new DigitalAccountParticipantCreate
        {
            Country = "Brasil",
            DocumentTypeEnumId = 1,
            EmailList = new List<EmailListItems> { new EmailListItems { EmailTypeEnumId = 1, Email = request.Email } },
            PersonName = request.Name,
            PersonTypeEnumId = 1,
            PhoneList = new List<PhoneListItems> {
            new PhoneListItems
            {
                PhoneTypeEnumId = 1 ,
                DDI = int.Parse(request.Cellphone[..2]),
                DDD = int.Parse(request.Cellphone[2..4]),
                Number = int.Parse(request.Cellphone[4..])
            }
            },
            RandomKey = request.Document,
            UserDocument = request.Document
        };

        if (request.Address != null)
        {
            request = FillEmptyAddress(request);
            response.AdressList = new List<AdressListItems> { new AdressListItems
            {
                 City = request.Address.City,
                 Country = request.Address.Country,
                 AdressTypeEnumId = 1,
                 District = request.Address.District,
                 Number = request.Address.Number,
                 PostalCode = request.Address.PostalCode,
                 State = request.Address.State,
                 Street = request.Address.Street }
            };
        }
        else
            response.AdressList = new List<AdressListItems>();

        return response;
    }

    private  static ParticipantsRegisterBaseRequestDto FillEmptyAddress(ParticipantsRegisterBaseRequestDto request)
    {
        if (string.IsNullOrEmpty(request.Address.Street))
            request.Address.Street = "Não Informado";

        if (string.IsNullOrEmpty(request.Address.Country))
            request.Address.Country = "Não Informado";

        if (string.IsNullOrEmpty(request.Address.City))
            request.Address.City = "Não Informado";

        if (string.IsNullOrEmpty(request.Address.Complement))
            request.Address.Complement = "Não Informado";

        if (string.IsNullOrEmpty(request.Address.State))
            request.Address.State = "Não Informado";

        if (string.IsNullOrEmpty(request.Address.PostalCode))
            request.Address.PostalCode = "Não Informado";

        if (string.IsNullOrEmpty(request.Address.District))
            request.Address.District = "Não Informado";

        if (string.IsNullOrEmpty(request.Address.Reference))
            request.Address.Reference = "Não Informado";

        if (request.Address.Number == default(int))
            request.Address.Number = default(int);

        return request;
    }
}
