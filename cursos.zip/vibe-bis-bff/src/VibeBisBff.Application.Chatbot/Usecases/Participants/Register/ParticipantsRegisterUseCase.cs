﻿using Common.Core.Exceptions;
using ErrorOr;
using FluentValidation;
using Microsoft.Extensions.Options;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Chatbot.Mappers.Participant;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCuting.Dto.Participants.Response;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IamClientCredentials;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;
using VibeBisBff.ExternalServices.Vertem.Terms;
using VibeBisBff.ExternalServices.Vertem.Terms.Dto;

namespace VibeBisBff.Application.Chatbot.Usecases.Participants.Register;

public class ParticipantsRegisterUseCase : IParticipantsRegisterUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly IVertemIamTenantService _vertemIamTenantService;
    private readonly IValidator<ParticipantsRegisterBaseRequestDto> _partnerParticipantsRegisterRequestValidation;
    private readonly ITermsExternalService _termsExternalService;
    private readonly VertemTermsOptions _vertemTermsOptions;
    private readonly VertemLogsLogger _logger;
    private readonly LoginDefaultCredentials _loginDefaultCredentials;

    public ParticipantsRegisterUseCase(ITermsExternalService termsExternalService,
        IOptionsSnapshot<VertemTermsOptions> vertemTermsOptions,
        IValidator<ParticipantsRegisterBaseRequestDto> partnerParticipantsRegisterRequestValidation,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        IDigitalAccountExternalService digitalAccountExternalService,
        VertemLogsLogger logger,
        IOptionsSnapshot<LoginDefaultCredentials> loginDefaultCredentials,
        IVertemIamTenantService vertemIamTenantService)
    {
        _termsExternalService = termsExternalService;
        _vertemTermsOptions = vertemTermsOptions.Value;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _partnerParticipantsRegisterRequestValidation = partnerParticipantsRegisterRequestValidation;
        _logger = logger;
        _vertemIamTenantService = vertemIamTenantService;
        _loginDefaultCredentials = loginDefaultCredentials.Value;
    }

    public async Task<ErrorOr<ParticipantCreateResponseDto>> Execute(
        ParticipantsRegisterBaseRequestDto participantsRegisterRequestDto,
        ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto,
        string accessToken)
    {

        var errorsOnInput = await HasValidationErrorsOnInputs(participantsRegisterRequestDto);

        if (errorsOnInput.IsError)
            return errorsOnInput.Errors;

        var createParticipantRegister = ParticipantProfile.MapToDigitalAccountCreate(participantsRegisterRequestDto);
        participantsRegisterRequestHeaderDto.FillEmptyField();

        var digitalAccountId = await _digitalAccountExternalService.Create(createParticipantRegister, ApplicationType.Vibe);

        try
        {
            var digitalAccount = await _digitalAccountExternalService.GetDigitalAccountByDocument(participantsRegisterRequestDto.Document, ApplicationType.Vibe);
            if (digitalAccount == null)
                throw new BusinessException("Participante não cadastrado.");

            var phone = digitalAccount.GetCellphone();

            await AcceptTermsForApp(participantsRegisterRequestHeaderDto, digitalAccountId.Response.Id);
            var credential = GetIAMCredentialFromAppType.Get(ApplicationType.Vibe, _loginDefaultCredentials);

            //Validar o cadastro com o whats zap safe
            var resposeValidateSafe = await _identityAccessManagementExternalService.ValidateRegisterSafe(new TokenWhatsRegisterSafeRequestDto
            {
                DigitalAccountId = digitalAccount.Id,
                Flow = "onboarding",
                PhoneDdd = phone[2..4],
                PhoneDdi = phone[..2],
                PhoneNumber = phone[4..]
            }, accessToken);

            if (!resposeValidateSafe.Success)
                throw new BusinessException("Falha ao validar cadastro do participante.");

            var token = await _vertemIamTenantService.GetObjectAccessTokenForWhatsAndClientCredentials(new TokenWhatsRequestDto
            {
                ClientId = credential.Value.ClientId,
                ClientSecret = credential.Value.ClientSecret,
                GrantType = "whatsapp_credentials",
                PhoneDdd = phone[2..4],
                PhoneDdi = phone[..2],
                PhoneNumber = phone[4..]
            });

            return new ParticipantCreateResponseDto
            {
                AccessToken = token.AccessToken,
                DigitalAccountId = digitalAccount.Id,
                RefreshToken = token.RefreshToken,
                ExpiresIn = token.ExpiresIn,
                Scope = token.Scope,
                TokenType = token.TokenType
            };

        }
        catch (Exception e)
        {
            _logger.LogError(new ExceptionLog(e));
            await _digitalAccountExternalService.DeleteDigitalAccount(digitalAccountId.Response.Id);
            return Error.Unexpected(e is not BusinessException
                ? "Erro ao criar o usuário. Tente novamente, por favor"
                : e.Message);
        }
    }

    private async Task AcceptTermsForApp(ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto,
        string digitalAccountId)
    {
        var defaultRequestForAcceptTerms = new AcceptTermsRequestDto
        {
            DigitalAccountId = digitalAccountId,
            UserAgent = new TermsUserAgentDto()
            {
                Device = participantsRegisterRequestHeaderDto.Device,
                OperationalSystem = participantsRegisterRequestHeaderDto.OperationalSystem,
                Language = participantsRegisterRequestHeaderDto.Language,
                DeviceType = participantsRegisterRequestHeaderDto.DeviceType,
            },
            Geolocation = new TermsGeolocationDto()
            {
                Latitude = participantsRegisterRequestHeaderDto.Latitude,
                Longitude = participantsRegisterRequestHeaderDto.Longitude
            },
            Ip = participantsRegisterRequestHeaderDto.Ip,
        };

        await Task.WhenAll(
            _termsExternalService.AcceptTermsForLastVersion(defaultRequestForAcceptTerms with
            {
                TermId = _vertemTermsOptions.TermIdForUseTerms
            }),
            _termsExternalService.AcceptTermsForLastVersion(defaultRequestForAcceptTerms with
            {
                TermId = _vertemTermsOptions.TermIdForPrivacyPolicy
            }));
    }

    private async Task<ErrorOr<bool>> HasValidationErrorsOnInputs(ParticipantsRegisterBaseRequestDto request)
    {
        var validationResultForBody = await _partnerParticipantsRegisterRequestValidation.ValidateAsync(request);

        if (!validationResultForBody.IsValid)
            return validationResultForBody.Errors.ToValidation().ToList();

        return true;
    }
}
