﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCuting.Dto.Participants.Response;

namespace VibeBisBff.Application.Chatbot.Usecases.Participants.Register;

public interface IParticipantsRegisterUseCase
{
    Task<ErrorOr<ParticipantCreateResponseDto>> Execute(
    ParticipantsRegisterBaseRequestDto participantsRegisterRequestDto, ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto, string accessToken);
}
