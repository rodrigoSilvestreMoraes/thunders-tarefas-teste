﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Chatbot.Usecases.Participants.ValidateRegisterKey;
public interface IValidateRegisterKeyUseCase
{
    Task<ErrorOr<bool>> Execute(ValidateKeyBaseRequestDto validateKeyRequestDto);
}
