﻿using ErrorOr;
using FluentValidation;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Chatbot.Usecases.Participants.ValidateRegisterKey;

public class ValidateRegisterKeyUseCase : IValidateRegisterKeyUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IValidator<ValidateKeyBaseRequestDto> _validateKeyRequestValidator;

    public ValidateRegisterKeyUseCase(
        IDigitalAccountExternalService digitalAccountExternalService,
        IValidator<ValidateKeyBaseRequestDto> validateKeyRequestValidator)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _validateKeyRequestValidator = validateKeyRequestValidator;
    }

    public async Task<ErrorOr<bool>> Execute(ValidateKeyBaseRequestDto validateKeyRequestDto)
    {
        var validationResult = await _validateKeyRequestValidator.ValidateAsync(validateKeyRequestDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        return validateKeyRequestDto.KeyType switch
        {
            KeyType.Cellphone => await _digitalAccountExternalService.GetDigitalAccountByPhone(validateKeyRequestDto.Value, ApplicationType.Vibe) == null,
            KeyType.Document => await _digitalAccountExternalService.GetDigitalAccountByDocument(validateKeyRequestDto.Value, ApplicationType.Vibe) == null,
            KeyType.Email =>
                await _digitalAccountExternalService.GetDigitalAccountByEmail(validateKeyRequestDto.Value, ApplicationType.Vibe) == null,
            _ => throw new ArgumentException("Tipo de identificador inválido")
        };
    }
}
