﻿using Common.Core.Exceptions;
using ErrorOr;
using Microsoft.Extensions.Options;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCuting.Dto.Participants.Response;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.ExternalServices.Vertem.Terms;
using VibeBisBff.Infra.Files;

namespace VibeBisBff.Application.Chatbot.Usecases.Participants.Terms;

public class UserTermUseCase : IUserTermUseCase
{
    private readonly ITermsExternalService _termsExternalService;
    private readonly VertemTermsOptions _vertemTermsOptions;
    private readonly ExternalFileDownloader _externalFileDownloader;

    public UserTermUseCase(
        ITermsExternalService termsExternalService,
        IOptionsSnapshot<VertemTermsOptions> vertemTermsOptions,
        ExternalFileDownloader externalFileDownloader)
    {
        _termsExternalService = termsExternalService;
        _vertemTermsOptions = vertemTermsOptions.Value;
        _externalFileDownloader = externalFileDownloader;
    }

    public async Task<ErrorOr<TermFileResponseDto>> Execute(TermFileRequestDto termFileRequestDto)
    {
        return termFileRequestDto.TermType switch
        {
            TermType.UserTerm =>
                await GetTermContentAndUpdateDate(_vertemTermsOptions.TermIdForUseTerms),
            TermType.PrivacyPolicy =>
                await GetTermContentAndUpdateDate(_vertemTermsOptions.TermIdForPrivacyPolicy),
            _ => throw new BusinessException("O tipo de grantType informado é inválido")
        };
    }

    private async Task<TermFileResponseDto> GetTermContentAndUpdateDate(string termId)
    {
        var response = new TermFileResponseDto();
        var term = await _termsExternalService.GetTermById(termId, ApplicationType.Vibe);
        response.TermUrl =  term.Data.GetFileForLastVersion().ContentUrl;
        return response;
    }
}
