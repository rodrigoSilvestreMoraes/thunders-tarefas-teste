﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Quests.Request;
using VibeBisBff.CrossCuting.Dto.Quests.Response;

namespace VibeBisBff.Application.Chatbot.Usecases.Quests.ReceiptImage;

public interface IReceiptImageUseCase
{
    Task<ErrorOr<QuestReceiptImageResponseDto>> Execute(QuestReceiptImageRequestDto questReceiptImageRequestDto);
}
