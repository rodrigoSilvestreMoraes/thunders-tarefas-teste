﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using ErrorOr;
using Microsoft.Extensions.Options;
using VibeBisBff.Application.Chatbot.Usecases.Quests.Receipt;
using VibeBisBff.CrossCuting.Dto.Quests.Request;
using VibeBisBff.CrossCuting.Dto.Quests.Response;
using VibeBisBff.CrossCutting.Extensions;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer;
using VibeBisBff.ExternalServices.Vertem.QrCode;
using VibeBisBff.ExternalServices.Vertem.QrCode.Dto;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.Infra.Files;


namespace VibeBisBff.Application.Chatbot.Usecases.Quests.ReceiptImage;

public class ReceiptImageUseCase : IReceiptImageUseCase
{
    private readonly IReceiptUseCase _receiptUseCase;
    private readonly IQrCodeExternalService _qrCodeExternalService;
    private readonly IReceiptImageRepository _receiptImageRepository;
    private readonly StorageAccountOptions _storageAccountOption;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IUploaderFile _uploaderFile;

    public ReceiptImageUseCase(
        IReceiptUseCase receiptUseCase,
        IQrCodeExternalService qrCodeExternalService,
        IReceiptImageRepository receiptImageRepository,
        IUploaderFile uploaderFile,
        AuthenticatedUser authenticatedUser,
        IOptionsSnapshot<StorageAccountOptions> storageAccountOption)
    {
        _receiptUseCase = receiptUseCase;
        _qrCodeExternalService = qrCodeExternalService;
        _receiptImageRepository = receiptImageRepository;
        _storageAccountOption = storageAccountOption.Value;
        _authenticatedUser = authenticatedUser;
        _uploaderFile = uploaderFile;
    }

    public async Task<ErrorOr<QuestReceiptImageResponseDto>> Execute(QuestReceiptImageRequestDto questReceiptImageRequestDto)
    {
        if (string.IsNullOrEmpty(questReceiptImageRequestDto.ImageUrl))
            throw new BusinessException("ImageUrl obrigatório.");

        var responseBlob = await _uploaderFile.Upload(questReceiptImageRequestDto.ImageUrl, _storageAccountOption.VibeReceiptQuestImagesBlobContainer);
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if(!string.IsNullOrEmpty(responseBlob))
        {
            var receiptImage = new VibeBisBff.Domain.Entities.Quest.ReceiptImage(digitalAccountId.Value, questReceiptImageRequestDto.ImageUrl, responseBlob);
            await _receiptImageRepository.Insert(receiptImage);

            var responseImage = await _qrCodeExternalService.GetQrCodeByImage(new QrCodeImageRequest { ImageUrl = questReceiptImageRequestDto.ImageUrl });

            if(!responseImage.IsError && !string.IsNullOrEmpty(responseImage.Value.QrCode))
            {
                receiptImage.UpdateQrCodeProcessor(responseImage.Value.UrlProcessor, responseImage.Value.QrCode);
                await _receiptImageRepository.Update(receiptImage);

                var responseAuthorize = await _receiptUseCase.Execute(new QuestReceiptRequestDto { SendType = CrossCutting.Enums.ReceiptAuthorizerSendType.QRCode, UrlQrCode = responseImage.Value.QrCode });

                if(!responseAuthorize.IsError)
                {
                    receiptImage.UpdateReceiptAuthorizer(responseAuthorize.Value.Id);
                    await _receiptImageRepository.Update(receiptImage);
                    return new QuestReceiptImageResponseDto { Id = receiptImage.Id };
                }                
            }            
        }

        throw new BusinessException("Falha ao processar imagem.");
    }
}
