﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCuting.Dto.Authentication.Response;

namespace VibeBisBff.Application.Chatbot.Usecases.Authentication.Token;

public interface ITokenUseCase
{
    Task<ErrorOr<TokenResponseDto>> Token(TokenWhatsRequestDto tokenWhatsRequestDto);
}
