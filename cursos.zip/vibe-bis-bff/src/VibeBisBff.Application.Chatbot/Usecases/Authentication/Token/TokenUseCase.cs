﻿using Common.Core.Exceptions;
using ErrorOr;
using FluentValidation;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.ExternalServices.Vertem.IamClientCredentials;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Mappers.Token;
using TokenDto = VibeBisBff.CrossCuting.Dto.Authentication.Response;

namespace VibeBisBff.Application.Chatbot.Usecases.Authentication.Token;

public class TokenUseCase : ITokenUseCase
{
    private readonly IVertemIamTenantService _vertemIamTenantService;
    private readonly IValidator<TokenWhatsRequestDto> _validation;

    public TokenUseCase(IValidator<TokenWhatsRequestDto> validator,
        IVertemIamTenantService vertemIamTenantService)
    {
        _validation = validator;
        _vertemIamTenantService = vertemIamTenantService;
    }

    public async Task<ErrorOr<TokenDto.TokenResponseDto>> Token(TokenWhatsRequestDto tokenWhatsRequestDto)
    {
        var validationResult = await _validation.ValidateAsync(tokenWhatsRequestDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        return tokenWhatsRequestDto.GrantType switch
        {
            AuthenticationTypes.CLIENT_CREDENTIALS =>
                await GenerateTokenByClientCredentialsFlow(tokenWhatsRequestDto),
            AuthenticationTypes.WHATS_CREDENTIALS =>
                await GenerateTokenByWhatsCredentialsFlow(tokenWhatsRequestDto),
            _ => throw new BusinessException("O tipo de grantType informado é inválido")
        };
    }

    private async Task<TokenDto.TokenResponseDto> GenerateTokenByClientCredentialsFlow(TokenWhatsRequestDto tokenWhatsRequestDto)
    {
        if (tokenWhatsRequestDto.GrantType != AuthenticationTypes.CLIENT_CREDENTIALS)
            return null;

        var token = await _vertemIamTenantService.GetObjectAccessTokenForClientCredentials(tokenWhatsRequestDto.ClientId, tokenWhatsRequestDto.ClientSecret);

        return token.MapToGenerateToken();
    }

    private async Task<TokenDto.TokenResponseDto> GenerateTokenByWhatsCredentialsFlow(TokenWhatsRequestDto tokenWhatsRequestDto)
    {
        if (tokenWhatsRequestDto.GrantType != AuthenticationTypes.WHATS_CREDENTIALS)
            return null;

        var token = await _vertemIamTenantService.GetObjectAccessTokenForWhatsAndClientCredentials(tokenWhatsRequestDto);
        return token.MapToGenerateToken();
    }
}
