﻿using FluentValidation;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCutting.Constants;

namespace VibeBisBff.Application.Chatbot.Validations.Token;

public class TokenValidation : AbstractValidator<TokenWhatsRequestDto>
{
    public TokenValidation()
    {
        RuleFor(x => x.GrantType)
           .Must(x => x is AuthenticationTypes.WHATS_CREDENTIALS or AuthenticationTypes.CLIENT_CREDENTIALS)
           .WithMessage($"GrantType inválido")
           .When(x => x != null);

        RuleFor(x => x.ClientId)
            .NotEmpty()
            .WithMessage($"ClientId é obrigatório quando o GrantType é igual a {AuthenticationTypes.CLIENT_CREDENTIALS}")
            .When(x => x.GrantType == AuthenticationTypes.CLIENT_CREDENTIALS);

        RuleFor(x => x.ClientSecret)
            .NotEmpty()
            .WithMessage($"ClientSecret é obrigatório quando o GrantType é igual a {AuthenticationTypes.CLIENT_CREDENTIALS}")
            .When(x => x.GrantType == AuthenticationTypes.CLIENT_CREDENTIALS);

        RuleFor(x => x.GrantType)
            .NotEmpty()
            .WithMessage($"GrantType é obrigatório");

        RuleFor(x => x.PhoneDdi)
            .NotEmpty()
            .WithMessage($"PhoneDdi é obrigatório quando o GrantType é igual a {AuthenticationTypes.WHATS_CREDENTIALS}")
            .When(x => x.GrantType == AuthenticationTypes.WHATS_CREDENTIALS);

        RuleFor(x => x.PhoneDdd)
            .NotEmpty()
            .WithMessage($"PhoneDdd é obrigatório quando o GrantType é igual a {AuthenticationTypes.WHATS_CREDENTIALS}")
            .When(x => x.GrantType == AuthenticationTypes.WHATS_CREDENTIALS);

        RuleFor(x => x.PhoneNumber)
            .NotEmpty()
            .WithMessage($"PhoneNumber é obrigatório quando o GrantType é igual a {AuthenticationTypes.WHATS_CREDENTIALS}")
            .When(x => x.GrantType == AuthenticationTypes.WHATS_CREDENTIALS);
    }
}
