﻿using FluentValidation;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Chatbot.Validations.Participant;

public class ValidateKeyChatbotRequestValidation : AbstractValidator<ValidateKeyBaseRequestDto>
{
    public ValidateKeyChatbotRequestValidation()
    {
        RuleFor(x => x.KeyType)
            .NotEmpty()
            .WithMessage("O tipo de chave deve ser específicado")
            .IsInEnum()
            .WithMessage("O tipo de chave específicado é inválido");

        RuleFor(x => x.Value)
            .NotEmpty()
            .WithMessage("O valor da chave específicado é inválido");
    }
}
