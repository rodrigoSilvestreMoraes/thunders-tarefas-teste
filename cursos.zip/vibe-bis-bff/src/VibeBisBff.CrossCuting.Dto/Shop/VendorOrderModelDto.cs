﻿namespace VibeBisBff.CrossCuting.Dto.Shop;

public record VendorOrderModelDto
{
    public string StatusGroupDescription { get; set; }
    public decimal TotalShippingValue { get; set; }
    public int VendorId { get; set; }
    public string VendorName { get; set; }
    public string VendorOrderId { get; set; }
    public List<VendorOrderItemDto> Items { get; set; }
    public DateTime? DeliveryForecast { get; set; }
}
