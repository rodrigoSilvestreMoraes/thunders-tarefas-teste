﻿namespace VibeBisBff.CrossCuting.Dto.Shop;
public record CardBrandsResponseDto
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string RegexValidation { get; set; }
    public string PaymentCode { get; set; }
}
