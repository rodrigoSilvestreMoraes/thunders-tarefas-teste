﻿namespace VibeBisBff.CrossCuting.Dto.Shop;

public record VendorOrderItemDto
{
    public int Id { get; set; }
    public string ImageUrl { get; set; }
    public DateTime? DeliveryForecast { get; set; }
    public DateTime? DeliveryDate { get; set; }
    public string Name { get; set; }
    public string ProductSkuId { get; set; }
    public string ProductCode { get; set; }
    public string CategoryId { get; set; }
    public string CategoryName { get; set; }
    public decimal SellingPrice { get; set; }
    public decimal CostPrice { get; set; }
}
