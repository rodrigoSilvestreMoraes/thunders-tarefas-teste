﻿namespace VibeBisBff.CrossCuting.Dto.Shop;

public record PurchaseInstallmentDto
{
    public int Parcel { get; set; }
    public decimal ParcelInterest { get; set; }
    public decimal ParcelValue { get; set; }
    public string Description { get; set; }
}

public record ShopItemInstallmentDto
{
    public int Installment { get; set; }
    public decimal Value { get; set; }
    public string Description { get; set; }
}
