﻿namespace VibeBisBff.CrossCuting.Dto.Version;

public record VersionResponseDto
{
    public string MinimumAppVersion { get; set; }
}
