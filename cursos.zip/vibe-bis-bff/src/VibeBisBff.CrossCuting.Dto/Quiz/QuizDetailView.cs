﻿using VibeBisBff.CrossCuting.Dto.Quiz.Register;

namespace VibeBisBff.CrossCuting.Dto.Quiz;

public record QuizDetailView
{
    public string Name { get; set; }
    public string Description { get; set; }
    public RegisterAnswerType  Type { get; set; }
    public List<QuizDetailQuestionsView> Questions { get; set; }  = new List<QuizDetailQuestionsView>();
}

public record QuizDetailQuestionsView
{
    public long Id { get; set; }
    public string Description { get; set; }
    public int Index { get; set; }
    public string Type { get; set; }
    public int MaxAlternativesAnswer { get; set; }
    public List<QuizDetailAlternativesAnswerView> Alternatives { get; set; } = new List<QuizDetailAlternativesAnswerView>();
}

public record QuizDetailAlternativesAnswerView
{
    public long Id { get; set; }
    public string Description { get; set; }
    public int Index { get; set; }
}


