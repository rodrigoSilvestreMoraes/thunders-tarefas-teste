﻿namespace VibeBisBff.CrossCuting.Dto.Quiz.Register;

public record QuizRegisterAnswerRequest
{
    /// <summary>
    /// Id do quiz ou do survey
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Id da missão
    /// </summary>
    public string QuestId { get; set; }

    public List<QuizRegisterDetailRequestDto> Answers { get; set; } = new List<QuizRegisterDetailRequestDto>();
    public List<SurveyRegisterDetailRequestDto> Survey { get; set; } = new List<SurveyRegisterDetailRequestDto>();
}

public record QuizRegisterDetailRequestDto
{
    public int QuestionId { get; set; }
    public List<int> ParticipantAlternatives { get; set; } = new List<int>();
}

public record SurveyRegisterDetailRequestDto
{
    public int QuestionId { get; set; }
    public List<SurveyDetailRequest> ParticipantAlternatives { get; set; } = new List<SurveyDetailRequest>();

}

public record SurveyDetailRequest
{
    public int? AlternativeId { get; set; }
    public string Value { get; set; }
}

public enum  RegisterAnswerType
{
    Quiz,
    Survey
}
