﻿namespace VibeBisBff.CrossCuting.Dto.Quiz.Register;

public record QuizRegisterAnswerResponse
{
    public decimal FundsReceive { get; set; }
    public bool Winner { get; set; }
}
