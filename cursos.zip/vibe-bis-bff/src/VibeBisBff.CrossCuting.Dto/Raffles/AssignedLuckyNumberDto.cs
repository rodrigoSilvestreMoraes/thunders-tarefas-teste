﻿namespace VibeBisBff.CrossCuting.Dto.Raffles;
public record AssignedLuckyNumberDto
{
    public string Code { get; set; }
    public DateTime AssignedDate { get; set; }
}
