﻿namespace VibeBisBff.CrossCuting.Dto.Raffles;

public record RaffleSpentBalanceDto
{
    public decimal CurrentAccumulatedInVirtualCoins { get; set; }
    public decimal RemainingVirtualCoinsToReceiveLuckyNumber { get; set; }
    public decimal TotalToAccumulateToReceiveALuckyNumber => CurrentAccumulatedInVirtualCoins + RemainingVirtualCoinsToReceiveLuckyNumber;
}
