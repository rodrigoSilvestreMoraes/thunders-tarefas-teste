﻿namespace VibeBisBff.CrossCuting.Dto.Raffles;

public class RaffleGroupDto
{
    public string Id { get; set; }
    public string Title { get; set; }
    public string BannerImageUrl { get; set; }
    public string DetailImageUrl { get; set; }
    public string FullRegulationUrl { get; set; }
    public string SummaryRegulation { get; set; }
    public RaffleSpentBalanceDto SpentBalance { get; set; }
    public List<RaffleDto> Raffles { get; set; }
}
