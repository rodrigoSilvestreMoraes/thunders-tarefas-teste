﻿using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.CrossCuting.Dto.Raffles;

public record RaffleDto
{
    public string Id { get; set; }
    public string Name { get; set; }
    public string LuckyNumberAwarded { get;  set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public DateTime RaffleDate { get; set; }
    public DateTime AnnouncementDate { get; set; }
    public List<string> ReceivedLuckyNumbers { get; set; }
    public List<AssignedLuckyNumberDto> AssignedLuckyNumbers { get; set; }
    public RaffleStatus Status { get; set; }
}
