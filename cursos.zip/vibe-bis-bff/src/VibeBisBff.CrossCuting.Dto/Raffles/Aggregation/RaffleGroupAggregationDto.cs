﻿namespace VibeBisBff.CrossCuting.Dto.Raffles.Aggregation;

public record RaffleGroupAggregationDto
{
    public string Id { get; set; }
    public string Title { get; set; }
    public string BannerImageUrl { get; set; }
    public string DetailImageUrl { get; set; }
    public string SummaryRegulationTermId { get; set; }
    public string FullRegulationTermId { get; set; }
    public string SpendingSettingsId { get; set; }
    public ICollection<RaffleAggregationDto> Raffles { get; set; }
}
