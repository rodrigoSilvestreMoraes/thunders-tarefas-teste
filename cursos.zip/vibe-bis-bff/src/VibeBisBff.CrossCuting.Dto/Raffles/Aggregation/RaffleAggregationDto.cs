﻿namespace VibeBisBff.CrossCuting.Dto.Raffles.Aggregation;

public record RaffleAggregationDto
{
    public string LuckyNumberAwarded { get;  set; }
    public string Name { get; set; }
    public DateTime StartDate { get;  set; }
    public DateTime EndDate { get; set; }
    public DateTime RaffleDate { get; set; }
}
