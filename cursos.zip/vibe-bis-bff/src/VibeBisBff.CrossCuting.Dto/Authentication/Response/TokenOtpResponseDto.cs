﻿using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.CrossCuting.Dto.Authentication.Response;

public record TokenOtpResponseDto
{
    public string OtpId {  get;  set; }
    public string PhoneNumber { get; set; }
    public OtpSendType OtpSendType { get; set; }        
}
