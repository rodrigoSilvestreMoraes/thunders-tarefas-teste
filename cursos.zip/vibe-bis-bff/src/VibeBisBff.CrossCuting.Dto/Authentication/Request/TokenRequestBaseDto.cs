﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Authentication.Request
{
    /// <summary>
    /// Solicitação de token de parceiro.
    /// </summary>
    public record TokenRequestBaseDto
    {
       /// <summary>
       /// required
       /// </summary>
       /// <remarks>
       ///  ClientId
       /// </remarks>
       /// <value>ClientId</value>
       /// <example>123456</example>
        [SwaggerSchema(Nullable = false)]
        public string ClientId { get; set; }

        /// <summary>
        /// required
        /// </summary>
        /// <remarks>
        /// ClientSecret para autenticação
        /// </remarks>
        /// <value>ClientSecret</value>
        /// <example>Abcd1234</example>
        [SwaggerSchema(Nullable = false)]
        public string ClientSecret { get; set; }

        /// <summary>
        /// required
        /// </summary>
        /// <remarks>
        /// GrantType
        /// </remarks>
        /// <value>GrantType</value>
        /// <example>client_credentials | otp_credentials</example>
        [SwaggerSchema(Nullable = false)]
        public virtual string GrantType { get; set; }
    }
}
