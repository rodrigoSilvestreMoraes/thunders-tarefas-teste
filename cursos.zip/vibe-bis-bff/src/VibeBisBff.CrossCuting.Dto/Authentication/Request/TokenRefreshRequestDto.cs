﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Authentication.Request;


/// <summary>
/// Solicitação de atualização de token
/// </summary>
public record TokenRefreshRequestDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// ClientId
    /// </remarks>
    /// <value>ClientId</value>
    /// <example>123456</example>
    [SwaggerSchema(Nullable = false)]
    public string ClientId { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// ClientSecret
    /// </remarks>
    /// <value>ClientSecret</value>
    /// <example>Abcd1234</example>
    [SwaggerSchema(Nullable = false)]
    public string ClientSecret { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Token de atualização para solicitar um novo token
    /// </remarks>
    /// <value>RefreshToken</value>
    /// <example>eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c</example>
    [SwaggerSchema(Nullable = false)]
    public string RefreshToken { get; set; }
}
