﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Authentication.Request;

/// <summary>
/// DTO para solicitação de token do usuário
/// </summary>
public record TokenUserRequestDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    ///  ClientId
    /// </remarks>
    /// <value>ClientId</value>
    /// <example>123456</example>
    [SwaggerSchema(Nullable = false)]
    public string ClientId { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// ClientSecret para autenticação
    /// </remarks>
    /// <value>ClientSecret</value>
    /// <example>Abcd1234</example>
    [SwaggerSchema(Nullable = false)]
    public string ClientSecret { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// GrantType
    /// </remarks>
    /// <value>GrantType</value>
    /// <example>client_credentials | otp_credentials</example>
    [SwaggerSchema(Nullable = false)]
    public string GrantType { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// ID Participante
    /// </remarks>
    /// <value>ParticipantIdentifier</value>
    /// <example>123</example>
    [SwaggerSchema(Nullable = false)]
    public string ParticipantIdentifier { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// One-Time Password (OTP)
    /// </remarks>
    /// <value>OtpId</value>
    /// <example>789012</example>
    [SwaggerSchema(Nullable = false)]
    public string OtpId { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// One-Time Password (OTP) gerado
    /// </remarks>
    /// <value>OtpCode</value>
    /// <example>123456</example>
    [SwaggerSchema(Nullable = false)]
    public string OtpCode { get; set; }
}
