﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Authentication.Request;

/// <summary>
/// Solicitação de token com OTP
/// </summary>
public record TokenOtpRequestDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Nome de usuário
    /// </remarks>
    /// <value>Username</value>
    [SwaggerSchema(Nullable = false)]
    public string Username { get; set; }
}

