﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Authentication.Request;

/// <summary>
/// Solicitação de token de parceiro.
/// </summary>
public record TokenRequestDto : TokenRequestBaseDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// One-Time Password (OTP)
    /// </remarks>
    /// <value>OtpId</value>
    /// <example>789012</example>
    [SwaggerSchema(Nullable = false)]
    public string OtpId { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// One-Time Password (OTP) gerado
    /// </remarks>
    /// <value>OtpCode</value>
    /// <example>123456</example>
    [SwaggerSchema(Nullable = false)]
    public string OtpCode { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Nome de usuário
    /// </remarks>
    /// <value>Username</value>
    /// <example>user123</example>
    [SwaggerSchema(Nullable = false)]
    public string Username { get; set; }
}
