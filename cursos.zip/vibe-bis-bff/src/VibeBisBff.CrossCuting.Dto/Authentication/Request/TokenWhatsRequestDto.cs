﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Authentication.Request;

public record TokenWhatsRequestDto : TokenRequestBaseDto
{
    /// <summary>
    /// required, se a solicitação for token do usuário
    /// </summary>
    /// <remarks>
    /// DDI do país
    /// </remarks>
    /// <value>PhoneDdi</value>
    /// <example>55</example>
    [SwaggerSchema(Nullable = false)]
    public string PhoneDdi {  get; set; }

    /// <summary>
    /// required, se a solicitação for token do usuário
    /// </summary>
    /// <remarks>
    /// DDD do estado
    /// </remarks>
    /// <value>PhoneDdd</value>
    /// <example>11</example>
    [SwaggerSchema(Nullable = false)]
    public string PhoneDdd { get; set; }

    /// <summary>
    /// required, se a solicitação for token do usuário
    /// </summary>
    /// <remarks>
    /// Número do celular apenas números
    /// </remarks>
    /// <value>PhoneNumber</value>
    /// <example>00000000</example>
    [SwaggerSchema(Nullable = false)]
    public string PhoneNumber { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// GrantType
    /// </remarks>
    /// <value>GrantType</value>
    /// <example>client_credentials | whatsapp_credentials</example>
    [SwaggerSchema(Nullable = false)]
    public override string GrantType { get => base.GrantType; set => base.GrantType = value; }
}
