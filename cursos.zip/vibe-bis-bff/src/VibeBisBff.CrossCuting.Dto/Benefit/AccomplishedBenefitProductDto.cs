﻿namespace VibeBisBff.CrossCuting.Dto.Benefit;

public record AccomplishedBenefitProductDto
{
    public string Id { get; set; }
    public string OriginalProductId { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public List<SectionDto> Sections { get; set; }
    public List<SkuEDto> Skus { get; set; }
    public List<FeatureDto> Features { get; set; }
    public VendorDto Vendor { get; set; }
    public bool OnlyCash { get; set; }
}

public record FeatureDto
{
    public string Name { get; set; }
    public string Value { get; set; }
    public string Type { get; set; }
}

public record ImageDto
{
    public string SmallImage { get; set; }
    public string MediumImage { get; set; }
    public string LargeImage { get; set; }
    public int Order { get; set; }
}    

public record SectionDto
{
    public int Id { get; set; }
    public string SectionType { get; set; }
    public string Name { get; set; }
    public string Slug { get; set; }
}

public record SkuEDto
{
    public string Sku { get; set; }
    public string OriginalId { get; set; }
    public string Status { get; set; }
    public string Ean { get; set; }
    public List<ImageDto> Images { get; set; }
    public List<SkuFeatureDto> SkuFeatures { get; set; }
}

public record SkuFeatureDto
{
    public string Name { get; set; }
    public string Value { get; set; }
    public string Type { get; set; }
}

public record VendorDto
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string LogoUrl { get; set; }
    public string Type { get; set; }
    public string Slug { get; set; }
}
