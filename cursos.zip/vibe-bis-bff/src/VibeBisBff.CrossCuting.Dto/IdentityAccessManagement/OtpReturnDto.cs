﻿namespace VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;

public record OtpReturnDto(string OtpId,
    bool IsTooManyRequest
);
