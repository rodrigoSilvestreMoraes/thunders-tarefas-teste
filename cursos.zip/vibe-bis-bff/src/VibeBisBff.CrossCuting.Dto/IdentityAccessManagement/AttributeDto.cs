﻿using System.Text.Json.Serialization;

namespace VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;

public record AttributeDto
{
    [JsonPropertyName("key")]
    public string Key { get; set; }

    [JsonPropertyName("value")]
    public string Value { get; set; }
}
