﻿namespace VibeBisBff.CrossCuting.Dto.Participants.Response;

public record TermFileResponseDto
{
    public string TermUrl { get; set; }
}
