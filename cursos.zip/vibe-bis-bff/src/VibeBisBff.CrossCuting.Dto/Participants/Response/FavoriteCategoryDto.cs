﻿
using VibeBisBff.CrossCuting.Dto.Engagement;

namespace VibeBisBff.CrossCuting.Dto.Participants.Response;

public record FavoriteCategoryDto : CategoryDto
{
    public List<BannerItemDto> Banners { get; set; }
}
