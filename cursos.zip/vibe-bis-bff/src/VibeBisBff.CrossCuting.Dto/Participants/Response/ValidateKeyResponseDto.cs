﻿namespace VibeBisBff.CrossCuting.Dto.Participants.Response;
public record ValidateKeyResponseDto
{
    public bool Available { get; set; }
}
