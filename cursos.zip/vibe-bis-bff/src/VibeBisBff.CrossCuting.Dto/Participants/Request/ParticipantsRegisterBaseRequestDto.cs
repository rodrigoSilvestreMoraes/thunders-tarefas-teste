﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Participants.Request;


/// <summary>
/// solicitação de registro de participantes
/// </summary>
public record ParticipantsRegisterBaseRequestDto
{
    /// <summary>
    /// Name
    /// </summary>
    [SwaggerSchema(Nullable = true)]
    public string Name { get; set; }

    /// <summary>
    /// required
    /// </summary>
    [SwaggerSchema(Nullable = false)]
    public string Cellphone { get; set; }

    /// <summary>
    /// required
    /// </summary>
    [SwaggerSchema(Nullable = false)]
    public string Email { get; set; }

    /// <summary>
    ///  BirthDate
    /// </summary>
    /// <example>1900-01-01</example>
    [SwaggerSchema(Nullable = true)]
    public DateTime BirthDate { get; set; }

    /// <summary>
    /// required
    /// </summary>
    [SwaggerSchema(Nullable = false)]
    public string Document { get; set; }

    /// <summary>
    /// Endereço do participante
    /// </summary>
    public ParticipantAddressDto Address { get; set; }

    /// <summary>
    /// Termos de uso
    /// </summary>
    public ParticipantsUseTerms UseTerms { get; set; }
}
