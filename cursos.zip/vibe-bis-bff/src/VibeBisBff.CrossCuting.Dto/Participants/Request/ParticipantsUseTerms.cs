﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Participants.Request;


/// <summary>
/// Termos de uso
/// </summary>
public record ParticipantsUseTerms
{
    /// <summary>
    /// required
    /// </summary>
    [SwaggerSchema(Nullable = false)]
    public bool AcceptedAppUseTerms { get; set; }

    /// <summary>
    /// required
    /// </summary>
    [SwaggerSchema(Nullable = false)]
    public bool AcceptedPrivacyPolicy { get; set; }
}
