﻿namespace VibeBisBff.CrossCuting.Dto.Participants.Request;

public record AddFavoriteVendorCategoryRequestDto
{
    public HashSet<string> CategoryIds { get; set; }
}
