﻿namespace VibeBisBff.CrossCuting.Dto.Participants.Request;

public record EmailOtpCodeDto(string OtpId, string Code);

