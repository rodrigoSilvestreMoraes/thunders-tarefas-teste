﻿using Swashbuckle.AspNetCore.Annotations;
using VibeBisBff.CrossCutting.Extensions;

namespace VibeBisBff.CrossCuting.Dto.Participants.Request;

/// <summary>
/// Endereço do participante
/// </summary>
public record ParticipantAddressDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Endereço IP
    /// </remarks>
    /// <example>Brasil</example>
    /// <value>Country</value>
    [SwaggerSchema(Nullable = false)]
    public string Country { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Estado
    /// </remarks>
    /// <example>São Paulo</example>
    /// <value>State</value>
    [SwaggerSchema(Nullable = false)]
    public string State { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Cidade
    /// </remarks>
    /// <example>São Paulo</example>
    /// <value>City</value>
    [SwaggerSchema(Nullable = false)]
    public string City { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// CEP
    /// </remarks>
    /// <example>06454-000</example>
    /// <value>PostalCode</value>
    [SwaggerSchema(Nullable = false)]
    public string PostalCode { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Bairro
    /// </remarks>
    /// <example>Alphaville Industrial</example>
    /// <value>District</value>
    [SwaggerSchema(Nullable = false)]
    public string District { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Rua
    /// </remarks>
    /// <example>Al. Rio Negro</example>
    /// <value>Street</value>
    [SwaggerSchema(Nullable = false)]
    public string Street { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Número do endereço
    /// </remarks>
    /// <example>585</example>
    /// <value>Number</value>
    [SwaggerSchema(Nullable = false)]
    public int Number { get; set; }

    /// <summary>
    /// Complemento.
    /// </summary>
    /// <remarks>
    /// Complemento do endereço
    /// </remarks>
    /// <value>Complement</value>
    public string Complement { get; set; }

    /// <summary>
    /// Referência.
    /// </summary>
    /// <remarks>
    /// Referência para o endereço
    /// </remarks>
    /// <value>Reference</value>
    public string Reference { get; set; }


    public void RemoveSpecialCharacters()
    {
        Country = Country.RemoveSpecialCharacters();
        State = State.RemoveSpecialCharacters();
        City = City.RemoveSpecialCharacters();
        PostalCode = PostalCode.RemoveSpecialCharacters();
        District = District.RemoveSpecialCharacters();
        Street = Street.RemoveSpecialCharacters();
        Complement = Complement.RemoveSpecialCharacters();
        Reference = Reference.RemoveSpecialCharacters();
    }


    public static ParticipantAddressDto GetAddressVertem()
    {
        return new ParticipantAddressDto
        {
            City = "São Paulo",
            Complement = "Bloco C, 13º andar",
            Country = "Brasil",
            District = "Alphaville Industrial - Barueri",
            Number = 585,
            State = "SP",
            Street = "Al. Rio Negro",
            PostalCode = "06454-000",
            Reference = "N/D"
        };
    }
}
