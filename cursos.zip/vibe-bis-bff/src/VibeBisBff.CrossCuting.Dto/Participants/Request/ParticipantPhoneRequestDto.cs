﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Participants.Request;


/// <summary>
/// Solicitação de telefone
/// </summary>
public record ParticipantPhoneRequestDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    ///Número de telefone
    /// </remarks>
    /// <value>Phone</value>
    /// <example>+1234567890</example>
    [SwaggerSchema(Nullable = false)]
    public string Phone { get; set; }
}

