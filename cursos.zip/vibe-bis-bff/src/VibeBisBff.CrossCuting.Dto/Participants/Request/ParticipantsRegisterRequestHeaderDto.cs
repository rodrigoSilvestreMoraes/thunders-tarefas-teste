﻿using Swashbuckle.AspNetCore.Annotations;
using System.Text.Json.Serialization;

namespace VibeBisBff.CrossCuting.Dto.Participants.Request;

/// <summary>
/// Header da solicitação de registro de participantes.
/// </summary>
public record ParticipantsRegisterRequestHeaderDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Endereço IP do dispositivo que está solicitando o registro.
    /// </remarks>
    /// <example>192.168.0.1</example>
    /// <value>Ip</value>
    [SwaggerSchema(Nullable = false)]
    public string Ip { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Dispositivo utilizado para a solicitação de registro.
    /// </remarks>
    /// <example>iPhone 12</example>
    /// <value>Device</value>
    [SwaggerSchema(Nullable = false)]
    public string Device { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Tipo de dispositivo utilizado para a solicitação de registro.
    /// </remarks>
    /// <example>Mobile</example>
    /// <value>DeviceType</value>
    [SwaggerSchema(Nullable = false)]
    public string DeviceType { get; set; }

    /// <summary>
    /// required-Agent
    /// </summary>
    /// <remarks>
    /// Cabeçalho User-Agent do navegador ou aplicativo.
    /// </remarks>
    /// <example>Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36</example>
    /// <value>UserAgent</value>
    [SwaggerSchema(Nullable = false)]
    [JsonPropertyName("User-Agent")]
    public string UserAgent { get; set; }

    /// <summary>
    /// Latitude
    /// </summary>
    /// <remarks>
    /// Latitude
    /// </remarks>
    /// <example>37.7749</example>
    /// <value>Latitude</value>
    [SwaggerSchema(Nullable = true)]
    public string Latitude { get; set; }

    /// <summary>
    /// Longitude
    /// </summary>
    /// <remarks>
    /// Longitude
    /// </remarks>
    /// <example>122.4194</example>
    /// <value>Longitude</value>
    [SwaggerSchema(Nullable = true)]
    public string Longitude { get; set; }

    /// <summary>
    /// Sistema operacional.
    /// </summary>
    /// <remarks>
    /// Sistema operacional do dispositivo.
    /// </remarks>
    /// <example>Windows10</example>
    /// <value>OperationalSystem</value>
    [SwaggerSchema(Nullable = true)]
    public string OperationalSystem { get; set; }

    /// <summary>
    /// Language
    /// </summary>
    /// <remarks>
    /// Idioma configurado no dispositivo.
    /// </remarks>
    /// <example>en-US</example>
    /// <value>Language</value>
    [SwaggerSchema(Nullable = true)]
    public string Language { get; set; }

    /// <summary>
    /// Preenche campos vazios com uma string vazia.
    /// </summary>
    public void FillEmptyField()
    {
        if (string.IsNullOrEmpty(Device))
            Device = "";

        if (string.IsNullOrEmpty(DeviceType))
            DeviceType = "";

        if (string.IsNullOrEmpty(UserAgent))
            UserAgent = "";

        if (string.IsNullOrEmpty(Latitude))
            Latitude = "";

        if (string.IsNullOrEmpty(Longitude))
            Longitude = "";

        if (string.IsNullOrEmpty(OperationalSystem))
            OperationalSystem = "";

        if (string.IsNullOrEmpty(Language))
            Language = "";
    }
}

