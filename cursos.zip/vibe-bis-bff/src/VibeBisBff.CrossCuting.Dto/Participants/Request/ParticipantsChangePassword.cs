﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Participants.Request;

/// <summary>
/// Alteração de senha do participante.
/// </summary>
public record ParticipantsChangePassword
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Senha atual
    /// </remarks>
    /// <example>SenhaAtual123</example>
    /// <value>CurrentPassword</value>
    [SwaggerSchema(Nullable = false)]
    public string CurrentPassword { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Nova senha
    /// </remarks>
    /// <example>NovaSenha456</example>
    /// <value>NewPassword</value>
    [SwaggerSchema(Nullable = false)]
    public string NewPassword { get; set; }
}

