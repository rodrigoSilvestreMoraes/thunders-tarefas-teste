﻿using Swashbuckle.AspNetCore.Annotations;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.CrossCuting.Dto.Participants.Request;
/// <summary>
/// Validação de chave.
/// </summary>
public record ValidateKeyBaseRequestDto
{
    /// <summary>
    /// required
    /// </summary>
    [SwaggerSchema(Nullable = false)]
    public KeyType? KeyType { get; set; }

    /// <summary>
    /// required
    /// </summary>
    [SwaggerSchema(Nullable = false)]
    public string Value { get; set; }
}
