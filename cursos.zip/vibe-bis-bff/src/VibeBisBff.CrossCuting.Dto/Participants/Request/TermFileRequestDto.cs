﻿using Swashbuckle.AspNetCore.Annotations;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.CrossCuting.Dto.Participants.Request;

/// <summary>
/// Request de filtro para consulta de termos
/// </summary>
public record TermFileRequestDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Tipo do termo
    /// </remarks>
    /// <example>UserTerm | PrivacyPolicy</example>
    /// <value>0 | 1</value>
    [SwaggerSchema(Nullable = false)]
    public TermType TermType { get; set; }
}
