﻿using Swashbuckle.AspNetCore.Annotations;

namespace VibeBisBff.CrossCuting.Dto.Participants.Request;


/// <summary>
/// Solicitação de e-mail do participante
/// </summary>
public record ParticipantEmailRequestDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// O endereço de e-mail do participante
    /// </remarks>
    /// <value>Email</value>
    /// <example>email@email.com</example>
    [SwaggerSchema(Nullable = false)]
    public string Email { get; set; }
}

