﻿namespace VibeBisBff.CrossCuting.Dto;

public record PagingDataResponseDto<T>
{
    public int TotalItems { get; set; }
    public List<T> Items { get; set; }
}
