﻿namespace VibeBisBff.CrossCuting.Dto.Quests.Database;

public record AccomplishedQuestIdsProjectionDto
{
    public string Id { get; set; }
    public string QuestId { get; set; }
}
