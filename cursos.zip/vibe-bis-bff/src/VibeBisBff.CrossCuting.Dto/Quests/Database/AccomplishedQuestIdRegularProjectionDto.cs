﻿namespace VibeBisBff.CrossCuting.Dto.Quests.Database;

public record AccomplishedQuestIdRegularProjectionDto
{
    public string QuestId { get; set; }
    public bool IsRegular { get; set; }
}
