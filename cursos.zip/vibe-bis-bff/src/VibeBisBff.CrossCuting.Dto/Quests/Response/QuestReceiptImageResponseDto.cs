﻿namespace VibeBisBff.CrossCuting.Dto.Quests.Response;

public record QuestReceiptImageResponseDto
{
    public string Id { get; set; }
}
