﻿namespace VibeBisBff.CrossCuting.Dto.Quests.Response;
public record QuestReceiptResponseDto
{
    public string Id { get; set; }
}
