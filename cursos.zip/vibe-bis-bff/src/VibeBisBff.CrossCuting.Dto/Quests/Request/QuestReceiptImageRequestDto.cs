﻿namespace VibeBisBff.CrossCuting.Dto.Quests.Request;

/// <summary>
/// Solicitação de envio de NF com o QR Code em imagem
/// </summary>
public record QuestReceiptImageRequestDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Endereço da imagem do QR Code
    /// </remarks>
    /// <value>ImageUrl</value>
    /// <example> Url do QrCode</example>
    public string ImageUrl {  get; set; }
}
