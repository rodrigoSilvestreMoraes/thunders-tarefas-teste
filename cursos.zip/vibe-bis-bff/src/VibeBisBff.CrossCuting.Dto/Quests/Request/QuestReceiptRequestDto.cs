﻿using Swashbuckle.AspNetCore.Annotations;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.CrossCuting.Dto.Quests.Request;

/// <summary>
/// Solicitação de quest.
/// </summary>
public record QuestReceiptRequestDto
{
    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    /// Tipo da quest
    /// </remarks>
    /// <value>SendType</value>
    /// <example> QRCode, AccessKey</example>
    [SwaggerSchema(Nullable = false)]
    public ReceiptAuthorizerSendType SendType { get; set; }

    /// <summary>
    /// required
    /// </summary>
    /// <remarks>
    ///  URL do código QR
    /// </remarks>
    /// <value>UrlQrCode</value>
    /// <example>https://example.com/qr</example>
    [SwaggerSchema(Nullable = false)]
    public string UrlQrCode { get; set; }
}
