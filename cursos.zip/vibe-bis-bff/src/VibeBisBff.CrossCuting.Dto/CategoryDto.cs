﻿namespace VibeBisBff.CrossCuting.Dto;

public record CategoryDto
{
    public string Id { get; set; }
    public string Name { get; set; }
}
