﻿namespace VibeBisBff.CrossCuting.Dto.Notification;

public record NotificationResponse
{
    public string Id { get; set; }
}
