﻿using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.CrossCuting.Dto.Notification;

public record NotificationRequestDto
{
    public string DigitalAccountId { get; set; }
    public NotificationSourceEvent SourceEvent {  get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string CorrelationId { get; set; }
    public string TenantConfigId { get; set; }
    public string ImageUrl { get; set; }
}
