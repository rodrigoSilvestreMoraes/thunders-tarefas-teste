﻿namespace VibeBisBff.CrossCuting.Dto.Tag;

public record TagConfigResponseDto
{
    public string Text { get; set; }
    public DateTime? ExpirationTime { get; set; }
    public string Icon { get; set; }
    public string TextColor { get; set; }
    public string BackgroundColor { get; set; }
}
