﻿using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.CrossCuting.Dto.Engagement;

public record ShowcaseResponseDto
{
    public string Id { get; set; }
    public string ExternalId { get; set; }
    public string Name { get; set; }
    public BannerShowcaseStatus Status { get; set; }
    public List<BannerItemDto> Banners { get; set; } = new();
}

public record BannerItemDto
{
    public int Order { get; set; }
    public string RedirectId { get; set; }
    public string UrlRedirect { get; set; }
    public string ImageUrl { get; set; }
    public BannerShowcaseItemType ItemType { get; set; }
}
