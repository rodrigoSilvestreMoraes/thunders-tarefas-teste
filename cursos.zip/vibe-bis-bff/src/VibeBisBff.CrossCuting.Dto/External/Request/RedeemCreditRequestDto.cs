﻿using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.CrossCuting.Dto.External.Request;

public record RedeemCreditRequestDto
{
    public string ParticipantDocument { get; set; }
    public string PinCode { get; set; }
    public string Cellphone { get; set; }
    public bool OptIn { get; set; }
    public string TenantConfigId { get; set; }
    public ApplicationType? AppType { get; set; } = ApplicationType.Vibe;
}
