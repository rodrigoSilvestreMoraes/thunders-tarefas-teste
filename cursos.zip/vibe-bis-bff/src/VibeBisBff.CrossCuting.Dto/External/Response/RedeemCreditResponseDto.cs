﻿namespace VibeBisBff.CrossCuting.Dto.External.Response;

public record RedeemCreditResponseDto
{
    public decimal ReceivedAmount { get; set; }
    public bool Success { get; set; }
}
