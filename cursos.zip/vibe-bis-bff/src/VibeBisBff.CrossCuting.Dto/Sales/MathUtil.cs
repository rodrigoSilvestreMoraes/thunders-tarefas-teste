﻿namespace VibeBisBff.CrossCuting.Dto.Sales;

public static class MathUtil
{
    public static decimal RoundUp(decimal input, int places)
    {
        var multiplier = Convert.ToDecimal(Math.Pow(10, Convert.ToDouble(places)));
        return Convert.ToDecimal(Math.Ceiling(input * multiplier) / multiplier);
    }
}
