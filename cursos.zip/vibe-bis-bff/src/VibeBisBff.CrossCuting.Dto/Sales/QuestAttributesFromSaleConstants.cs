﻿namespace VibeBisBff.CrossCuting.Dto.Sales;
public static class QuestAttributesFromSaleConstants
{
    public const string QUEST_TYPE = "QUEST_TYPE";
    public const string BANNER_IMAGE = "BANNER_IMAGE";
    public const string DETAIL_IMAGE = "DETAIL_IMAGE";
    public const string IS_REGULAR = "IS_REGULAR";
    public const string REDIRECT_LINK = "REDIRECT_LINK";
    public const string LIST_IMAGE = "LIST_IMAGE";
}
