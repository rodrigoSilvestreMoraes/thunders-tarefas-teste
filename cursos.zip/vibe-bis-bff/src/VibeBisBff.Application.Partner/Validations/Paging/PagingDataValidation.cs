﻿using FluentValidation;
using VibeBisBff.CrossCuting.Dto;

namespace VibeBisBff.Application.Partner.Validations.Paging;

public class PagingDataValidation : AbstractValidator<PagingDataDto>
{
    public PagingDataValidation()
    {
        RuleFor(x => x.PageSize).NotNull().WithMessage("O tamanho da página deve ser informado");
        RuleFor(x => x.PageNumber).NotNull().WithMessage("O número da página é obrigatório");
        RuleFor(x => x.PageSize).Must(x => x!.Value > 0).WithMessage("O tamanho da página deve ser maior que zero").When(x => x.PageSize.HasValue);
        RuleFor(x => x.PageNumber).Must(x => x!.Value > 0).WithMessage("O número da página deve ser maior que zero").When(x => x.PageNumber.HasValue);
    }
}
