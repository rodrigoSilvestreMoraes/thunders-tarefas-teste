﻿using FluentValidation;
using VibeBisBff.Dto.Wallet;

namespace VibeBisBff.Application.Partner.Validations.Wallet
{
    public class ExtractExpirationPointsRequestValidation : AbstractValidator<ExtractExpirationPointsRequestDto>
    {
        public ExtractExpirationPointsRequestValidation()
        {
            RuleFor(x => x.BeginDate).Must((x, beginDate) => ValidateBeginDate(beginDate)).WithMessage("A data de início deve ser maior que a data atual.");
        }

        private bool ValidateBeginDate(DateTime beginDate) => (beginDate >= DateTime.Now);        
    }
}
