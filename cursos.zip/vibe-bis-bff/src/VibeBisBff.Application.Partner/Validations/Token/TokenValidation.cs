﻿using FluentValidation;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCutting.Constants;

namespace VibeBisBff.Application.Partner.Validations.Token;

public class TokenValidation : AbstractValidator<TokenRequestDto>
{
    public TokenValidation()
    {
        RuleFor(x => x.GrantType)
            .Must(x => x is AuthenticationTypes.OTP_CREDENTIALS or AuthenticationTypes.CLIENT_CREDENTIALS)
            .WithMessage($"GrantType inválido")
            .When(x => x != null);

        RuleFor(x => x.ClientId)
            .NotEmpty()
            .WithMessage($"ClientId é obrigatório quando o GrantType é igual a {AuthenticationTypes.CLIENT_CREDENTIALS}")
            .When(x => x.GrantType == AuthenticationTypes.CLIENT_CREDENTIALS);

        RuleFor(x => x.ClientSecret)
            .NotEmpty()
            .WithMessage($"ClientSecret é obrigatório quando o GrantType é igual a {AuthenticationTypes.CLIENT_CREDENTIALS}")
            .When(x => x.GrantType == AuthenticationTypes.CLIENT_CREDENTIALS);

        RuleFor(x => x.GrantType)
            .NotEmpty()
            .WithMessage($"GrantType é obrigatório");

        RuleFor(x => x.OtpId)
            .NotEmpty()
            .WithMessage($"OtpId é obrigatório quando o GrantType é igual a {AuthenticationTypes.OTP_CREDENTIALS}")
            .When(x => x.GrantType == AuthenticationTypes.OTP_CREDENTIALS);

        RuleFor(x => x.OtpCode)
            .NotEmpty()
            .WithMessage($"OtpCode é obrigatório quando o GrantType é igual a {AuthenticationTypes.OTP_CREDENTIALS}")
            .When(x => x.GrantType == AuthenticationTypes.OTP_CREDENTIALS);
    }
}
