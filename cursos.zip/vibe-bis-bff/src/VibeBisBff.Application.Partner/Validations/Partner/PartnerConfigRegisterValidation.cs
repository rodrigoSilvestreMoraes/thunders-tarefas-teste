﻿using FluentValidation;
using VibePartner.Dto.Request;

namespace VibeBisBff.Application.Partner.Validations.Partner
{
    public class PartnerConfigRegisterValidation : AbstractValidator<PartnerConfigRequestDto>
    {
        public PartnerConfigRegisterValidation()
        {
            RuleFor(x => x.Name).NotEmpty().WithMessage("O campo Name é obrigatório.");
            RuleFor(x => x.ClientId).NotEmpty().WithMessage("O campo ClientId é obrigatório.");
            RuleFor(x => x.KeyVaultClientSecretKey).NotEmpty().WithMessage("O campo KeyVaultClientSecretKey é obrigatório.");
            RuleFor(x => x.EngagementCampaignId).NotEmpty().WithMessage("O campo EngagementCampaignId é obrigatório.");
            RuleFor(x => x.EngagementRaffleCampaignId).NotEmpty().WithMessage("O campo EngagementRaffleCampaignId é obrigatório.");
            RuleFor(x => x.EngagementStoreId).NotEmpty().WithMessage("O campo EngagementStoreId é obrigatório.");
            RuleFor(x => x.ShopMarketplaceShowCaseId).NotEmpty().WithMessage("O campo ShopMarketplaceShowCaseId é obrigatório.");
            RuleFor(x => x.BenefitsMarketplaceShowCaseId).NotEmpty().WithMessage("O campo BenefitsMarketplaceShowCaseId é obrigatório.");            
        }
    }
}
