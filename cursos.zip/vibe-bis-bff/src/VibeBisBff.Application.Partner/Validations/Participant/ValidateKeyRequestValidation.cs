﻿using FluentValidation;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Partner.Validations.Participant;

public class ValidateKeyRequestValidation : AbstractValidator<ValidateKeyBaseRequestDto>
{
    public ValidateKeyRequestValidation()
    {
        RuleFor(x => x.KeyType)
            .NotEmpty()
            .WithMessage("O tipo de chave deve ser específicado")
            .IsInEnum()
            .WithMessage("O tipo de chave específicado é inválido");

        RuleFor(x => x.Value)
            .NotEmpty()
            .WithMessage("O valor da chave específicado é inválido");
    }
}
