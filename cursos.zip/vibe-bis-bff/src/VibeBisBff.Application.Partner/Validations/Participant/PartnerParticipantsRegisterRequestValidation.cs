﻿using FluentValidation;
using VibeBisBff.CrossCuting.Dto.Participants.Request;


namespace VibeBisBff.Application.Partner.Validations.Participant;

public class PartnerParticipantsRegisterRequestValidation : AbstractValidator<ParticipantsRegisterBaseRequestDto>
{
    private const int CELLPHONE_CORRECT_LENGTH = 13;

    public PartnerParticipantsRegisterRequestValidation()
    {
        RuleFor(x => x.Cellphone).NotEmpty().WithMessage("O campo de celular é obrigatório");
        RuleFor(x => x.Cellphone).Must(item => (item?.Length ?? 0) == CELLPHONE_CORRECT_LENGTH).WithMessage("O campo de celular deve seguir o formato 5599000000000");
        RuleFor(x => x.Document).NotEmpty().WithMessage("O campo de documento é obrigatório");
        RuleFor(x => x.Email).NotEmpty().WithMessage("O campo de e-mail é obrigatório");
        RuleFor(x => x.UseTerms).NotNull().WithMessage("O campo de temos de uso é obrigatório");
        RuleFor(x => x.UseTerms.AcceptedAppUseTerms).Must(acceptedAppUseTerms => acceptedAppUseTerms)
            .WithMessage("É necessário aceitar os termos de uso");
        RuleFor(x => x.UseTerms.AcceptedPrivacyPolicy).Must(acceptedPrivacyPolicy => acceptedPrivacyPolicy)
            .WithMessage("É necessário aceitar a política de privacidade");        
    }
}
