﻿using AutoMapper;
using Common.Core.Exceptions;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Vertem.WalletVertem.Dto;
using VibePartner.Dto.Wallets.Response;

namespace VibeBisBff.Application.Partner.Mappers.Wallets;
public class ExtractParticipantProfile : Profile
{
    public ExtractParticipantProfile()
    {
        CreateMap<ParticipantExtractItemExternalServiceResponseDto, ExtractParticipantResponseDto>()
            .ForMember(dest => dest.TotalCredits, opt => opt.MapFrom(src => src.EndingBalance))
            .ForMember(dest => dest.Operations, opt => opt.MapFrom(src => src.Transactions));

        CreateMap<ParticipantExtractTransactionExternalServiceResponseDto, ExtractResponseDto>()
            .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.Description))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Amount))
            .ForMember(dest => dest.Type, opt => opt.MapFrom((src, dest) =>
            {
                return GetParticipantExtractType(src.Type);
            }))
            .ForMember(dest => dest.Date, opt => opt.MapFrom(src => src.TransactionDate));
    }

    private static ParticipantExtractType GetParticipantExtractType(string type)
    {
        if (string.IsNullOrEmpty(type))
            throw new BusinessException("Invalid participant extract type");

        type = type.ToLower().Trim();

        switch (type)
        {
            case "deposit":
                return ParticipantExtractType.Deposit;
            case "authorization":
                return ParticipantExtractType.Redemption;
            case "cancellation":
                return ParticipantExtractType.Cancellation;
            case "reversal":
                return ParticipantExtractType.Reversal;
            default:
                throw new BusinessException("Invalid participant extract type");
        }
    }
}
