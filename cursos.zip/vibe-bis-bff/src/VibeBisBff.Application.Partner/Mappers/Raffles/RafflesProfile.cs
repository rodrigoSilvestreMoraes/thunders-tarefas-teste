﻿using AutoMapper;
using VibeBisBff.CrossCuting.Dto.Raffles;
using VibeBisBff.CrossCuting.Dto.Raffles.Aggregation;
using VibePartner.Dto.Raffles.Response;

namespace VibeBisBff.Application.Partner.Mappers.Raffles
{
    public  class RaffleProfile : Profile
    {
        public RaffleProfile()
        {
            CreateMap<RaffleGroupAggregationDto, RaffleGroupDto>();
            CreateMap<RaffleAggregationDto, RaffleDto>();
        }

        public static RafflesResponseDto Map(RaffleGroupDto raffleGroupDto, string productImageBaseUrlForBenefits)
        {
            var raffleGroup = new RafflesResponseDto
            {
                Id = raffleGroupDto.Id,
                Title = raffleGroupDto.Title,
                FullRegulationUrl = raffleGroupDto.FullRegulationUrl,
                SummaryRegulation = raffleGroupDto.SummaryRegulation,
                SpentBalance = new RaffleSpentBalanceResponseDto
                {
                    CurrentAccumulatedInVirtualCoins = raffleGroupDto.SpentBalance.CurrentAccumulatedInVirtualCoins,
                    RemainingVirtualCoinsToReceiveLuckyNumber = raffleGroupDto.SpentBalance.RemainingVirtualCoinsToReceiveLuckyNumber
                    
                },
                Images = new List<VibePartner.Dto.AdvertisementImageResponseDto>
                {
                   new() { Tag = "detail", Url = GetProductImageUrlFromSku(raffleGroupDto.DetailImageUrl, "detail", productImageBaseUrlForBenefits) },
                   new() { Tag = "banner", Url = GetProductImageUrlFromSku(raffleGroupDto.BannerImageUrl, "banner", productImageBaseUrlForBenefits) }
                },               

            };
            if (raffleGroupDto != null && raffleGroupDto.Raffles.Any())
                raffleGroupDto.Raffles.ForEach((raffle) =>
                {
                    raffleGroup.LuckyNumbers.Add(new RaffleLuckyNumbersResponseDto
                    {
                         StartDate = raffle.StartDate,
                         EndDate  = raffle.EndDate,
                         IsWinner = raffle.Status == CrossCutting.Enums.RaffleStatus.Winner,
                         Number = raffle.LuckyNumberAwarded,
                         ReceivedLuckyNumbers = raffle.ReceivedLuckyNumbers
                    });
                });

            return raffleGroup;
        }
        private static string GetProductImageUrlFromSku(string skuId, string imageDestiny, string productImageBaseUrlForBenefits) =>
        $"{productImageBaseUrlForBenefits}/{skuId}_{imageDestiny}.png";
    }    
}
