﻿using AutoMapper;
using VibeBisBff.Domain.Entities.Partner;
using VibePartner.Dto.Response;

namespace VibeBisBff.Application.Partner.Mappers;

public class PartnerConfigProfile : Profile
{
    public PartnerConfigProfile()
    {
        CreateMap<PartnerConfig, PartnerConfigResponseDto>();
    }
}
