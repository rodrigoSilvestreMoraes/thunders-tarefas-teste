﻿using AutoMapper;
using VibeBisBff.ExternalServices.Tradeback.SpendingBehaviorManagement.Dto;
using VibePartner.Dto.Quests.Response;

namespace VibeBisBff.Application.Partner.Mappers.Quest;
public class QuestSpendingProfile : Profile
{
    public QuestSpendingProfile()
    {

        CreateMap<SpentDetailResponseDto, QuestSpendingResponseDto > ()
        .ForMember(dest => dest.PrizeLimitReached, opt => opt.MapFrom(src => src.PrizeLimitReached))
        .ForMember(dest => dest.TotalValueToBeRewarded, opt => opt.MapFrom(src => src.Balance))
        .ForMember(dest => dest.RemainingSpendToBeRewarded, opt => opt.MapFrom(src => src.RemainingSpendToBeRewarded))
        .ForMember(dest => dest.TotalSpending, opt => opt.MapFrom(src => src.TotalSpending));
    }
}
