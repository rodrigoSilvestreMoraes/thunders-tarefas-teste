﻿using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Partner.Mappers.Participant;

public static class ParticipantAddressProfile
{
    public static ParticipantAddressDto MapAddressPartnerForVibe(this ParticipantAddressDto participantAddressDto)
    {
        return new ParticipantAddressDto
        {
            City = participantAddressDto.City,
            Complement = participantAddressDto.Complement,
            Country = participantAddressDto.Country,
            District = participantAddressDto.District,
            Number = participantAddressDto.Number,
            PostalCode = participantAddressDto.PostalCode,
            Reference = participantAddressDto.Reference,
            State = participantAddressDto.State,
            Street = participantAddressDto.Street
        };
    }
}
