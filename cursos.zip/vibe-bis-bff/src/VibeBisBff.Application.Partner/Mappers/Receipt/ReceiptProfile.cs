﻿using AutoMapper;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer.Dto;
using VibePartner.Dto.Quests.Response.Receipt;

namespace VibeBisBff.Application.Partner.Mappers.Receipt;
public class ReceiptProfile : Profile
{
    public ReceiptProfile()
    {

        CreateMap<ReceiptResponseExternalServiceDto, QuestTotalReceiptResponseDto>() // Source / Destination
            .ForMember(dest => dest.TotalItems, opt => opt.MapFrom(src => src.NumberOfRows))
            .ForMember(dest => dest.Items, opt => opt.MapFrom(src => src.Data));
    }
}
