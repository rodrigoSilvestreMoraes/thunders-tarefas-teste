﻿using VibeBisBff.ExternalServices.PartnerHub.Voucher.Dto;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Extensions;

public static class VoucherBenefitResponseDtoExtensions
{
    public static VoucherBenefitResponseDto ToVoucherResponse(this VoucherDataDto benefitVoucher, DateTime redeemedDate, int expirationDays)
    {
        var hasVoucherCode = !string.IsNullOrEmpty(benefitVoucher?.Data?.VoucherCode);

        return new VoucherBenefitResponseDto
        {
            HasVoucherCode = true, //TODO: Futuramente, tratar para retornar false se o código do voucher não vier
            VoucherCode = !hasVoucherCode ? "Código do cupom enviado por e-mail." : benefitVoucher.Data.VoucherCode,
            StartDate = redeemedDate,
            ExpirationDays = expirationDays
        };
    }
}
