﻿using ErrorOr;
using VibePartner.Dto.Request;
using VibePartner.Dto.Response;

namespace VibeBisBff.Application.Partner.Usecases.Partner.InsertPartner;
public interface IInsertPartnerUseCase
{
    Task<ErrorOr<PartnerConfigInsertResponseDto>> Execute(PartnerConfigRequestDto partnerConfigRequestDto);
}
