﻿using ErrorOr;
using FluentValidation;
using VibeBisBff.Domain.Entities.Partner;
using VibeBisBff.Domain.Repositories.MongoDb.Partner;
using VibeBisBff.Infra.KeyVault;
using VibePartner.Dto.Request;
using VibePartner.Dto.Response;

namespace VibeBisBff.Application.Partner.Usecases.Partner.InsertPartner;
public class InsertPartnerUseCase : IInsertPartnerUseCase
{
    private readonly IKeyVaultClientManager _keyVaultClientManager;
    private readonly IPartnerRepository _partnerRepository;
    private readonly IValidator<PartnerConfigRequestDto> _validation;

    public InsertPartnerUseCase(
        IKeyVaultClientManager keyVaultClientManager,
        IPartnerRepository partnerRepository,
        IValidator<PartnerConfigRequestDto> validator)
    {
        _keyVaultClientManager = keyVaultClientManager;
        _partnerRepository = partnerRepository;
        _validation = validator;
    }

    public async Task<ErrorOr<PartnerConfigInsertResponseDto>> Execute(PartnerConfigRequestDto request)
    {
        var validationResult = await _validation.ValidateAsync(request);
        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        //TODO: Validar se existe um parceiro com o mesmo client

        var resultKeyVaultInsert = await _keyVaultClientManager.SetSecret(PartnerConfigRequestDto.GetKeyForKeyVault(request.Name), request.KeyVaultClientSecretKey);
        if (!resultKeyVaultInsert)
            return Error.Failure("422", "Falha ao gerar key vault");


        var partner = PartnerConfig.BuilderCreate(request);
        return await _partnerRepository.Insert(partner);
    }
}
