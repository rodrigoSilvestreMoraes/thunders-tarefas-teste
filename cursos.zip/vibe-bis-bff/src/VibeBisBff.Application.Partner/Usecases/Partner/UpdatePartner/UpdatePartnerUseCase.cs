﻿using ErrorOr;
using FluentValidation;
using VibeBisBff.Domain.Entities.Partner;
using VibeBisBff.Domain.Repositories.MongoDb.Partner;
using VibeBisBff.Infra.KeyVault;
using VibePartner.Dto.Request;

namespace VibeBisBff.Application.Partner.Usecases.Partner.UpdatePartner;
public class UpdatePartnerUseCase : IUpdatePartnerUseCase
{
    private readonly IPartnerRepository _partnerRepository;
    private readonly IValidator<PartnerConfigUpdateDto> _validation;
    private readonly IKeyVaultClientManager _keyVaultClientManager;

    public UpdatePartnerUseCase(
        IKeyVaultClientManager keyVaultClientManager,
        IPartnerRepository partnerRepository,
        IValidator<PartnerConfigUpdateDto> validation)
    {
        _keyVaultClientManager = keyVaultClientManager;
        _partnerRepository = partnerRepository;
        _validation = validation;
    }

    public async Task<ErrorOr<Success>> Execute(PartnerConfigUpdateDto request)
    {
        var validationResult = await _validation.ValidateAsync(request);
        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var partner = await _partnerRepository.GetById(request.Id);
        if(partner is null)
            return Error.NotFound(description: "Não foi encontrado partner na base.");

        var resultKeyVaultInsert = await _keyVaultClientManager.SetSecret(PartnerConfigRequestDto.GetKeyForKeyVault(request.Name),
            request.KeyVaultClientSecretKey);

        if (!resultKeyVaultInsert)
            return Error.Failure("422", "Falha ao gerar key vault");
        

        var tenantUpdate = PartnerConfig.BuilderUpdate(request.Id, request);
        await _partnerRepository.Update(tenantUpdate);

        return Result.Success;
    }
}
