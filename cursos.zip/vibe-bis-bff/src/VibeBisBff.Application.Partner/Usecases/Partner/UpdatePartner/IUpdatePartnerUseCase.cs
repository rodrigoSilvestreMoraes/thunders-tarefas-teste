﻿using ErrorOr;
using VibePartner.Dto.Request;

namespace VibeBisBff.Application.Partner.Usecases.Partner.UpdatePartner;
public interface IUpdatePartnerUseCase
{
    Task<ErrorOr<Success>> Execute(PartnerConfigUpdateDto partnerConfigUpdate);
}
