﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartner;
using VibeBisBff.Infra.Extensions;
using VibePartner.Dto.Response;

namespace VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
public class GetPartnerAuthenticateUseCase : IGetPartnerAuthenticateUseCase
{
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IGetPartnerUseCase _getPartnerUseCase;

    public GetPartnerAuthenticateUseCase(
        IGetPartnerUseCase getPartnerUseCase,
        AuthenticatedUser authenticatedUser)
    {
        _getPartnerUseCase = getPartnerUseCase;
        _authenticatedUser = authenticatedUser;
    }

    public string GetClientId()
    {
        var clientId = _authenticatedUser.GetClientId();
        if (string.IsNullOrEmpty(clientId.Value))
            throw new BusinessException("client id não encontrada.");

        return clientId.Value;
    }

    public async Task<PartnerConfigResponseDto> GetPartnerConfig()
    {
        var partnerConfig = await _getPartnerUseCase.ExecuteByClientId(GetClientId());
        if (partnerConfig is null)
            throw new BusinessException("partner config não encontrado.");

        return partnerConfig;
    }
}
