﻿using VibePartner.Dto.Response;

namespace VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
public interface IGetPartnerAuthenticateUseCase
{
    string GetClientId();
    Task<PartnerConfigResponseDto> GetPartnerConfig();
}
