﻿using VibePartner.Dto.Response;

namespace VibeBisBff.Application.Partner.Usecases.Partner.GetPartner;
public interface IGetPartnerUseCase
{
    Task<PartnerConfigResponseDto> Execute(string partnerId);
    Task<PartnerConfigResponseDto> ExecuteByClientId(string clientId);
}
