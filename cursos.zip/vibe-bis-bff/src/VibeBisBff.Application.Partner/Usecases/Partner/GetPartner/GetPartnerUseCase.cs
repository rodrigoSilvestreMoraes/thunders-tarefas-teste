﻿using AutoMapper;
using VibeBisBff.Domain.Entities.Partner;
using VibeBisBff.Domain.Repositories.MongoDb.Partner;
using VibePartner.Dto.Response;

namespace VibeBisBff.Application.Partner.Usecases.Partner.GetPartner;
public class GetPartnerUseCase : IGetPartnerUseCase
{
    readonly IPartnerRepository _partnerRepository;
    private readonly IMapper _mapper;
    public GetPartnerUseCase(IPartnerRepository partnerRepository, IMapper mapper)
    {
        _partnerRepository = partnerRepository;
        _mapper = mapper;
    }

    public async Task<PartnerConfigResponseDto> Execute(string partnerId)
    {
        var partner = await _partnerRepository.GetById(partnerId);
        if (partner == null)
            return null;

        return _mapper.Map<PartnerConfig, PartnerConfigResponseDto>(partner);
    }

    public async Task<PartnerConfigResponseDto> ExecuteByClientId(string clientId)
    {
        var partner = await _partnerRepository.GetByClientId(clientId);
        if (partner == null)
            return null;

        return _mapper.Map<PartnerConfig, PartnerConfigResponseDto>(partner);
    }
}
