﻿using VibePartner.Dto.Wallets.Request;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.RedemptionCancel;
public interface IRedemptionCancelUseCase
{
    Task Execute(WalletRedemptionConfirmRequestDto walletRedemptionConfirmRequestDto);
}
