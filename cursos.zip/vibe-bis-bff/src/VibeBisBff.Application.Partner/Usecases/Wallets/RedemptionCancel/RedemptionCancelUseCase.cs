﻿using Common.Core.Exceptions;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibePartner.Dto.Wallets.Request;
using VibeBisBff.ExternalServices.Tradeback.Authorizer;
using VibeBisBff.ExternalServices.Tradeback.Authorizer.Dto;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.RedemptionCancel;

public class RedemptionCancelUseCase : IRedemptionCancelUseCase
{
    private readonly ITradebackAuthorizerExternalService _tradebackAuthorizerExternalService;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    public RedemptionCancelUseCase(
        ITradebackAuthorizerExternalService tradebackAuthorizerExternalService,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase)
    {
        _tradebackAuthorizerExternalService = tradebackAuthorizerExternalService;
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
    }
    public async Task Execute(WalletRedemptionConfirmRequestDto walletRedemptionConfirmRequestDto)
    {
        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        await _tradebackAuthorizerExternalService.CancelBenefit(new CartFinalizeOperationRequestDto
           {
               MerchantId = partnerConfig.EngagementStoreId,
               MerchantTransactionId = walletRedemptionConfirmRequestDto.PartnerTransactionId,
               PartnerTransactionId = walletRedemptionConfirmRequestDto.PartnerTransactionId,
               TransactionId = walletRedemptionConfirmRequestDto.TransactionId
           }, CrossCutting.Enums.ApplicationType.Vibe);
    }
}
