﻿using VibePartner.Dto.Wallets.Request;
using VibePartner.Dto.Wallets.Response;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.RedemptionPinVerification;
public interface IRedemptionPinVerificationUseCase
{
    Task<WalletRedemptionPinVerificationResponseDto> Execute(WalletRedemptionOtpRequestDto walletRedemptionOtpRequestDto);
}
