﻿using Common.Core.Exceptions;
using VibeBisBff.Application.Partner.Usecases.Wallets.RedemptionConfirm;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibePartner.Dto.Wallets.Request;
using VibePartner.Dto.Wallets.Response;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.RedemptionPinVerification;
public class RedemptionPinVerificationUseCase : IRedemptionPinVerificationUseCase
{
    private readonly IRedemptionConfirmUseCase _redemptionConfirmUseCase;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    
    public RedemptionPinVerificationUseCase(
        IRedemptionConfirmUseCase redemptionConfirmUseCase,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService)
    {
        _redemptionConfirmUseCase = redemptionConfirmUseCase;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;    
    }

    public async Task<WalletRedemptionPinVerificationResponseDto> Execute(WalletRedemptionOtpRequestDto walletRedemptionOtpRequestDto)
    {
        var validateOtp = await _identityAccessManagementExternalService.ValidateOtpCode(walletRedemptionOtpRequestDto.PinId, walletRedemptionOtpRequestDto.Pin);
        if (!validateOtp.Success)
            throw new BusinessException(validateOtp.GetFriendlyErrorMessage());

       var result =  await _redemptionConfirmUseCase.Execute(new WalletRedemptionConfirmRequestDto
        {
             PartnerTransactionId = walletRedemptionOtpRequestDto.PartnerTransactionId,
             TransactionId = walletRedemptionOtpRequestDto.TransactionId
        });

        return new WalletRedemptionPinVerificationResponseDto
        {
            Status = (result ? CrossCutting.Enums.BenefitPartnerStatus.Success : CrossCutting.Enums.BenefitPartnerStatus.Unauthorized)
        };
     }
}
