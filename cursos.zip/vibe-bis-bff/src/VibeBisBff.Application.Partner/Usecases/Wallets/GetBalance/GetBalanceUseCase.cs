﻿using Common.Core.Authentication.Models;
using ErrorOr;
using Microsoft.Extensions.Options;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.ExternalServices.Vertem.WalletVertem;
using VibeBisBff.ExternalServices.Vertem.WalletVertem.Dto;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.GetBalance;
public class GetBalanceUseCase : IGetBalanceUseCase
{
    private readonly IWalletVertemExternalService _walletVertemExternalService;
    private readonly WalletVertemConfigurations _walletVertemConfigurations;
    private readonly AuthenticatedUser _authenticatedUser;

    public GetBalanceUseCase(
        IOptionsSnapshot<WalletVertemConfigurations> walletVertemConfigurations,
        AuthenticatedUser authenticatedUser,
        IWalletVertemExternalService walletVertemExternalService)
    {
        _walletVertemConfigurations = walletVertemConfigurations.Value;
        _authenticatedUser = authenticatedUser;
        _walletVertemExternalService = walletVertemExternalService;
    }

    public async Task<ErrorOr<BalanceResponseDto>> Execute()
    {
        var digitalAccountId =  _authenticatedUser.GetDigitalAccountId();

        var balanceForVirtualCoins = await _walletVertemExternalService.GetBalance(digitalAccountId.Value,
            _walletVertemConfigurations.VirtualCoinsAccountingLedgerId);

        return new BalanceResponseDto { TotalBalance = balanceForVirtualCoins };
    }
}
