﻿using ErrorOr;
using VibeBisBff.ExternalServices.Vertem.WalletVertem.Dto;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.GetBalance;
public interface IGetBalanceUseCase
{
    Task<ErrorOr<BalanceResponseDto>> Execute();
}
