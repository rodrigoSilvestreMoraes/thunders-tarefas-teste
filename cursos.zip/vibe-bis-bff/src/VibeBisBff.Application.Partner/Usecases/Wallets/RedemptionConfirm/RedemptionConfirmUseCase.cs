﻿using Common.Core.Exceptions;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.ExternalServices.Tradeback.Authorizer;
using VibeBisBff.ExternalServices.Tradeback.Authorizer.Dto;
using VibePartner.Dto.Wallets.Request;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.RedemptionConfirm;
public class RedemptionConfirmUseCase : IRedemptionConfirmUseCase
{
    private readonly ITradebackAuthorizerExternalService _tradebackAuthorizerExternalService;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;    

    public RedemptionConfirmUseCase(
        ITradebackAuthorizerExternalService tradebackAuthorizerExternalService,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase)
    {
        _tradebackAuthorizerExternalService = tradebackAuthorizerExternalService;
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
    }

    public async Task<bool> Execute(WalletRedemptionConfirmRequestDto walletRedemptionConfirmRequestDto)
    {
        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var result = await
           _tradebackAuthorizerExternalService.ConfirmBenefit(new CartFinalizeOperationRequestDto
           {
                MerchantId = partnerConfig.EngagementStoreId,
                MerchantTransactionId = walletRedemptionConfirmRequestDto.PartnerTransactionId,
                PartnerTransactionId = walletRedemptionConfirmRequestDto.PartnerTransactionId,
                TransactionId = walletRedemptionConfirmRequestDto.TransactionId
           }, CrossCutting.Enums.ApplicationType.Vibe);

        return result.ReturnStatusId == (int)StatusTransactionResponse.Success;
    }
}
