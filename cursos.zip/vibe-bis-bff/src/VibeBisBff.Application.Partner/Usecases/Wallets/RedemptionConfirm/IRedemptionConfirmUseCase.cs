﻿using VibePartner.Dto.Wallets.Request;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.RedemptionConfirm;
public interface IRedemptionConfirmUseCase
{
    Task<bool> Execute(WalletRedemptionConfirmRequestDto walletRedemptionConfirmRequestDto);
}
