﻿using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using FluentValidation;
using Microsoft.Extensions.Options;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Dto.Wallet;
using VibeBisBff.ExternalServices.Vertem.WalletVertem;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.GetExpiration;
public class GetExpirationUseCase : IGetExpirationUseCase
{
    private readonly IWalletVertemExternalService _walletVertemExternalService;
    private readonly IOptionsSnapshot<WalletVertemConfigurations> _walletVertemConfigurations;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IMapper _mapper;
    private IValidator<PagingDataDto> _validatorPaging;
    private IValidator<ExtractExpirationPointsRequestDto> _validatorRequest;

    public GetExpirationUseCase(IWalletVertemExternalService walletVertemExternalService,
        IOptionsSnapshot<WalletVertemConfigurations> walletVertemConfigurations,
        AuthenticatedUser authenticatedUser,
        IMapper mapper,
        IValidator<PagingDataDto> validatorPaging,
        IValidator<ExtractExpirationPointsRequestDto> validatorRequest)
    {
        _walletVertemExternalService = walletVertemExternalService;
        _walletVertemConfigurations = walletVertemConfigurations;
        _authenticatedUser = authenticatedUser;
        _mapper = mapper;
        _validatorPaging = validatorPaging;
        _validatorRequest = validatorRequest;
    }

    public async Task<ErrorOr<PagingDataResponseDto<ExtractExpirationPointsResponseDto>>> Execute(ExtractExpirationPointsRequestDto request,
        PagingDataDto pagingDataDto)
    {
        var validationPagingResult = await _validatorPaging.ValidateAsync(pagingDataDto);
        if (!validationPagingResult.IsValid)
            return validationPagingResult.Errors.ToValidation();

        var validationRequestResult = await _validatorRequest.ValidateAsync(request);
        if (!validationRequestResult.IsValid)
            return validationRequestResult.Errors.ToValidation();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();
        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var participantExtractResult = await _walletVertemExternalService.GetCreditExpire(
            digitalAccountId.Value,
            _walletVertemConfigurations?.Value.VirtualCoinsAccountingLedgerId,
            request.BeginDate);

        if (participantExtractResult.IsError)
            return participantExtractResult.Errors;

        if (participantExtractResult.Value == null || !participantExtractResult.Value.Any())
            return new PagingDataResponseDto<ExtractExpirationPointsResponseDto>();

        var response = new PagingDataResponseDto<ExtractExpirationPointsResponseDto>();

        var extractItems = _mapper.Map<List<CreditExpireDetailResponseDto>, List<ExtractExpirationPointsResponseDto>>(participantExtractResult.Value);
        response.TotalItems = extractItems.Count;

        var skip = pagingDataDto.PageSize * (pagingDataDto.PageNumber - 1);
        extractItems = extractItems.Skip(skip!.Value).Take(pagingDataDto.PageSize!.Value).ToList();
        response.Items = extractItems;

        return response;
    }
}
