﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Tradeback.Authorizer;
using VibeBisBff.ExternalServices.Tradeback.Authorizer.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;
using VibePartner.Dto.Wallets.Request;
using VibePartner.Dto.Wallets.Response;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.CreditRedemption;

public class CreditRedemptionUseCase : ICreditRedemptionUseCase
{
    private readonly ITradebackAuthorizerExternalService _tradebackAuthorizerExternalService;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;

    public CreditRedemptionUseCase(
        ITradebackAuthorizerExternalService tradebackAuthorizerExternalService,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        AuthenticatedUser authenticatedUser,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _tradebackAuthorizerExternalService = tradebackAuthorizerExternalService;
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _authenticatedUser = authenticatedUser;
        _digitalAccountExternalService = digitalAccountExternalService;
    }

    public async Task<CreditRedemptionRerponse> Execute(CreditRedemptionRequest creditRedemptionRequest)
    {
        await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var digitalAccountId =  _authenticatedUser.GetDigitalAccountId();
        if (digitalAccountId.IsError)
            throw new BusinessException("Participante não encontrado");

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value, ApplicationType.Vibe);
        if (digitalAccount is null)
            throw new BusinessException("Participante não encontrado");

        List<CartProductItemDto> credits = new List<CartProductItemDto>();
        credits.Add(new CartProductItemDto
        {
             UnitaryValue = creditRedemptionRequest.Cost,
             Quantity = 1,
             Description = creditRedemptionRequest.Description,
             ProductCode = creditRedemptionRequest.ProductCode,
        });

        var transactionResponse = await _tradebackAuthorizerExternalService.GenerateAndConfirmBenefit(
        digitalAccount.UserDocument,
        creditRedemptionRequest.StoreId,
        new[] { int.Parse(creditRedemptionRequest.CampaignId) },
        credits.ToArray(),
        creditRedemptionRequest.PartnerTransactionId, appType: ApplicationType.Vibe);

        return new CreditRedemptionRerponse
        {
            Status = transactionResponse.ReturnStatusId == (int)StatusTransactionResponse.Success ? BenefitPartnerStatus.Success : BenefitPartnerStatus.Unauthorized,
            TransactionId = transactionResponse.TransactionId
        };
    }
}
