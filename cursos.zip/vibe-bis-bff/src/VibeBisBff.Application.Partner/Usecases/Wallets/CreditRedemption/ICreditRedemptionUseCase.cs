﻿using VibePartner.Dto.Wallets.Response;
using VibePartner.Dto.Wallets.Request;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.CreditRedemption;

public interface ICreditRedemptionUseCase
{
    Task<CreditRedemptionRerponse> Execute(CreditRedemptionRequest creditRedemptionRequest);
}
