﻿using VibePartner.Dto.Wallets.Request;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.RedemptionReversal;
public interface IRedemptionReversalUseCase
{
    Task Execute(WalletRedemptionConfirmRequestDto walletRedemptionConfirmRequestDto);
}
