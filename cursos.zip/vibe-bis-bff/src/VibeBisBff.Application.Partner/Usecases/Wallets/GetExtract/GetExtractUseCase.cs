﻿using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using Microsoft.Extensions.Options;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.ExternalServices.Vertem.WalletVertem;
using VibeBisBff.ExternalServices.Vertem.WalletVertem.Dto;
using VibeBisBff.Infra.Extensions;
using VibePartner.Dto.Wallets.Request;
using VibePartner.Dto.Wallets.Response;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.GetExtract;

public class GetExtractUseCase : IGetExtractUseCase
{
    private readonly IWalletVertemExternalService _walletVertemExternalService;
    private readonly WalletVertemConfigurations _walletVertemConfigurations;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IMapper _mapper;

    public GetExtractUseCase(
        IWalletVertemExternalService walletVertemExternalService,
        IOptionsSnapshot<WalletVertemConfigurations> walletVertemConfigurations,
        AuthenticatedUser authenticatedUser,
        IMapper mapper)
    {
        _walletVertemExternalService = walletVertemExternalService;
        _walletVertemConfigurations = walletVertemConfigurations.Value;
        _authenticatedUser = authenticatedUser;
        _mapper = mapper;
    }

    //TODO: Mudei o retorno para ter o total de saldo igual o original
    public async Task<ErrorOr<List<ExtractResponseDto>>> Execute(ExtractRequestDto extractRequestDto)
    {
        var dateValidation = ValidateStartAndEndDate(extractRequestDto.Start, extractRequestDto.End);

        if (dateValidation.IsError)
            return dateValidation.Errors;

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var participantExtractResult = await _walletVertemExternalService
            .GetExtract(digitalAccountId.Value, _walletVertemConfigurations.VirtualCoinsAccountingLedgerId, extractRequestDto.Start, extractRequestDto.End);

        if (participantExtractResult.IsError)
            return participantExtractResult.Errors;

        if (participantExtractResult.Value.Items == null || !participantExtractResult.Value.Items.Any())
            return new List<ExtractResponseDto>();

        var participantExtracts = _mapper.Map<List<ParticipantExtractItemExternalServiceResponseDto>, List<ExtractParticipantResponseDto>>
            (participantExtractResult.Value.Items);

        var participantExtract = participantExtracts.FirstOrDefault();
        var operations = participantExtract!.Operations.OrderByDescending(x => x.Date).ToList();

        participantExtract!.Operations = ReplaceEncodedDescriptions(operations);

        return participantExtract.Operations;
    }

    private static List<ExtractResponseDto> ReplaceEncodedDescriptions(IEnumerable<ExtractResponseDto> operations)
    {
        var operationAsList = operations?.ToList();
        if (operationAsList is null || !operationAsList.Any())
            return null;

        foreach (var operation in operationAsList)
        {
            //TODO: Retirar 
            operation.Origin = "VIBE";
            operation.Description = operation.Type switch
            {
                ParticipantExtractType.Deposit => "Crédito",
                ParticipantExtractType.Cancellation => "Cancelamento",
                ParticipantExtractType.Reversal => "Estorno",
                _ => operation.Description
            };
        }

        return operationAsList;
    }

    private static ErrorOr<List<ExtractParticipantResponseDto>> ValidateStartAndEndDate(DateTime? start, DateTime? end)
    {
        if (!start.HasValue && !end.HasValue) return new ErrorOr<List<ExtractParticipantResponseDto>>();

        if (start.HasValue && start.Value > DateTime.Now)
            return Error.Validation(description: "A data de início não deve ser maior que a data de hoje");

        if (end.HasValue && end.Value > DateTime.Now)
            return Error.Validation(description: "A data de término não deve ser maior que a data de hoje");

        if (!start.HasValue || !end.HasValue) return new ErrorOr<List<ExtractParticipantResponseDto>>();

        if (start > end)
            return Error.Validation(description: "A data de início não deve ser maior que a data de término");

        return end.Value.Date.Subtract(start.Value.Date).TotalDays > 90
            ? Error.Validation(description: "O intervalo entre a data de ínício e de término não deve ser maior que 90 dias")
            : new ErrorOr<List<ExtractParticipantResponseDto>>();
    }
}
