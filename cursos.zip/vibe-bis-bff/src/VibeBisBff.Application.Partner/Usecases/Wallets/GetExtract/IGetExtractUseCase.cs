﻿using VibePartner.Dto.Wallets.Response;
using ErrorOr;
using VibePartner.Dto.Wallets.Request;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.GetExtract;

public interface IGetExtractUseCase
{
    //TODO: Acho que esse não faz sentido ter paginação conforme a reunião que tivemos com a Meliuz. Foi acordado que eles buscariam de 90 em 90 dias
    Task<ErrorOr<List<ExtractResponseDto>>> Execute(ExtractRequestDto extractRequestDto);
}
