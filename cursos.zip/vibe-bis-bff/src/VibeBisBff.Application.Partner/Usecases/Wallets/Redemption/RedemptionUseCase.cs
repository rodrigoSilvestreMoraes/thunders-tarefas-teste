﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Tradeback.Authorizer;
using VibeBisBff.ExternalServices.Tradeback.Authorizer.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;
using VibePartner.Dto.Wallets.Request;
using VibePartner.Dto.Wallets.Response;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.Redemption;
public class RedemptionUseCase : IRedemptionUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly ITradebackAuthorizerExternalService _tradebackAuthorizerExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    public RedemptionUseCase(
        ITradebackAuthorizerExternalService tradebackAuthorizerExternalService,
        AuthenticatedUser authenticatedUser,
        IDigitalAccountExternalService digitalAccountExternalService,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase)
    {
        _tradebackAuthorizerExternalService = tradebackAuthorizerExternalService;
        _authenticatedUser = authenticatedUser;
        _digitalAccountExternalService = digitalAccountExternalService;
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
    }

    public async Task<ErrorOr<WalletRedemptionResponseDto>> Execute(WalletRedemptionRequestDto walletRedemptionRequestDto)
    {
        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(_authenticatedUser.GetDigitalAccountId().Value, ApplicationType.Vibe);
        if (digitalAccount == null)
            throw new BusinessException("Participante não cadastrado.");

        if (partnerConfig.Has2Fa)
            throw new NotImplementedException();

        var result = await
            _tradebackAuthorizerExternalService.GenerateBenefit(
            digitalAccount.UserDocument,
            partnerConfig.EngagementStoreId,
            walletRedemptionRequestDto.PartnerTransactionId,
            walletRedemptionRequestDto.PartnerTransactionId,
            new List<int> { int.Parse(partnerConfig.EngagementCampaignId) },
            new List<CartProductItemDto>
            {
                new() { ProductCode = walletRedemptionRequestDto.ProductCode,
                        Description = walletRedemptionRequestDto.Description,
                        Quantity = 1,
                        UnitaryValue = walletRedemptionRequestDto.Cost }
            }, ApplicationType.Vibe);

        return new WalletRedemptionResponseDto
        {
            Status = (result.ReturnStatusId == (int)StatusTransactionResponse.Success
                ? CrossCutting.Enums.BenefitPartnerStatus.Success : CrossCutting.Enums.BenefitPartnerStatus.Unauthorized),
            TransactionId = result.TransactionId
        };
    }
}
