﻿using ErrorOr;
using VibePartner.Dto.Wallets.Request;
using VibePartner.Dto.Wallets.Response;

namespace VibeBisBff.Application.Partner.Usecases.Wallets.Redemption;
public interface IRedemptionUseCase
{
    Task<ErrorOr<WalletRedemptionResponseDto>> Execute(WalletRedemptionRequestDto walletRedemptionRequestDto);
}
