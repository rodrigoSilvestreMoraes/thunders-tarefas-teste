﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCutting.Enums;
using VibePartner.Dto.Quests.Response;

namespace VibeBisBff.Application.Partner.Usecases.Quests.GetQuests;
public interface IGetQuestsUsecase
{
    Task<ErrorOr<PagingDataResponseDto<QuestResponseDto>>> Execute(QuestsStatus questsStatus, PagingDataDto pagingDataDto);
}
