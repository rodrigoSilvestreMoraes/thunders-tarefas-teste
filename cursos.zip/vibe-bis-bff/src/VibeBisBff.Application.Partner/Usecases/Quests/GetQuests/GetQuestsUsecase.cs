﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Domain.Entities.Quest;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibePartner.Dto;
using VibePartner.Dto.Quests.Response;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.ExternalServices.Tradeback.Promo.PartnerDecrapt;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto.PartnerDecrapt;
using VibeBisBff.CrossCuting.Dto;

namespace VibeBisBff.Application.Partner.Usecases.Quests.GetQuests;
public class GetQuestsUsecase : IGetQuestsUsecase
{
    private readonly ITradebackPromoExternalServiceV2 _tradebackPromoExternalService;
    private readonly IAccomplishedQuestsRepository _accomplishedQuestsRepository;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    public GetQuestsUsecase(
    ITradebackPromoExternalServiceV2 tradebackPromoExternalService,
    IAccomplishedQuestsRepository accomplishedQuestsRepository,
    AuthenticationProvider authenticationProvider,
    IDigitalAccountExternalService digitalAccountExternalService,
    IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase)
    {
        _tradebackPromoExternalService = tradebackPromoExternalService;
        _accomplishedQuestsRepository = accomplishedQuestsRepository;
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();

        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
    }

    public async Task<ErrorOr<PagingDataResponseDto<QuestResponseDto>>> Execute(QuestsStatus questsStatus, PagingDataDto pagingDataDto)
    {
        var result = new PagingDataResponseDto<QuestResponseDto>();

        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var (accomplishedQuests, _) = await _accomplishedQuestsRepository.GetByDigitalAccountId(digitalAccountId.Value, pagingDataDto);

        var advertisements =
            await GetAdvertisementsFromQuestStatus(accomplishedQuests, questsStatus, digitalAccountId.Value);

        if (advertisements.IsError) return advertisements.Errors;

          var quests = advertisements.Value.Data
            .Where(a => a.Benefit.Credit != null)
            .Select(advertisement => new QuestResponseDto
            {
                Description = advertisement.Description,
                Title = advertisement.Name,
                Id = advertisement.Id,
                Images = new List<AdvertisementImageResponseDto>
                {
                    new AdvertisementImageResponseDto { Tag = "image", Url = advertisement.Image },
                    new AdvertisementImageResponseDto { Tag = "bannerImage", Url = advertisement.BannerImage },
                    new AdvertisementImageResponseDto { Tag = "detailImage", Url = advertisement.DetailImage },
                    new AdvertisementImageResponseDto { Tag = "listImage", Url = advertisement.ListImage }
                },
                Redirect = advertisement.Redirect,
                IsRegular = advertisement.IsRegular,
                Type = advertisement.QuestType,
                Value = advertisement.Benefit.Credit.Amount,
                HasSpending = advertisement.ActivationCondition?.SecondLevelCondition?.SpendingBehavior?.SpendingBehaviorSettingsId != null
            }).ToList();

        RemoveNotRegularAccomplishedQuestsWhenQuestStatusIsAvailable(questsStatus,
            quests,
            accomplishedQuests
        );

        result.TotalItems = quests.Count;
        result.Items = quests;

        return result;
    }

    private static void RemoveNotRegularAccomplishedQuestsWhenQuestStatusIsAvailable(
        QuestsStatus questsStatus,
        List<QuestResponseDto> quests,
        List<AccomplishedQuest> accomplishedQuests)
    {
        if (questsStatus != QuestsStatus.Available)
            return;

        quests?.RemoveAll(q => !q.IsRegular && accomplishedQuests.Any(aq => aq.QuestId == q.Id));
    }

    private async Task<ErrorOr<AdvertisementResponseDto>> GetAdvertisementsFromQuestStatus
        (List<AccomplishedQuest> accomplishedQuests,
        QuestsStatus questsStatus,
        string digitalAccountId)
    {
        var saleIds = new List<string>();

        if (questsStatus == QuestsStatus.Accomplished)
        {
            if (!accomplishedQuests.Any())
                return new AdvertisementResponseDto();

            saleIds = accomplishedQuests.Select(aq => aq.QuestId)?.ToList();
        }

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId, ApplicationType.Vibe);

        //TODO: Questionar sobre essa paginação
        return await _tradebackPromoExternalService.SearchAdvertisements
            (new AdvertisementSearchRequestDtoV2
                (new AdvertisementSearchPaginationDtoV2(99, 1), new AdvertisementSearchFilterDtoV2(saleIds, digitalAccount.UserDocument)));
    }
}
