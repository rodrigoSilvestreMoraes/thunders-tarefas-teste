﻿using ErrorOr;
using VibePartner.Dto.Quests.Response;

namespace VibeBisBff.Application.Partner.Usecases.Quests.GetAccomplishedQuestSpending;
public interface IGetAccomplishedQuestSpendingUseCase
{
    Task<ErrorOr<QuestSpendingResponseDto>> Execute(string questId);
}
