﻿using AutoMapper;
using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.ExternalServices.Tradeback.SpendingBehaviorManagement;
using VibeBisBff.ExternalServices.Tradeback.SpendingBehaviorManagement.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibePartner.Dto.Quests.Response;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.ExternalServices.Tradeback.Promo.PartnerDecrapt;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto.PartnerDecrapt;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.Application.Partner.Usecases.Quests.GetAccomplishedQuestSpending;
public class GetAccomplishedQuestSpendingUseCase : IGetAccomplishedQuestSpendingUseCase
{
    private readonly ITradebackPromoExternalServiceV2 _tradebackPromoExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IAccomplishedQuestsRepository _questsAccomplishedRepository;
    private readonly ITradebackSpendingBehaviorManagementExternalService  _tradebackSpendingBehaviorManagementExternalService;

    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    private readonly IMapper _mapper;

    public GetAccomplishedQuestSpendingUseCase(
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        ITradebackPromoExternalServiceV2 tradebackPromoExternalService,
        IDigitalAccountExternalService digitalAccountExternalService,
        AuthenticatedUser authenticatedUser,
        IAccomplishedQuestsRepository questsAccomplishedRepository,
        ITradebackSpendingBehaviorManagementExternalService tradebackSpendingBehaviorManagementExternalService,
        IMapper mapper)
    {
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _tradebackPromoExternalService = tradebackPromoExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticatedUser;
        _questsAccomplishedRepository = questsAccomplishedRepository;
        _tradebackSpendingBehaviorManagementExternalService = tradebackSpendingBehaviorManagementExternalService;
        _mapper = mapper;
    }

    //TODO: Pedir explicação de como funciona no motor 
    public async Task<ErrorOr<QuestSpendingResponseDto>> Execute(string questId)
    {
        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();
        if (partnerConfig == null) throw new BusinessException("Parceiro não encontrado.");

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var participantDetails = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value, ApplicationType.Vibe);

        var advertisements = await _tradebackPromoExternalService.SearchAdvertisements
        (new AdvertisementSearchRequestDtoV2(new AdvertisementSearchPaginationDtoV2(99, 1),
            new AdvertisementSearchFilterDtoV2(new List<string> { questId }, participantDetails.UserDocument)));

        if (advertisements.IsError) return advertisements.Errors;

        if (!advertisements.Value.Data.Any()) return Error.NotFound(description: "A missão não foi encontrada");

        var advertisement = advertisements.Value.Data.First();

        var settingsId = advertisement.ActivationCondition?.SecondLevelCondition?.SpendingBehavior
            ?.SpendingBehaviorSettingsId;

        if (string.IsNullOrWhiteSpace(settingsId))
            return Error.Validation("A missão informada não possui configurações de valor acumulado associadas");

        var accomplishedQuestSpending =
            await _tradebackSpendingBehaviorManagementExternalService.GetSpentDetail(settingsId,
                participantDetails.UserDocument, ApplicationType.Vibe);

        if (accomplishedQuestSpending.IsError) return accomplishedQuestSpending.Errors;

        var alreadySpentSomething = accomplishedQuestSpending.Value.Any();

        var spendingResult = alreadySpentSomething
            ? _mapper.Map<SpentDetailResponseDto, QuestSpendingResponseDto>
                (accomplishedQuestSpending.Value.Find(x => x.CounterGroupKey.Contains(questId.ToString())))
            : await GetDefaultSpendingResponse(settingsId);

        spendingResult.VirtualCoinsToBeEarned = advertisement.Benefit.Credit.Amount;

        await AppendTotalAccumulatedInVirtualCoinsToResult(
            spendingResult,
            alreadySpentSomething,
            digitalAccountId.Value,
            advertisement.Id);

        return spendingResult;
    }

    private async Task AppendTotalAccumulatedInVirtualCoinsToResult(
        QuestSpendingResponseDto result,
        bool alreadySpentSomething,
        string digitalAccountId,
        string questId)
    {
        if (!alreadySpentSomething)
            return;

        var virtualCoinsEarned = await _questsAccomplishedRepository.GetVirtualCoinsEarnedByDigitalAccountIdAndQuestId(digitalAccountId, questId);

        result.TotalAccumulatedInVirtualCoins = virtualCoinsEarned.Sum(x => x!.Value);
    }

    private async Task<QuestSpendingResponseDto> GetDefaultSpendingResponse(string spendingSettingsId)
    {
        var settings = await _tradebackSpendingBehaviorManagementExternalService.GetSettingsById(spendingSettingsId, ApplicationType.Vibe);

        if (settings.IsError)
            throw new BusinessException(
                "Ops! Houve um problema, mas estamos cuidando disso! Tente novamente mais tarde.");

        return new QuestSpendingResponseDto()
        {
            TotalSpending = 0,
            PrizeLimitReached = false,
            RemainingSpendToBeRewarded = settings.Value.SpentValueToBeRewarded,
            TotalValueToBeRewarded = 0,
            TotalAccumulatedInVirtualCoins = 0
        };
    }
}
