﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Quests.Request;
using VibeBisBff.CrossCuting.Dto.Quests.Response;

namespace VibeBisBff.Application.Partner.Usecases.Quests.Receipt;
public interface IReceiptUseCase
{
    Task<ErrorOr<QuestReceiptResponseDto>> Execute(QuestReceiptRequestDto questReceiptRequestDto);
}
