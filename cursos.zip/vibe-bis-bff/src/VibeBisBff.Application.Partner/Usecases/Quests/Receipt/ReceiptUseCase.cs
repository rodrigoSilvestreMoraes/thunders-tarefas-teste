﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Helpers;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.CrossCuting.Dto.Quests.Response;
using VibeBisBff.CrossCuting.Dto.Quests.Request;

namespace VibeBisBff.Application.Partner.Usecases.Quests.Receipt;
public class ReceiptUseCase : IReceiptUseCase
{
    private readonly IReceiptAuthorizerExternalService _receiptAuthorizerExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public ReceiptUseCase(
        IReceiptAuthorizerExternalService receiptAuthorizerExternalService,
        AuthenticationProvider authenticationProvider,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _receiptAuthorizerExternalService = receiptAuthorizerExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
    }

    public async Task<ErrorOr<QuestReceiptResponseDto>> Execute(QuestReceiptRequestDto questReceiptRequestDto)
    {
        var digitalAccountIdOrError = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountIdOrError.IsError) return digitalAccountIdOrError.Errors;
        var digitalAccount =
            await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountIdOrError.Value, ApplicationType.Vibe);

        var accessKey = questReceiptRequestDto.SendType == ReceiptAuthorizerSendType.QRCode
        ? QrCodeHelper.GetAccessKeyFromQrCode(questReceiptRequestDto.UrlQrCode)
            : questReceiptRequestDto.UrlQrCode;

        var sendReceiptDto = new SendReceiptRequestDto
        {
            SendType = questReceiptRequestDto.SendType,
            UrlQrCode = questReceiptRequestDto.UrlQrCode,
            AppType =  ApplicationType.Vibe
        };

        if (accessKey.Length != 44)
        {
            var resultReceiptAcessKeyDif44 = await _receiptAuthorizerExternalService.SendReceipt(sendReceiptDto, digitalAccount.UserDocument, ApplicationType.Vibe);
            return new QuestReceiptResponseDto { Id = resultReceiptAcessKeyDif44.Value };
        }

        var searchReceiptResult = await _receiptAuthorizerExternalService.SearchReceipt(0, 1,
            digitalAccount.UserDocument, start: null, end: null,  accessKey: accessKey);

        if (searchReceiptResult.Value.NumberOfRows != 0)
            return new QuestReceiptResponseDto { Id = searchReceiptResult.Value.Data[0].Id };

        var resultReceipt =  await _receiptAuthorizerExternalService.SendReceipt(sendReceiptDto, digitalAccount.UserDocument, ApplicationType.Vibe);
        return new QuestReceiptResponseDto { Id = resultReceipt.Value };
    }
}
