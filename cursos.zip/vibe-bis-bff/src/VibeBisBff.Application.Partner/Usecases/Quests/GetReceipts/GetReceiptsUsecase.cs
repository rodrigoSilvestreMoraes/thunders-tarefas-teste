﻿using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibePartner.Dto.Quests.Response.Receipt;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCuting.Dto;

namespace VibeBisBff.Application.Partner.Usecases.Quests.GetReceipts;
public class GetReceiptsUsecase : IGetReceiptsUsecase
{
    private readonly IReceiptAuthorizerExternalService _receiptAuthorizerExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IMapper _mapper;


    public GetReceiptsUsecase(
        IReceiptAuthorizerExternalService receiptAuthorizerExternalService,
        IDigitalAccountExternalService digitalAccountExternalService,
        AuthenticatedUser authenticatedUser,
        IMapper mapper)
    {
        _receiptAuthorizerExternalService = receiptAuthorizerExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticatedUser;
        _mapper = mapper;
    }

    //TODO: Questionar se isso vai funcionar sem informando o ApplicationType  = Vibe
    public async Task<ErrorOr<QuestTotalReceiptResponseDto>> Execute(PagingDataDto pagingDataDto, DateTime? start = null, DateTime? end = null)
    {
        var digitalAccountIdOrError = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountIdOrError.IsError) return digitalAccountIdOrError.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountIdOrError.Value, ApplicationType.Vibe);
                
        var receiptResponseExternalService = await _receiptAuthorizerExternalService.SearchReceipt(
            pagingDataDto.PageNumber!.Value, pagingDataDto.PageSize!.Value, digitalAccount.UserDocument, start, end,string.Empty, ApplicationType.Vibe);

        if (receiptResponseExternalService.IsError) return receiptResponseExternalService.Errors;

        return _mapper.Map<ReceiptResponseExternalServiceDto, QuestTotalReceiptResponseDto>(receiptResponseExternalService.Value);
    }
}
