﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto;
using VibePartner.Dto.Quests.Response.Receipt;

namespace VibeBisBff.Application.Partner.Usecases.Quests.GetReceipts;
public interface IGetReceiptsUsecase
{
    Task<ErrorOr<QuestTotalReceiptResponseDto>> Execute(PagingDataDto pagingDataDto, DateTime? start = null, DateTime? end = null);
}
