﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCuting.Dto.Authentication.Response;

namespace VibeBisBff.Application.Partner.Usecases.Authentication.SendOtp;
public interface ISendOtpUseCase
{
    Task<ErrorOr<TokenOtpResponseDto>> Execute(TokenOtpRequestDto tokenOtpRequestDto);
}
