﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartner;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCuting.Dto.Authentication.Response;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Partner.Usecases.Authentication.SendOtp;

public class SendOtpUseCase : ISendOtpUseCase
{
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IGetPartnerUseCase _getPartnerUseCase;

    public SendOtpUseCase(
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        AuthenticatedUser authenticatedUser,
        IDigitalAccountExternalService digitalAccountExternalService,
        IGetPartnerUseCase getPartnerUseCase)
    {
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _authenticatedUser = authenticatedUser;
        _digitalAccountExternalService = digitalAccountExternalService;
        _getPartnerUseCase = getPartnerUseCase;
    }

    public async Task<ErrorOr<TokenOtpResponseDto>> Execute(TokenOtpRequestDto tokenOtpRequestDto)
    {
        var digitalAccount = await _digitalAccountExternalService.GetDigitalAccountByDocument(tokenOtpRequestDto.Username, ApplicationType.Vibe);
        if(digitalAccount == null)
            throw new BusinessException("Participante não cadastrado.");

        var partnerConfig = await _getPartnerUseCase.ExecuteByClientId(_authenticatedUser.GetClientId().Value);
        if(partnerConfig == null)
            throw new BusinessException("Parceiro não encontrado.");

        var isValid = digitalAccount.DigitalAccountPhones.Any() && digitalAccount.DigitalAccountPhones.Any(x => x.IsValidate);
        var response = await _identityAccessManagementExternalService.SendCellphoneOtp(digitalAccount.GetCellphone(),
            digitalAccount.Id,
            (isValid ? "authentication" : "onboarding"),
            ApplicationType.Vibe);

        return new TokenOtpResponseDto()
        {
             OtpId = response.OtpId,
             OtpSendType = CrossCutting.Enums.OtpSendType.SMS,
             PhoneNumber = digitalAccount.GetMaskCellphone()
        };
    }
}
