﻿using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCuting.Dto.Participants.Response;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.ExternalServices.Vertem.IamClientCredentials;
using VibeBisBff.Infra.KeyVault;

namespace VibeBisBff.Application.Partner.Usecases.Authentication
{
    /// <summary>
    /// Use case temporária para gerar token até o otp está ok
    /// </summary>
    public class TokenForcePosUseCase : ITokenForcePosUseCase
    {
        private readonly IKeyVaultClientManager _keyVaultClientManager;
        private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;
        private readonly IVertemIamTenantService _vertemIamTenantService;

        public TokenForcePosUseCase(IKeyVaultClientManager keyVaultClientManager,
            IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
            IVertemIamTenantService vertemIamTenantService)
        {
            _keyVaultClientManager = keyVaultClientManager;
            _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
            _vertemIamTenantService = vertemIamTenantService;
        }

        public async Task<ParticipantCreateResponseDto> GetToken(string digitalAccountId)
        {
            var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();
            var clientSecret = await _keyVaultClientManager.GetSecret(partnerConfig.KeyVaultClientSecretKey);

            var token = await _vertemIamTenantService.GetAccessTokenForByPos(
                new LoginCredential
                {
                    ClientId = partnerConfig.ClientId,
                    ClientSecret = clientSecret

                }, digitalAccountId: digitalAccountId);


            return new ParticipantCreateResponseDto
            {
                AccessToken = token.Value.AccessToken,
                DigitalAccountId = digitalAccountId,
                RefreshToken = token.Value.RefreshToken,
                ExpiresIn = token.Value.ExpiresIn,
                Scope = token.Value.Scope,
                TokenType = token.Value.TokenType
            };
        }
    }
}
