﻿using Common.Core.Exceptions;
using ErrorOr;
using FluentValidation;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartner;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCuting.Dto.Authentication.Response;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IamClientCredentials;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Mappers.Token;

namespace VibeBisBff.Application.Partner.Usecases.Authentication.Token;

public class TokenUseCase : ITokenUseCase
{
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly IVertemIamTenantService _vertemIamTenantService;
    private readonly IValidator<TokenRequestDto> _validation;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IGetPartnerUseCase _getPartnerUseCase;

    public TokenUseCase(
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        IValidator<TokenRequestDto> validator,
        IGetPartnerUseCase getPartnerUseCase,
        IDigitalAccountExternalService digitalAccountExternalService,
        IVertemIamTenantService vertemIamTenantService)
    {
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _validation = validator;
        _getPartnerUseCase = getPartnerUseCase;
        _digitalAccountExternalService = digitalAccountExternalService;
        _vertemIamTenantService = vertemIamTenantService;
    }

    public async Task<ErrorOr<TokenResponseDto>> Token(TokenRequestDto tokenRequestDto)
    {
        var validationResult = await _validation.ValidateAsync(tokenRequestDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var partner = await _getPartnerUseCase.ExecuteByClientId(tokenRequestDto.ClientId);

        if (partner == null)
            throw new BusinessException("Parceiro não existe!");

        return tokenRequestDto.GrantType switch
        {
            AuthenticationTypes.CLIENT_CREDENTIALS =>
                await GenerateTokenByClientCredentialsFlow(tokenRequestDto),
            AuthenticationTypes.OTP_CREDENTIALS =>
                await GenerateTokenByOtpCredentialsFlow(tokenRequestDto),
            _ => throw new BusinessException("O tipo de grantType informado é inválido")
        };
    }

    private async Task<TokenResponseDto> GenerateTokenByClientCredentialsFlow(
        TokenRequestDto tokenRequestDto)
    {
        if (tokenRequestDto.GrantType != AuthenticationTypes.CLIENT_CREDENTIALS)
            return null;

        var token = await _vertemIamTenantService.GetObjectAccessTokenForClientCredentials(
            tokenRequestDto.ClientId, tokenRequestDto.ClientSecret);

        return token.MapToGenerateToken();
    }

    private async Task<TokenResponseDto> GenerateTokenByOtpCredentialsFlow(TokenRequestDto tokenRequestDto)
    {
        if (tokenRequestDto.GrantType != AuthenticationTypes.OTP_CREDENTIALS)
            return null;

        var digitalAccount = await _digitalAccountExternalService.GetDigitalAccountByDocument(tokenRequestDto.Username, ApplicationType.Vibe);

        if (digitalAccount == null)
            throw new BusinessException("Participante não cadastrado.");

        var isValid = digitalAccount.DigitalAccountPhones.Any() && digitalAccount.DigitalAccountPhones.Any(x => x.IsValidate);

        if (!isValid)
            return await GenerateTokenOnboarding(tokenRequestDto, digitalAccount.Id);

        return await GenerateToken(tokenRequestDto);
    }

    private async Task<TokenResponseDto> GenerateTokenOnboarding(TokenRequestDto tokenRequestDto, string digitalAccountId)
    {
        var validateOtp = await _identityAccessManagementExternalService.ValidateOtpCode(tokenRequestDto.OtpId, tokenRequestDto.OtpCode, "onboarding", appType: ApplicationType.Vibe);

        if (!validateOtp.Success)
            throw new BusinessException(validateOtp.GetFriendlyErrorMessage()!);

        var token = await _vertemIamTenantService.GetAccessTokenForByPos(
                new LoginCredential
                {
                    ClientId = tokenRequestDto.ClientId,
                    ClientSecret = tokenRequestDto.ClientSecret

                }, digitalAccountId: digitalAccountId);

        return token.Value.MapToGenerateToken();
    }
    async Task<TokenResponseDto> GenerateToken(TokenRequestDto tokenRequestDto)
    {
        var token = await _vertemIamTenantService.GetObjectAccessTokenForOtpCredentials(tokenRequestDto);
        return token.MapToGenerateToken();
    }
}
