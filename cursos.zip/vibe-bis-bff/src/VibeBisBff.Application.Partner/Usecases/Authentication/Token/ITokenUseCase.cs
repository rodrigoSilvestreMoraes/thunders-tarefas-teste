﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCuting.Dto.Authentication.Response;

namespace VibeBisBff.Application.Partner.Usecases.Authentication.Token;
public interface ITokenUseCase
{
    Task<ErrorOr<TokenResponseDto>> Token(TokenRequestDto tokenRequestDto);
}
