﻿using VibeBisBff.CrossCuting.Dto.Participants.Response;

namespace VibeBisBff.Application.Partner.Usecases.Authentication
{
    public interface ITokenForcePosUseCase 
    {
        Task<ParticipantCreateResponseDto> GetToken(string digitalAccountId);
    }
}
