﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCuting.Dto.Authentication.Response;

namespace VibeBisBff.Application.Partner.Usecases.Authentication.RefeshToken;
public interface IRefreshTokenUseCase
{
    Task<ErrorOr<TokenResponseDto>> RefreshToken(TokenRefreshRequestDto tokenRefresh);
}
