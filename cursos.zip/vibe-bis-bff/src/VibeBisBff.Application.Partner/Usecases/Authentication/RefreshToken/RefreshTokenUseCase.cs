﻿using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Authentication.RefeshToken;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCuting.Dto.Authentication.Response;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.ExternalServices.Vertem.IamClientCredentials;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Mappers.Token;

namespace VibeBisBff.Application.Partner.Usecases.Authentication.RefreshToken;

public class RefreshTokenUseCase : IRefreshTokenUseCase
{
    private readonly IVertemIamTenantService _vertemIamTenantService;

    public RefreshTokenUseCase(IVertemIamTenantService vertemIamTenantService)
    {
        _vertemIamTenantService = vertemIamTenantService;
    }

    public async Task<ErrorOr<TokenResponseDto>> RefreshToken(TokenRefreshRequestDto tokenRefresh)
    {
        var token = await _vertemIamTenantService.RefreshToken(
            tokenRefresh.RefreshToken,
            new LoginCredential
                { ClientId = tokenRefresh.ClientId, ClientSecret = tokenRefresh.ClientSecret });

        return token.Value.MapToRefreshToken();
    }
}
