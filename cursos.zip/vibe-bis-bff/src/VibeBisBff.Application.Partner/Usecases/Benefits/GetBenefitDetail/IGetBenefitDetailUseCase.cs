﻿using ErrorOr;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.GetBenefitDetail;
public interface IGetBenefitDetailUseCase
{
    Task<ErrorOr<BenefitListResponseDto>> Execute(string benefitId);
}
