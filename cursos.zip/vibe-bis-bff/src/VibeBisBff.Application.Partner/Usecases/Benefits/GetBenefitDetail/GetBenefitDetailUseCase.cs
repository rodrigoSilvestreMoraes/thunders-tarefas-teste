﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Benefits.GetBenefits;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.Dto.Benefit;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;
using VibePartner.Dto;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.GetBenefitDetail;

public class GetBenefitDetailUseCase : IGetBenefitDetailUseCase
{
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly ITradebackPromoExternalService _promoExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;

    public GetBenefitDetailUseCase(
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        AuthenticatedUser authenticatedUser,
        ITradebackPromoExternalService tradebackPromoExternalService,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _authenticatedUser = authenticatedUser;
        _promoExternalService = tradebackPromoExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
    }

    public async Task<ErrorOr<BenefitListResponseDto>> Execute(string benefitId)
    {
        await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var userOnDigitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        var benefit = await GetBenefitFromTradebackPromo(userOnDigitalAccount!.UserDocument, benefitId);

        if (benefit != null)
        {
            return new BenefitListResponseDto
            {
                BenefitId = benefit.Id,
                BenefitDetailId = benefit.BenefitDetailId,
                Cost = benefit.Cost,
                Name = benefit.Name,
                Description = benefit.Description,
                Category = new BenefitCategoryResponseDto
                {
                    Id = benefit.CategoryId.ToString(),
                    Name = benefit.CategoryName
                },
                Vendor = new BenefitVendorResponseDto
                {
                    Id = benefit.Vendor.Id.ToString(),
                    Name = benefit.Vendor.Name
                },
                Images = new List<AdvertisementImageResponseDto>
                {
                    new() { Tag = "card", Url = benefit.Image },
                    new() { Tag = "detail", Url = benefit.DetailImage },
                    new() { Tag = "banner", Url = benefit.BannerImage }
                }
            };
        }

        return new ErrorOr<BenefitListResponseDto>();
    }

    private async Task<GetBenefitsResponseV2Dto> GetBenefitFromTradebackPromo(string userDocument, string benefitId)
    {
        var response = await _promoExternalService.SearchAdvertisements(new AdvertisementSearchRequestDto(
            new PromoPaginationDto(1, 1), new AdvertisementSearchFilterDto
            {
                SaleIds = new List<string> { benefitId },
                ParticipantIdentifier = userDocument
            }), new CancellationToken(), CrossCutting.Enums.ApplicationType.Vibe);

        if (response.IsError)
            throw new BusinessException(GetBenefitsUseCase.DEFAULT_ERROR_MESSAGE);

        if (!response.IsError && response.Value != null && response.Value.Data.Any())
        {
            List<AdvertisementDataDto> data = response.Value.Data;
            return data.Select(BuildResponseItem).FirstOrDefault();
        }

        return null;
    }

    private static GetBenefitsResponseV2Dto BuildResponseItem(AdvertisementDataDto advertisement) =>
        new()
        {
            Id = advertisement.EligibleProduct.Products[0].Code,
            BenefitDetailId = advertisement.Id,
            Description = advertisement.Description,
            Name = advertisement.Name,
            Order = int.Parse(advertisement.Attributes.Find(attribute => attribute.Key == "ranking")?.Value ?? "9999"),
            Image = advertisement.Store?.Chain?.Images?.Find(image => image.Tag == GetBenefitsUseCase.CARD_IMAGE_TAG)
                ?.Url,
            CategoryId = advertisement.Store?.Chain?.CategoryInfo?.Id,
            CategoryName = advertisement.Store?.Chain?.CategoryInfo?.Name,
            Cost = advertisement.ActivationCondition?.FirstLevelCondition?.AvailableWalletBalance?.AvailableAmount
                ?.Amount ?? 0,
            BannerImage = advertisement.Store?.Chain?.Images
                ?.Find(image => image.Tag == GetBenefitsUseCase.BANNER_IMAGE_TAG)?.Url,
            DetailImage = advertisement.Store?.Chain?.Images
                ?.Find(image => image.Tag == GetBenefitsUseCase.DETAIL_IMAGE_TAG)?.Url,
            Vendor = new BenefitVendorDto
            {
                Name = advertisement.Store?.Chain?.Name,
                Id = long.Parse(advertisement.Store?.Chain?.Id ?? "0")
            }
        };
}
