﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using ErrorOr;
using System.Text.Json;
using VibeBisBff.Application.Partner.Usecases.Benefits.BenefitConfirmationRedemption;
using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2.Dto;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Cache;
using VibeBisBff.Infra.Extensions;
using VibePartner.Dto.Benefit.Request;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.ResendRedemptionConfirmation;
public class ResendRedemptionConfirmationUseCase : IResendRedemptionConfirmationUseCase
{
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly IBenefitConfirmationRedemptionUseCase _benefitExecuteRedemptionUseCase;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IRedisService _redisService;

    public ResendRedemptionConfirmationUseCase(
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        IBenefitConfirmationRedemptionUseCase benefitExecuteRedemptionUseCase,
        AuthenticatedUser authenticatedUser,
        IRedisService redisService)
    {
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _benefitExecuteRedemptionUseCase = benefitExecuteRedemptionUseCase;
        _authenticatedUser = authenticatedUser;
        _redisService = redisService;
    }

    public async Task<ErrorOr<BenefitRedeemedTransactionResponseDto>> Execute(BenefitResendValidatePinRequestDto benefitResendValidatePinRequestDto)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();
        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var result = await _identityAccessManagementExternalService.ValidateOtpCode(
            benefitResendValidatePinRequestDto.PinId,
            benefitResendValidatePinRequestDto.Pin);
        if (!result.Success)
            throw new BusinessException(result.GetFriendlyErrorMessage());

        var benefitRequestAsString = await _redisService.Get(benefitResendValidatePinRequestDto.PinId);
        if (benefitRequestAsString is null)
            throw new BusinessException("Erro ao encontrar o benefício para resgate");

        var benefitRequest = JsonSerializer.Deserialize<AuthorizerV2TransactionRequestDto>(benefitRequestAsString);
        if (benefitRequest is null)
            throw new BusinessException("Erro ao encontrar o benefício para resgate");

        return await _benefitExecuteRedemptionUseCase.Execute(digitalAccountId.Value, benefitRequest);
    }
}
