﻿using ErrorOr;
using VibePartner.Dto.Benefit.Request;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.ResendRedemptionConfirmation;
public interface IResendRedemptionConfirmationUseCase
{
    Task<ErrorOr<BenefitRedeemedTransactionResponseDto>> Execute(BenefitResendValidatePinRequestDto benefitResendValidatePinRequestDto);
}
