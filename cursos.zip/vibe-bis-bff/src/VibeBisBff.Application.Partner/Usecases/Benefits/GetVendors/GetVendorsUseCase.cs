﻿using ErrorOr;
using FluentValidation;
using VibeBisBff.CrossCutting.Constants;
using VibePartner.Dto.Benefit.Response;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.CrossCuting.Dto;


namespace VibeBisBff.Application.Partner.Usecases.Benefits.GetVendors;
public class GetVendorsUseCase : IGetVendorsUseCase
{
    private readonly IValidator<PagingDataDto> _validator;
    private readonly ITradebackPromoExternalService _promoExternalService;

    public GetVendorsUseCase(
        ITradebackPromoExternalService tradebackPromoExternalService,
        IValidator<PagingDataDto> validator)
    {
        _promoExternalService = tradebackPromoExternalService;
        _validator = validator;
    }

    public async Task<ErrorOr<PagingDataResponseDto<BenefitVendorResponseDto>>> Execute(PagingDataDto pagingDataDto)
    {
        var validationResult = await _validator.ValidateAsync(pagingDataDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var categoriesFromCompanies = await _promoExternalService.GetChainCategories(new CancellationToken(false), CrossCutting.Enums.ApplicationType.Vibe);
        var categories = categoriesFromCompanies.Value.Any() ? categoriesFromCompanies.Value.ToList(): new List<CategoryDto>();

        if (categories.Any())
            categories = categories.Where(x => x.Name != Constants.QUEST_CATEGORY_NAME).ToList();

        var result = new PagingDataResponseDto<BenefitVendorResponseDto>();

        var skip = pagingDataDto.PageSize * (pagingDataDto.PageNumber - 1);
        result.Items = categories.Skip(skip!.Value).Take(pagingDataDto.PageSize!.Value).AsEnumerable().Select(x => new BenefitVendorResponseDto
        {
            Id = x.Id,
            Name = x.Name,
        }).ToList();

        return result;
    }
}
