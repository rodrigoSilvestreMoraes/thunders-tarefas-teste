﻿using ErrorOr;
using VibePartner.Dto.Benefit.Response;
using VibeBisBff.CrossCuting.Dto;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.GetVendors;
public interface IGetVendorsUseCase
{
    Task<ErrorOr<PagingDataResponseDto<BenefitVendorResponseDto>>> Execute(PagingDataDto pagingDataDto);
}
