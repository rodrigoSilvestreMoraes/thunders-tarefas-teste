﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using Microsoft.Extensions.Options;
using System.Text.Json;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.Application.Partner.Extensions;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Entities.Benefit;
using VibeBisBff.Domain.Repositories.MongoDb.Benefit;
using VibeBisBff.Dto.MessageWorker;
using VibeBisBff.ExternalServices.PartnerHub.Voucher;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.Infra.ServiceBus;
using VibePartner.Dto.Benefit.Response;
using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2.Dto;
using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2;
using Common.Core.Exceptions;
using VibeBisBff.Domain.Entities;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.ExternalServices.Tradeback.Promo;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.BenefitConfirmationRedemption;
public class BenefitConfirmationRedemptionUseCase : IBenefitConfirmationRedemptionUseCase
{
    private readonly AuthTokenAccessor _tokenAccessor;
   private readonly IAccomplishedBenefitsRepository _accomplishedBenefitsRepository;
    private readonly IVoucherHubExternalService _voucherHubHubExternalService;
    private readonly VoucherOptions _voucherOptions;
    private readonly IServiceBus _messageBroker;
    private readonly VertemLogsLogger _logger;
    private readonly AuthenticatedUser _authenticatedUser;

    private readonly ITradebackAuthorizerV2ExternalService _tradebackAuthorizerV2ExternalService;
    private readonly ITradebackPromoExternalService _tradebackPromoExternalService;

    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    public BenefitConfirmationRedemptionUseCase(
        VertemLogsLogger vertemLogsLogger,
        IServiceBus serviceBus,
        IOptionsSnapshot<VoucherOptions> voucherOptions,
        IVoucherHubExternalService voucherHubExternalService,
        IAccomplishedBenefitsRepository accomplishedBenefitsRepository,
        AuthTokenAccessor authTokenAccessor,
        AuthenticationProvider authenticationProvider,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        ITradebackAuthorizerV2ExternalService tradebackAuthorizerV2ExternalService,
        ITradebackPromoExternalService tradebackPromoExternalService)
    {

        _logger = vertemLogsLogger;
        _messageBroker = serviceBus;
        _voucherOptions = voucherOptions.Value;
        _voucherHubHubExternalService = voucherHubExternalService;
        _accomplishedBenefitsRepository = accomplishedBenefitsRepository;

        _tokenAccessor = authTokenAccessor;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;

        _tradebackAuthorizerV2ExternalService = tradebackAuthorizerV2ExternalService;
        _tradebackPromoExternalService = tradebackPromoExternalService;
    }

    public async Task<ErrorOr<BenefitRedeemedTransactionResponseDto>> Execute(string digitalAccountId, AuthorizerV2TransactionRequestDto benefitRequest)
    {
        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var generatedBenefitTransaction =
            await _tradebackAuthorizerV2ExternalService.GenerateTransaction(benefitRequest, ApplicationType.Vibe);

        if (!generatedBenefitTransaction.HasBenefits)
        {
            _logger.LogError(new ExceptionLog(new Exception(generatedBenefitTransaction.Messages?.Default ?? "A transação gerada do resgate de benefício não possui benefícios")));
            throw new BusinessException("Erro ao resgatar o benefício. Tente novamente mais tarde.");
        }

        var voucherHubBenefit = generatedBenefitTransaction.Benefits.FirstOrDefault(x => x.VoucherHub != null);

        if (voucherHubBenefit is null)
            throw new BusinessException("Erro ao resgatar o benefício. Tente novamente mais tarde.");

        try
        {
            var advertisementResponse = await _tradebackPromoExternalService
                .SearchAdvertisements(new AdvertisementSearchRequestDto(new PromoPaginationDto(1, 1),
                    new AdvertisementSearchFilterDto
                    {
                        SaleIds = new[] { voucherHubBenefit.SaleId }
                    }), new CancellationToken(), ApplicationType.Vibe);

            var advertisement = advertisementResponse.Value.Data[0];
            var accomplished = new AccomplishedBenefit
            {
                CategoryId = advertisement.Store.Chain.CategoryInfo?.Id,
                CategoryName = advertisement.Store.Chain.CategoryInfo?.Name,
                ProductId = voucherHubBenefit.VoucherHub.SkuId.ToString(),
                Cost = advertisement.ActivationCondition.FirstLevelCondition.AvailableWalletBalance.AvailableAmount.Amount,
                Description = advertisement.Description,
                Name = advertisement.Name,
                TransactionId = generatedBenefitTransaction.TransactionId,
                DigitalAccountId = _authenticatedUser.GetDigitalAccountId().Value,
                VoucherHubOrderId = voucherHubBenefit.VoucherHub.OrderId,
                VendorId = benefitRequest.Merchant.Id,
                VendorName = advertisement.Store.Chain.Name,
                Images = advertisement.Store.Chain.Images.Select(x => new GenericImage
                {
                    Tag = x.Tag,
                    Url = x.Url
                }).ToList()
            };

            accomplished.SetPartner(partnerConfig.Id);
            accomplished.SetPartnerTransactionId(benefitRequest.PartnerTransactionId);
            await _accomplishedBenefitsRepository.Insert(accomplished);

            await DispatchBenefitRedeemedEvent(accomplished.Cost, advertisement.EligibleProduct.Products[0].Code, digitalAccountId);
        }
        catch (Exception ex)
        {
            _logger.LogError(new ExceptionLog(ex));
        }

        var benefitVoucher = await _voucherHubHubExternalService.GetVoucher(
            voucherHubBenefit.VoucherHub.SkuId.ToString(),
            voucherHubBenefit.VoucherHub.OrderId.ToString(),
            _tokenAccessor.AccessToken);

        var responseVoucher = benefitVoucher.ToVoucherResponse(DateTime.UtcNow, _voucherOptions.ExpirationDays);

        return new BenefitRedeemedTransactionResponseDto
        {
            BenefitType = BenefitRedeemedTransactionResponseDto._benefitTypeVoucher,
            Status = BenefitPartnerStatus.Success,
            TransactionId = generatedBenefitTransaction.TransactionId,
            VoucherBenefit = responseVoucher
        };

    }
    private async Task DispatchBenefitRedeemedEvent(decimal priceInVirtualCoins, string sku, string digitalAccountId)
    {
        var luckyNumberGenerateMessage = new LuckyNumberGenerateMessageDto
        {
            DigitalAccountId = digitalAccountId,
            Products = new List<ProductsWithVibesBurnedDto>
        {
                new()
                {
                    BurnQuantityOfVirtualCoins = priceInVirtualCoins,
                    Id = sku
                }
            }
        };

        await _messageBroker.SendMessage(MessageBrokerEntitiesNames.REDEEMED_BENEFIT_QUEUE_NAME, JsonSerializer.Serialize(luckyNumberGenerateMessage));
    }
}
