﻿using ErrorOr;
using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2.Dto;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.BenefitConfirmationRedemption;
public interface IBenefitConfirmationRedemptionUseCase
{
    Task<ErrorOr<BenefitRedeemedTransactionResponseDto>> Execute(string digitalAccountId, AuthorizerV2TransactionRequestDto benefitRequest);
}
