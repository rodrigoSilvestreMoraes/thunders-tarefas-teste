﻿using ErrorOr;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.GetBenefitTransaction;
public interface IGetBenefitTransactionUseCase
{
    Task<ErrorOr<VoucherBenefitResponseDto>> Execute(string transactionId);
}
