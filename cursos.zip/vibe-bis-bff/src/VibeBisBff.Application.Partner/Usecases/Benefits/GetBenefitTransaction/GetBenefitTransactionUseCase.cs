﻿using ErrorOr;
using Microsoft.Extensions.Options;
using VibeBisBff.Application.Partner.Extensions;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Repositories.MongoDb.Benefit;
using VibeBisBff.ExternalServices.PartnerHub.Voucher;
using VibeBisBff.Infra.Auth;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.GetBenefitTransaction;
public class GetBenefitTransactionUseCase : IGetBenefitTransactionUseCase
{
    private readonly IVoucherHubExternalService _voucherHubExternalService;
    private readonly AuthTokenAccessor _authTokenAccessor;
    private readonly IAccomplishedBenefitsRepository _accomplishedBenefitsRepository;
    private readonly VoucherOptions _voucherOptions;

    public GetBenefitTransactionUseCase(
        IVoucherHubExternalService voucherHubExternalService,
        AuthTokenAccessor authTokenAccessor,
        IAccomplishedBenefitsRepository accomplishedBenefitsRepository,
        IOptionsSnapshot<VoucherOptions> voucherOptions)
    {
        _voucherHubExternalService = voucherHubExternalService;
        _authTokenAccessor = authTokenAccessor;
        _accomplishedBenefitsRepository = accomplishedBenefitsRepository;
        _voucherOptions = voucherOptions.Value;
    }

    public async Task<ErrorOr<VoucherBenefitResponseDto>> Execute(string transactionId)
    {
        var benefit = await _accomplishedBenefitsRepository.GetByParentOrderId(transactionId);

        if (benefit is null)
            return Error.NotFound(description: "Beneficio resgatado não encontrado");

        var voucherBenefit = await _voucherHubExternalService.GetVoucher(benefit.Product.ProductCode,
            benefit.Product.VendorOrderId, _authTokenAccessor.AccessToken);

        return voucherBenefit.ToVoucherResponse(benefit.RedeemedDate, _voucherOptions.ExpirationDays);
    }
}
