﻿using ErrorOr;
using VibePartner.Dto.Benefit.Request;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.ResendRedemption;
public interface IResendRedemptionOtpCodeUseCase
{
    Task<ErrorOr<BenefitResendPinResponseDto>> Execute(BenefitResendPinRequestDto request);
}
