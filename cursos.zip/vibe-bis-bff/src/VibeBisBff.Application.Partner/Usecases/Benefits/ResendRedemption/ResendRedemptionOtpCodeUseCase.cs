﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Domain.Repositories.MongoDb.Benefit;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Extensions;
using VibePartner.Dto.Benefit.Request;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.ResendRedemption;

public class ResendRedemptionOtpCodeUseCase : IResendRedemptionOtpCodeUseCase
{
    private readonly IAccomplishedBenefitsRepository _accomplishedBenefitsRepository;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    public ResendRedemptionOtpCodeUseCase(
    IAccomplishedBenefitsRepository accomplishedBenefitsRepository,
    AuthenticationProvider authenticationProvider,
    IDigitalAccountExternalService digitalAccountExternalService,
    IIdentityAccessManagementExternalService identityAccessManagementExternalService,
    IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase)
    {
        _accomplishedBenefitsRepository = accomplishedBenefitsRepository;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
        _digitalAccountExternalService = digitalAccountExternalService;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;

        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
    }

    public async Task<ErrorOr<BenefitResendPinResponseDto>> Execute(BenefitResendPinRequestDto request)
    {
        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var benefit  = await _accomplishedBenefitsRepository.GetByParentOrderIdAndPartnerId(request.TransactionId, partnerConfig.Id);

        if(benefit is null)
            throw new BusinessException("benefício não encontrado.");

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value, ApplicationType.Vibe);

        var result =  await _identityAccessManagementExternalService.SendCellphoneOtp(digitalAccount.GetCellphone(),
            digitalAccountId.Value, appType: ApplicationType.Vibe);
        return new BenefitResendPinResponseDto
        {
             PinId = result.OtpId
        };
    }
}
