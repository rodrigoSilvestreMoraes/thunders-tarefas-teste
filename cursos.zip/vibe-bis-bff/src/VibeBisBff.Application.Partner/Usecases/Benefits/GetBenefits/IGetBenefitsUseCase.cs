﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.GetBenefits;
public interface IGetBenefitsUseCase
{
    Task<ErrorOr<PagingDataResponseDto<BenefitListResponseDto>>> Execute(PagingDataDto pagingDataDto, string vendorId);
}
