﻿using ErrorOr;
using FluentValidation;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibePartner.Dto;
using VibePartner.Dto.Benefit.Response;
using Common.Core.Authentication.Models;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.Dto.Benefit;
using Common.Core.Exceptions;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.GetBenefits;

public class GetBenefitsUseCase : IGetBenefitsUseCase
{
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;
    private readonly IValidator<PagingDataDto> _validator;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly ITradebackPromoExternalService _promoExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;

    public const string DEFAULT_ERROR_MESSAGE = "Erro ao buscar os benefícios. Tente novamente em alguns minutos.";
    public const string BANNER_IMAGE_TAG = "banner";
    public const string DETAIL_IMAGE_TAG = "detail";
    public const string CARD_IMAGE_TAG = "card";


    public GetBenefitsUseCase(
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        IValidator<PagingDataDto> validator,
        AuthenticatedUser authenticatedUser,
        ITradebackPromoExternalService tradebackPromoExternalService,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _validator = validator;
        _authenticatedUser = authenticatedUser;
        _promoExternalService = tradebackPromoExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
    }

    public async Task<ErrorOr<PagingDataResponseDto<BenefitListResponseDto>>> Execute(PagingDataDto pagingDataDto,
        string vendorId)
    {
        var validationResult = await _validator.ValidateAsync(pagingDataDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var userOnDigitalAccount =
            await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        var availableProducts = await GetBenefitsFromTradebackPromo(userOnDigitalAccount!.UserDocument);

        availableProducts = availableProducts.OrderBy(x => x.Order)
            .ThenByDescending(x => x.Cost)
            .ThenBy(x => x.Id).ToList();

        if (!string.IsNullOrEmpty(vendorId) && availableProducts.Any())
        {
            availableProducts = availableProducts.Where(x => x.Vendor.Id.ToString() == vendorId).ToList();
        }

        var skip = pagingDataDto.PageSize * (pagingDataDto.PageNumber - 1);
        availableProducts = availableProducts.Skip(skip!.Value).Take(pagingDataDto.PageSize!.Value).ToList();

        List<BenefitListResponseDto> availableBenefits = availableProducts
            .Select(benefit => new BenefitListResponseDto
            {
                BenefitId = benefit.Id,
                BenefitDetailId = benefit.BenefitDetailId,
                Cost = benefit.Cost,
                Name = benefit.Name,
                Description = benefit.Description,
                Category = new BenefitCategoryResponseDto
                {
                    Id = benefit.CategoryId.ToString(),
                    Name = benefit.CategoryName
                },
                Vendor = new BenefitVendorResponseDto
                {
                    Id = benefit.Vendor.Id.ToString(),
                    Name = benefit.Vendor.Name
                },
                Images = new List<AdvertisementImageResponseDto>
                {
                    new() { Tag = "card", Url = benefit.Image },
                    new() { Tag = "detail", Url = benefit.DetailImage },
                    new() { Tag = "banner", Url = benefit.BannerImage }
                }
            }).ToList();

        var availableBenefitsAsList = availableBenefits.ToList();

        return new PagingDataResponseDto<BenefitListResponseDto>()
        {
            TotalItems = availableBenefits.Count,
            Items = availableBenefitsAsList
        };
    }

    private async Task<IEnumerable<GetBenefitsResponseV2Dto>> GetBenefitsFromTradebackPromo(string userDocument)
    {
        var categoriesFromCompanies =
            await _promoExternalService.GetChainCategories(new CancellationToken(),
                CrossCutting.Enums.ApplicationType.Vibe);

        if (categoriesFromCompanies.IsError)
            throw new BusinessException(DEFAULT_ERROR_MESSAGE);

        var response = await _promoExternalService.SearchAdvertisements(new AdvertisementSearchRequestDto(
            new PromoPaginationDto(100, 1), new AdvertisementSearchFilterDto
            {
                ParticipantIdentifier = userDocument,
                Chain = new AdvertisementChainFilterDto()
                {
                    Categories = categoriesFromCompanies.Value.Where(x => x.Name != Constants.QUEST_CATEGORY_NAME)
                        .Select(x => x.Id).ToList()
                }
            }), new CancellationToken(), CrossCutting.Enums.ApplicationType.Vibe);

        if (response.IsError)
            throw new BusinessException(DEFAULT_ERROR_MESSAGE);

        return response.Value.Data.Select(BuildResponseItem).ToList();
    }

    private static GetBenefitsResponseV2Dto BuildResponseItem(AdvertisementDataDto advertisement) =>
        new()
        {
            Id = advertisement.EligibleProduct.Products[0].Code,
            BenefitDetailId = advertisement.Id,
            Name = advertisement.Name,
            Description = advertisement.Description,            
            Order = int.Parse(advertisement.Attributes.Find(attribute => attribute.Key == "ranking")?.Value ?? "9999"),
            CategoryId = advertisement.Store?.Chain?.CategoryInfo?.Id,
            CategoryName = advertisement.Store?.Chain?.CategoryInfo?.Name,
            Image = advertisement.Store?.Chain?.Images?.Find(image => image.Tag == CARD_IMAGE_TAG)?.Url,
            Cost = advertisement.ActivationCondition?.FirstLevelCondition?.AvailableWalletBalance?.AvailableAmount
                ?.Amount ?? 0,

            BannerImage = advertisement.Store?.Chain?.Images?.Find(image => image.Tag == BANNER_IMAGE_TAG)?.Url,
            DetailImage = advertisement.Store?.Chain?.Images?.Find(image => image.Tag == DETAIL_IMAGE_TAG)?.Url,
            Vendor = new BenefitVendorDto
            {
                Name = advertisement.Store?.Chain?.Name,
                Id = long.Parse(advertisement.Store?.Chain?.Id ?? "0")
            }
        };
}
