﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.GetBenefitsRedeemed;

public interface IGetBenefitsRedeemedUseCase
{
    Task<ErrorOr<PagingDataResponseDto<BenefitListResponseDto>>> Execute(PagingDataDto pagingDataDto, string vendorId);
}
