﻿using Common.Core.Authentication.Models;
using ErrorOr;
using FluentValidation;
using Microsoft.Extensions.Options;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCutting.Extensions;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Repositories.MongoDb.Benefit;
using VibeBisBff.Infra.Extensions;
using VibePartner.Dto;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.GetBenefitsRedeemed;
public class GetBenefitsRedeemedUseCase : IGetBenefitsRedeemedUseCase
{
    private readonly IAccomplishedBenefitsRepository _accomplishedBenefitsRepository;
    private readonly StorageAccountOptions _storageAccountOptions;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IValidator<PagingDataDto> _validator;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    public GetBenefitsRedeemedUseCase(
        IAccomplishedBenefitsRepository accomplishedBenefitsRepository,
        IOptionsSnapshot<StorageAccountOptions> storageAccountOptions,
        AuthenticatedUser authenticatedUser,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        IValidator<PagingDataDto> validator)
    {
        _accomplishedBenefitsRepository = accomplishedBenefitsRepository;
        _authenticatedUser = authenticatedUser;
        _storageAccountOptions = storageAccountOptions.Value;
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _validator = validator;
    }

    public async Task<ErrorOr<PagingDataResponseDto<BenefitListResponseDto>>> Execute(PagingDataDto pagingDataDto, string vendorId)
    {
        var validationResult = await _validator.ValidateAsync(pagingDataDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var accomplishedBenefits = await _accomplishedBenefitsRepository.GetByDigitalAccountAndPartner(pagingDataDto,
            _authenticatedUser.GetDigitalAccountId().Value, partnerConfig.Id, vendorId);

        if (accomplishedBenefits == null || !accomplishedBenefits.Any())
            return new PagingDataResponseDto<BenefitListResponseDto>()
            {
                Items = new List<BenefitListResponseDto>(),
                TotalItems = 0
            };

        var items = accomplishedBenefits.Select(accomplishedBenefit => new BenefitListResponseDto
        {
            BenefitId = accomplishedBenefit.Product.Sku,
            Cost = accomplishedBenefit.Product.CostPrice,
            Name = accomplishedBenefit.Product.Name,
            Description = accomplishedBenefit.Description,
            Category = new BenefitCategoryResponseDto
            {
                Id = accomplishedBenefit.Product.CategoryId.ToString(),
                Name = accomplishedBenefit.Product.CategoryName
            },
            Vendor = new BenefitVendorResponseDto
            {
                Id = accomplishedBenefit.Product.VendorId,
                Name = accomplishedBenefit.Product.VendorName
            },
            Images = new List<AdvertisementImageResponseDto>
            {
                new() { Tag = "card", Url = GetProductImageUrlFromSku(accomplishedBenefit.Product.Sku, "card") },
                new() { Tag = "detail", Url = GetProductImageUrlFromSku(accomplishedBenefit.Product.Sku, "detail") },
                new() { Tag = "banner", Url = GetProductImageUrlFromSku(accomplishedBenefit.Product.Sku, "banner") }
            },
            InformationList = accomplishedBenefit.Features.Select(x => new AdditionalInformationDetail
            {
                Title = MarkdownHelper.InBold(x.Name),
                Value = x.Value.ConvertHtmlTextToMarkdown(new MarkdownHelperConfiguration()
                {
                    ShouldConvertHTagToBold = true
                })
            }).ToList()
        }).ToList();

        return new PagingDataResponseDto<BenefitListResponseDto>()
        {
            Items = items,
            TotalItems = items.Count
        };
    }
    private string GetProductImageUrlFromSku(string skuId, string imageDestiny) =>
        $"{_storageAccountOptions?.ProductImageBaseUrlForBenefits}/{skuId}_{imageDestiny}.png";
}
