﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Benefits.BenefitConfirmationRedemption;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2.Dto;
using VibeBisBff.ExternalServices.Tradeback.Mappers.Benefit;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Cache;
using VibeBisBff.Infra.Extensions;
using VibePartner.Dto.Benefit.Request;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.BenefitRedemption;
public class BenefitRedemptionUseCase : IBenefitRedemptionUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IBenefitConfirmationRedemptionUseCase _benefitExecuteRedemptionUseCase;
    private readonly IRedisService _redisService;

    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;
    private static long HOURS_IN_SECONDS = 3600;

    public BenefitRedemptionUseCase (
        IDigitalAccountExternalService digitalAccountExternalService,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        AuthenticatedUser authenticatedUser,
        IBenefitConfirmationRedemptionUseCase benefitExecuteRedemptionUseCase,
        IRedisService redisService,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _authenticatedUser = authenticatedUser;
        _benefitExecuteRedemptionUseCase = benefitExecuteRedemptionUseCase;
        _redisService = redisService;

        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;

    }
   
    public async Task<ErrorOr<BenefitRedeemedTransactionResponseDto>> Execute(BenefitRedeemedRequestDto benefitRedeemedRequestDto)
    {
        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        if (partnerConfig.Has2Fa)
            return await FlowVibeWith2Fa(benefitRedeemedRequestDto);

        return await FlowVibeWithout2Fa(benefitRedeemedRequestDto);
    }   

    private async Task<ErrorOr<BenefitRedeemedTransactionResponseDto>> FlowVibeWithout2Fa(BenefitRedeemedRequestDto request)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();
        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value, ApplicationType.Vibe);
        var requestBenefit =  PrepareBenefit(digitalAccount, request.VendorId, request.BenefitId, request.PartnerTransactionId);

        return  await _benefitExecuteRedemptionUseCase.Execute(digitalAccountId.Value, requestBenefit.Value);
    }


    public async Task<ErrorOr<BenefitRedeemedTransactionResponseDto>> FlowVibeWith2Fa(BenefitRedeemedRequestDto request)
    {
        var response = new BenefitRedeemedTransactionResponseDto { BenefitType = BenefitRedeemedTransactionResponseDto._benefitTypeVoucher, Status = BenefitPartnerStatus.TwoFA };

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();
        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value, ApplicationType.Vibe);
        var requestBenefit = PrepareBenefit(digitalAccount, request.VendorId, request.BenefitId, request.PartnerTransactionId);

        var result2Fa = await _identityAccessManagementExternalService.SendCellphoneOtp(digitalAccount.GetCellphone(), digitalAccountId.Value);

        if(result2Fa ==  null)
            throw new BusinessException("Erro ao resgatar o benefício. Tente novamente mais tarde.");

        await _redisService.Set(result2Fa.OtpId, requestBenefit.Value, HOURS_IN_SECONDS * 2);

        response.SecondFactor = new SecondFactorResponseDto
        {
            PinId = result2Fa.OtpId,
            OtpSendType = OtpSendType.SMS,
            PhoneNumber = digitalAccount.GetMaskCellphone()
        };

        return response;
    }

    private static ErrorOr<AuthorizerV2TransactionRequestDto> PrepareBenefit(DigitalAccountParticipantDetail digitalAccount, string vendorId, string benefitId, string partnerTransactionId)
     => TradebackAuthorizerV2TransactionRequestProfile.MapToBenefitRequest(digitalAccount, vendorId, benefitId, partnerTransactionId);
}
