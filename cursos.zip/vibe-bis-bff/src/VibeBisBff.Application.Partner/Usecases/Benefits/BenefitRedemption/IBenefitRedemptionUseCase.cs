﻿using ErrorOr;
using VibePartner.Dto.Benefit.Request;
using VibePartner.Dto.Benefit.Response;

namespace VibeBisBff.Application.Partner.Usecases.Benefits.BenefitRedemption;
public interface IBenefitRedemptionUseCase
{
    Task<ErrorOr<BenefitRedeemedTransactionResponseDto>> Execute(BenefitRedeemedRequestDto benefitRedeemedRequestDto);
    Task<ErrorOr<BenefitRedeemedTransactionResponseDto>> FlowVibeWith2Fa(BenefitRedeemedRequestDto request);
}
