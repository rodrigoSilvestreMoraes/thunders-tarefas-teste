﻿using VibePartner.Dto;
using VibePartner.Dto.Raffles.Response;

namespace VibeBisBff.Application.Partner.Usecases.Ruffles;
public interface IGetRaffleUseCase
{
    Task<RafflesResponseDto> Execute();
}
