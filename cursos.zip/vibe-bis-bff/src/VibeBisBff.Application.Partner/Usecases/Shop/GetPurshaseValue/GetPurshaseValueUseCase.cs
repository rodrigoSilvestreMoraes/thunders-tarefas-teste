﻿using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Wallets.GetBalance;
using VibePartner.Dto.Shop.Response;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Calculator;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetPurshaseValue;

public class GetPurshaseValueUseCase : IGetPurshaseValueUseCase
{
    private readonly IPurchaseValueCalculator _purchaseValueCalculator;
    private readonly IGetBalanceUseCase _getBalanceUseCase;
    public GetPurshaseValueUseCase(
        IPurchaseValueCalculator purchaseValueCalculator,
        IGetBalanceUseCase getBalanceUseCase)
    {
        _purchaseValueCalculator = purchaseValueCalculator;
        _getBalanceUseCase = getBalanceUseCase;
    }

    public async Task<ErrorOr<ShopPurchaseValuesResponseDto>> Execute()
    {
        //Validação:  MKP retorna erro quando a conta não existe saldo
        var balance = await _getBalanceUseCase.Execute();
        if (balance.IsError || balance.Value.TotalBalance <= 0)
            throw new BusinessException("Você não possui saldo");

        var result = await _purchaseValueCalculator.CalculatePurchaseValueByCart();
        return new ShopPurchaseValuesResponseDto
        {

            MinPointForCash = result.Value.MinPointForCash,
            ShippingCost = result.Value.ShippingCost,
            TotalOrder = result.Value.TotalOrder
        };
    }
}
