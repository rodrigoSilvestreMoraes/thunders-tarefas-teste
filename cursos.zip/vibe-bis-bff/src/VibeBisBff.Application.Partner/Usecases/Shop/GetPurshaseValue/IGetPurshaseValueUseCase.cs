﻿using ErrorOr;
using VibePartner.Dto.Shop.Response;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetPurshaseValue;

public interface IGetPurshaseValueUseCase
{
    Task<ErrorOr<ShopPurchaseValuesResponseDto>> Execute();
}
