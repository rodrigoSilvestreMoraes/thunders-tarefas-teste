﻿using ErrorOr;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;

namespace VibeBisBff.Application.Partner.Usecases.Shop.InsertOrder;

public interface IInsertOrderUseCase
{
    Task<ErrorOr<Success>> Execute(string parentOrderId, string partnerId, PurchaseValueResponseDto orderValueSummary);
}
