﻿using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using System.Collections.Concurrent;
using VibeBisBff.Domain.Entities.Shop;
using VibeBisBff.Domain.Models;
using VibeBisBff.Domain.Repositories.MongoDb.Shop;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Partner.Usecases.Shop.InsertOrder
{
    public class InsertOrderUseCase : IInsertOrderUseCase
    {
        private readonly AuthenticatedUser _authenticatedUser;
        private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
        private readonly AuthTokenAccessor _tokenAccessor;
        private readonly IOrderRepository _orderRepository;
        private readonly IMapper _mapper;

        public InsertOrderUseCase(AuthenticatedUser authenticatedUser,
            IVertemMarketplaceExternalService vertemMarketplaceExternalService,
            AuthTokenAccessor tokenAccessor,
            IOrderRepository orderRepository,
            IMapper mapper)
        {
            _authenticatedUser = authenticatedUser;
            _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
            _tokenAccessor = tokenAccessor;
            _orderRepository = orderRepository;
            _mapper = mapper;
        }

        public async Task<ErrorOr<Success>> Execute(string parentOrderId, string partnerId, PurchaseValueResponseDto orderValueSummary)
        {
            var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

            if (digitalAccountId.IsError)
                return digitalAccountId.Errors;

            var orderDetails =
                (await _vertemMarketplaceExternalService.GetOrderDetails(parentOrderId, _tokenAccessor.AccessToken)).Orders[0];

            var productsFromOrder = GetProductsFromOrderAndAppendPriceAndVendorOrderId(orderDetails);

            var order = new Order(parentOrderId,
                digitalAccountId.Value,
                productsFromOrder,
                orderValueSummary.Markup,
                orderDetails.OrderTotalShippingValue,
                orderValueSummary.TotalOrder,
                orderValueSummary.MinPointForCash,
                _mapper.Map<OrderAddress>(orderDetails.Address));

            order.SetPartner(partnerId);
            await _orderRepository.Insert(order);

            return Result.Success;
        }

        private static ConcurrentBag<OrderProduct> GetProductsFromOrderAndAppendPriceAndVendorOrderId(MarketplaceOrderDetailDto orderDetail)
        {
            var productsFromOrder = new ConcurrentBag<OrderProduct>();

            Parallel.ForEach(orderDetail.VendorOrderModel,
                orderRepresentationFromVendor =>
                {
                    foreach (var vendorOrderItem in orderRepresentationFromVendor.Items)
                        productsFromOrder.Add(vendorOrderItem.ToOrderProduct(orderRepresentationFromVendor));
                });

            return productsFromOrder;
        }
    }
}
