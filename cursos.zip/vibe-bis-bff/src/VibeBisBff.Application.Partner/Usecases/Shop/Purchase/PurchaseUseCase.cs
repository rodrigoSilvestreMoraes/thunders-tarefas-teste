﻿using Common.Core.Exceptions;
using ErrorOr;
using FluentValidation;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.Application.Partner.Usecases.Shop.InsertOrder;
using VibeBisBff.Application.Partner.Usecases.Wallets.GetBalance;
using VibeBisBff.Infra.Auth;
using VibePartner.Dto.Shop.Response;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Calculator;

namespace VibeBisBff.Application.Partner.Usecases.Shop.Purchase;

public class PurchaseUseCase : IPurchaseUseCase
{
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly IValidator<CreditCardPaymentRequestDto> _validator;
    private readonly AuthTokenAccessor _tokenAccessor;
    private readonly IPurchaseValueCalculator _purchaseValueCalculator;
    private readonly IInsertOrderUseCase _insertOrderUseCase;
    private readonly IGetBalanceUseCase _getBalanceUseCase;
    private readonly VertemLogsLogger _logger;

    public PurchaseUseCase(IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        IValidator<CreditCardPaymentRequestDto> validator,
        AuthTokenAccessor tokenAccessor,
        IPurchaseValueCalculator purchaseValueCalculator,
        IInsertOrderUseCase insertOrderUseCase,
        IGetBalanceUseCase getBalanceUseCase,
        VertemLogsLogger logger)
    {
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _validator = validator;
        _tokenAccessor = tokenAccessor;
        _purchaseValueCalculator = purchaseValueCalculator;
        _insertOrderUseCase = insertOrderUseCase;
        _getBalanceUseCase = getBalanceUseCase;
        _logger = logger;
    }

    public async Task<ErrorOr<ShopPurchaseResponseDto>> Execute(CreditCardPaymentRequestDto creditCardPaymentRequestDto)
    {
        var validationResult = await _validator.ValidateAsync(creditCardPaymentRequestDto);
        var response  = new ShopPurchaseResponseDto();

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        //Validação:  MKP retorna erro quando a conta não existe saldo
        var balance = await _getBalanceUseCase.Execute();
        if (balance.IsError || balance.Value.TotalBalance <= 0)
            throw new BusinessException("Você não possui saldo");

        var purchaseValue = await _purchaseValueCalculator.CalculatePurchaseValueByCart();
        if (purchaseValue.IsError)
            return purchaseValue.Errors;

        creditCardPaymentRequestDto.PointsValue = purchaseValue.Value.TotalMoneyValueWithoutTax;

        var parentOrderId =
           await _vertemMarketplaceExternalService.PurchaseCart(creditCardPaymentRequestDto, _tokenAccessor.AccessToken);

        try
        {
            var insertOrderResult = await _insertOrderUseCase.Execute(parentOrderId.ToString(), partnerConfig.Id, purchaseValue.Value);

            if (insertOrderResult.IsError)
                throw new BusinessException(string.Join(',', insertOrderResult.Errors.Select(x => x.Description)));
        }
        catch (Exception ex)
        {
            _logger.LogError(new ExceptionLog(ex));
        }
        response.OrderId = parentOrderId.ToString();
        return response;
    }
}
