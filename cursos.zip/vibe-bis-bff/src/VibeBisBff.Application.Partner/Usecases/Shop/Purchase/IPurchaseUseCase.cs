﻿using ErrorOr;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibePartner.Dto.Shop.Response;

namespace VibeBisBff.Application.Partner.Usecases.Shop.Purchase;

public interface IPurchaseUseCase
{
    Task<ErrorOr<ShopPurchaseResponseDto>> Execute(CreditCardPaymentRequestDto creditCardPaymentRequestDto);
}
