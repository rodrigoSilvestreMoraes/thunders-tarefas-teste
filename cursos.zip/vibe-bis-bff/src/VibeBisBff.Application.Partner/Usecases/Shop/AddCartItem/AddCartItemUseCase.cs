﻿using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.Application.Partner.Mappers.Participant;
using VibeBisBff.ExternalServices.MarketplaceCartItem;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.Infra.Auth;
using VibePartner.Dto.Shop.Request;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Mapper;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.Application.Partner.Usecases.Shop.AddCartItem;

public class AddCartItemUseCase : IAddCartItemUseCase
{
    private readonly IAddMarketplaceCartItem _addMarketplaceCartItem;
    private readonly AuthTokenAccessor _authTokenAccessor;
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;

    public AddCartItemUseCase(IAddMarketplaceCartItem addMarketplaceCartItem,
        AuthTokenAccessor authTokenAccessor,
        IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthenticatedUser authenticatedUser,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _addMarketplaceCartItem = addMarketplaceCartItem;
        _authTokenAccessor = authTokenAccessor;
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _authenticatedUser = authenticatedUser;
        _digitalAccountExternalService = digitalAccountExternalService;
    }

    public async Task<ErrorOr<Success>> Execute(ShopAddCartItemRequestDto shopAddCartItemRequestDto)
    {
        var response = await _addMarketplaceCartItem.Execute(shopAddCartItemRequestDto.ProductId, shopAddCartItemRequestDto.VendorId);
        if (response.IsError) return response.Errors;

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();
        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value, ApplicationType.Vibe);

        var cartRequestAddressDto = CartAddAddressProfile.Map(digitalAccount, shopAddCartItemRequestDto.Address.MapAddressPartnerForVibe(), _authenticatedUser.IsVibeTenant().Value);
        var addCartResponse = await _vertemMarketplaceExternalService.AddCartAddress(cartRequestAddressDto, _authTokenAccessor.AccessToken);

        if (addCartResponse.IsError)
            return addCartResponse.Errors;

        return Result.Success;
    }
}
