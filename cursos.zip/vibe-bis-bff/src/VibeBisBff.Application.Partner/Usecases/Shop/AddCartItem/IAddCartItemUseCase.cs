﻿using ErrorOr;
using VibePartner.Dto.Shop.Request;

namespace VibeBisBff.Application.Partner.Usecases.Shop.AddCartItem;

public interface IAddCartItemUseCase
{
    Task<ErrorOr<Success>> Execute(ShopAddCartItemRequestDto shopAddCartItemRequestDto);
}
