﻿using VibePartner.Dto.Shop.Response;
using ErrorOr;
using VibeBisBff.CrossCuting.Dto;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetVendorsAvailable;

public interface IGetVendorsAvailableUseCase
{
    Task<ErrorOr<PagingDataResponseDto<ShopVendorResponseDto>>> Execute(PagingDataDto pagingDataDto);

}
