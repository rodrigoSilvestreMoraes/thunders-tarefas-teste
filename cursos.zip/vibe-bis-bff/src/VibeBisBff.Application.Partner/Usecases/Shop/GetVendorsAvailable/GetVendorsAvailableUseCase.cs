﻿using ErrorOr;
using FluentValidation;
using VibeBisBff.Application.Partner.Usecases.Shop.GetItem;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCutting.Constants;
using VibePartner.Dto.Shop.Response;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetVendorsAvailable;

public class GetVendorsAvailableUseCase : IGetVendorsAvailableUseCase
{
    private readonly IValidator<PagingDataDto> _validator;
    private readonly IGetItemUseCase _getItemUseCase;

    public GetVendorsAvailableUseCase(IValidator<PagingDataDto> validator, IGetItemUseCase getItemUseCase)
    {
        _validator = validator;
        _getItemUseCase = getItemUseCase;
    }

    public async Task<ErrorOr<PagingDataResponseDto<ShopVendorResponseDto>>> Execute(PagingDataDto pagingDataDto)
    {
        var validationResult = await _validator.ValidateAsync(pagingDataDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var result = new PagingDataResponseDto<ShopVendorResponseDto>();
        var products = await _getItemUseCase.Execute(new PagingDataDto { PageSize = PagingDataFixValues.PageMaxSize, PageNumber = PagingDataFixValues.PageInitNumber });

        if (products.Value?.TotalItems > 0)
        {
            var vendors = products.Value.Items.Select(x => x.Vendor)
                .GroupBy(x => new ShopVendorResponseDto { Id = x.Id, Name = x.Name })
                .Select(x => new ShopVendorResponseDto
                {
                    Id = x.Key.Id,
                    Name = x.Key.Name
                }).ToList();

            result.TotalItems = vendors.Count;

            var skip = pagingDataDto.PageSize * (pagingDataDto.PageNumber - 1);
            result.Items = vendors.Skip(skip!.Value).Take(pagingDataDto.PageSize!.Value).ToList();
        }

        return result;
    }
}
