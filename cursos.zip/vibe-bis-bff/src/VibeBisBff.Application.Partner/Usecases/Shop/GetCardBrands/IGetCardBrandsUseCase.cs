﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Shop;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetCardBrands;

public interface IGetCardBrandsUseCase
{
    Task<ErrorOr<List<CardBrandsResponseDto>>> Execute();
}
