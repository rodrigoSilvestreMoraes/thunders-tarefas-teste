﻿using VibePartner.Dto.Shop.Response;
using ErrorOr;
using VibeBisBff.CrossCuting.Dto;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetItem;
public interface IGetItemUseCase
{
    Task<ErrorOr<PagingDataResponseDto<ShopProductResponseDto>>> Execute(PagingDataDto pagingDataDto);
}
