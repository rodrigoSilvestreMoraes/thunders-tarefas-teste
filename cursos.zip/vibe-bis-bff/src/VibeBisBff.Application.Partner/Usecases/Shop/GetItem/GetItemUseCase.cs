﻿using ErrorOr;
using FluentValidation;
using Microsoft.Extensions.Options;
using System.Collections.Concurrent;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCuting.Dto.Shop;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Entities.Benefit.Mapper;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Helpers;
using VibePartner.Dto;
using VibePartner.Dto.Shop.Response;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetItem;

public class GetItemUseCase : IGetItemUseCase
{
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly IValidator<PagingDataDto> _validator;
    private readonly AuthTokenAccessor _tokenAccessor;
    private readonly IVertemLogsLogger _logger;
    private readonly StorageAccountOptions _storageAccountOptions;

    public GetItemUseCase(IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthTokenAccessor authTokenAccessor,
        IValidator<PagingDataDto> validator,
        IVertemLogsLogger logger,
        IOptionsSnapshot<StorageAccountOptions> storageAccountOptions)
    {
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _validator = validator;
        _tokenAccessor = authTokenAccessor;
        _logger = logger;
        _storageAccountOptions = storageAccountOptions.Value;
    }

    public async Task<ErrorOr<PagingDataResponseDto<ShopProductResponseDto>>> Execute(PagingDataDto pagingDataDto)
    {
        var validationResult = await _validator.ValidateAsync(pagingDataDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var resultFromMarketplace =
            await _vertemMarketplaceExternalService.GetProductsByShowCaseForBenefits<ShowCaseProductDto>(
                partnerConfig.ShopMarketplaceShowCaseId, _tokenAccessor.AccessToken);

        var availableProducts = (await GetAvailableProductsAndAppendPrice(resultFromMarketplace.Products)).ToList();
        var totalOfProducts = availableProducts.Count();

        //TODO: A paginação precisa ser feita depois para que o total de itens esteja correto.
        if (availableProducts.Any())
        {
            var skip = pagingDataDto.PageSize * (pagingDataDto.PageNumber - 1);
            availableProducts = availableProducts.Skip(skip!.Value).Take(pagingDataDto.PageSize!.Value).ToList();
        }

        var productsToFilter = availableProducts.Select(x => x.Sku).ToDictionary(x => x);

        var availableBenefits = availableProducts
            .Where(showCaseProduct => productsToFilter.ContainsKey(showCaseProduct.Sku))
            .Select(showCaseProduct => new ShopProductResponseDto
            {
                Id = showCaseProduct.Sku,
                Name = showCaseProduct.Name,
                Description = showCaseProduct.Description,
                Cost = showCaseProduct.Price,
                CostInCoins = showCaseProduct.Availability.PointsCash.PartialPoints,                
                Order = showCaseProduct.Order,
                Category = new ShopCategoryResponseDto
                {
                    Id = showCaseProduct.Subcategory.Category.Id.ToString(),
                    Name = showCaseProduct.Subcategory.Category.Name
                },
                Vendor = new ShopVendorResponseDto
                {
                    Id = showCaseProduct.Vendor.Id,
                    Name = showCaseProduct.Vendor.Name
                },
                Images = new List<AdvertisementImageResponseDto>
                {
                    new() { Tag = "card", Url = GetProductImageUrlFromSku(showCaseProduct.Sku, "card") },
                    new() { Tag = "detail", Url = GetProductImageUrlFromSku(showCaseProduct.Sku, "detail") },
                    new() { Tag = "banner", Url = GetProductImageUrlFromSku(showCaseProduct.Sku, "banner") }
                },
                InformationList = showCaseProduct.Features.Select(x => new AdditionalInformationDetail
                {
                    Title = x.key,
                    Value = x.value
                }).ToList(),
                Installments = showCaseProduct.Availability.Cash.Installments.Select(installment => new ShopItemInstallmentDto
                {
                    Description = installment.Description,
                    Installment = installment.Installment,
                    Value = installment.Value
                }).ToList(),
            });

        RankAvailableBenefits(ref availableBenefits);

        var availableBenefitsAsList = availableBenefits.ToList();

        return new PagingDataResponseDto<ShopProductResponseDto>()
        {
            TotalItems = totalOfProducts,
            Items = availableBenefitsAsList
        };
    }
    private string GetProductImageUrlFromSku(string skuId, string imageDestiny) =>
        $"{_storageAccountOptions?.ProductImageBaseUrlForBenefits}/{skuId}_{imageDestiny}.png";
    private static void RankAvailableBenefits(ref IEnumerable<ShopProductResponseDto> availableBenefits)
    {
        availableBenefits = availableBenefits
            .OrderBy(x => x.Order)
            .ThenByDescending(x => x.Cost)
            .ThenBy(x => x.Id);
    }

    private async Task<ConcurrentBag<ShowCaseProductDto>> GetAvailableProductsAndAppendPrice(
        IEnumerable<ShowCaseProductDto> benefits)
    {
        var availableProducts = new ConcurrentBag<ShowCaseProductDto>();

        await Parallel.ForEachAsync(benefits, async (product, cancellationToken) =>
        {
            if (cancellationToken.IsCancellationRequested)
                return;

            try
            {
                var productAvailabilityResultTask = _vertemMarketplaceExternalService.GetAvailabilityAndPriceBySku(
                    new ProductAvailabilityRequestDto
                    {
                        Sku = product.Sku,
                        OriginalId = product.OriginalId,
                        VendorId = product.Vendor.Id.ToString()
                    }, _tokenAccessor.AccessToken);

                var productDetailTask =
                    _vertemMarketplaceExternalService.GetProductDetail(product.Sku, _tokenAccessor.AccessToken);

                await Task.WhenAll(new List<Task>
                {
                    productAvailabilityResultTask,
                    productDetailTask
                });

                var featureWithRanking = productDetailTask.Result.Value.Features
                    .Find(feature => feature.Name == MarketplaceProductHelper.FEATURE_RANK_KEY)?.Value;

                if (productAvailabilityResultTask.Result.Available)
                {
                    product.Price = productAvailabilityResultTask.Result.Price;
                    product.Available = true;
                    product.Availability = productAvailabilityResultTask.Result;
                    product.Name = productDetailTask.Result.Value.Name;
                    product.Order = featureWithRanking != null ? int.Parse(featureWithRanking) : int.MaxValue;
                    product.Description =
                        MarketplaceProductHelper.GetFormattedDescriptionAsMarkdown(productDetailTask.Result.Value
                            .Description);
                    product.Features =
                        MarketplaceProductHelper.GetFeaturesMarkDown(FeatureProfile.Map(productDetailTask.Result.Value.Features));
                    availableProducts.Add(product);
                }
            }
            catch (Exception exception)
            {
                _logger.LogError(new ExceptionLog(exception));
            }
        });

        return availableProducts;
    }
}
