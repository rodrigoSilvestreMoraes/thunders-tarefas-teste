﻿using ErrorOr;
using VibePartner.Dto.Shop.Response;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetDetailOrder;

public interface IGetDetailOrderUseCase
{
    Task<ErrorOr<ShopOrderDetailsResponseDto>> Execute(string orderId, string vendorOrderId, string productSkuId);
}
