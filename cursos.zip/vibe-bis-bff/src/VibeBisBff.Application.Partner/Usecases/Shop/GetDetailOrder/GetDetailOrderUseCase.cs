﻿using Common.Core.Exceptions;
using ErrorOr;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Partner.Mappers.Shop;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.Domain.Entities.Shop;
using VibeBisBff.Domain.Repositories.MongoDb.Shop;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.Infra.Auth;
using VibePartner.Dto.Shop.Response;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetDetailOrder;
public class GetDetailOrderUseCase : IGetDetailOrderUseCase
{
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;
    private readonly AuthTokenAccessor _tokenAccessor;
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly IOrderRepository _orderRepository;
    private readonly VertemLogsLogger _logger;

    public GetDetailOrderUseCase(IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        AuthTokenAccessor tokenAccessor,
        IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        IOrderRepository orderRepository,
        VertemLogsLogger logger)
    {
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _tokenAccessor = tokenAccessor;
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _orderRepository = orderRepository;
        _logger = logger;
    }

    public async Task<ErrorOr<ShopOrderDetailsResponseDto>> Execute(string orderId, string vendorOrderId, string productSkuId)
    {
        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();
        var order = await _orderRepository.GetById(parentOrderId: orderId, partnerId: partnerConfig.Id);

        if (order is null)
            throw new BusinessException("Pedido não encontrado");

        if (order.OrderPayment is null)
            order = await UpdateOrderPaymentFromMkp(order);

        var orderProduct =
            order.Products.FirstOrDefault(x => x.VendorOrderId == vendorOrderId
                                               && x.Sku == productSkuId);

        if (orderProduct == default)
            throw new BusinessException("Item não encontrado no pedido atual");

        var trackingResponse = await GetTrackingOrDefaultValue(
            vendorOrderId: orderProduct.VendorOrderId,
            productCode: orderProduct.ProductCode,
            vendorId: orderProduct.VendorId);

        return OrdersMapper.MapToOrderDetails(order, trackingResponse, orderProduct);
    }

    private async Task<Order> UpdateOrderPaymentFromMkp(Order order)
    {
        var responseFromMarketplace =
            await _vertemMarketplaceExternalService.GetOrderDetails(order.ParentOrderId, _tokenAccessor.AccessToken);

        if (responseFromMarketplace.Orders is null || !responseFromMarketplace.Orders.Any())
            throw new BusinessException("Pedido não encontrado");

        var marketplacePayment = responseFromMarketplace.Orders.FirstOrDefault()?.OrderPaymentDetailMoneyAndPoints;

        if (marketplacePayment == null) return order;

        order.AddPayment(new OrderPayment(
            cardBrandImageUrl: marketplacePayment.ImageUrlCardBrand,
            creditCardLastDigits: marketplacePayment.LastCreditCardDigits,
            installments: int.Parse(marketplacePayment.NumberParcels),
            installmentValue: marketplacePayment.ValueParcelDecimal));

        await _orderRepository.UpdatePayment(order);

        return order;
    }

    private async Task<ShippingTrackingResponseDto> GetTrackingOrDefaultValue(string vendorOrderId,
        string productCode,
        string vendorId)
    {
        try
        {
            return await _vertemMarketplaceExternalService.GetShippingTracking(long.Parse(vendorOrderId),vendorId, productCode, _tokenAccessor.AccessToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(new ExceptionLog(ex));
            return null;
        }
    }
}
