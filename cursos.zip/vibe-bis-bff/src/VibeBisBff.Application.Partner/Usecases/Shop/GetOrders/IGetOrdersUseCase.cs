﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto;
using VibePartner.Dto.Shop.Response;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetOrders;

public interface IGetOrdersUseCase
{
    Task<ErrorOr<PagingDataResponseDto<ShopOrderResponseDto>>> Execute(PagingDataDto pagingDataDto);
}
