﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.Application.Partner.Mappers.Shop;
using VibeBisBff.Domain.Repositories.MongoDb.Shop;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Extensions;
using VibePartner.Dto.Shop.Response;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.CrossCuting.Dto;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetOrders;

public class GetOrdersUseCase : IGetOrdersUseCase
{
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthTokenAccessor _authTokenAccessor;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IOrderRepository _orderRepository;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    private const int BLOCK_SIZE_FOR_ORDERS = 50;

    public GetOrdersUseCase(IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthTokenAccessor authTokenAccessor,
        AuthenticatedUser authenticatedUser,
        IOrderRepository orderRepository,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase)
    {
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _authTokenAccessor = authTokenAccessor;
        _authenticatedUser = authenticatedUser;
        _orderRepository = orderRepository;
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
    }

    public async Task<ErrorOr<PagingDataResponseDto<ShopOrderResponseDto>>> Execute(PagingDataDto pagingDataDto)
    {
        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var response = new PagingDataResponseDto<ShopOrderResponseDto>();
        response.Items = new List<ShopOrderResponseDto>();

        var responseFromMarketplace =
            await _vertemMarketplaceExternalService.GetOrders(_authTokenAccessor.AccessToken, 0, BLOCK_SIZE_FOR_ORDERS);

        if (responseFromMarketplace.Total == 0)
            return response;

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            throw new BusinessException(
                $"Erro ao obter o identificador do participante - {string.Join(',', digitalAccountId.Errors.Select(x => x.Code))}");

        var parentOrderIdsFromOrdersOnInternalBase =
            (await _orderRepository.GetParentOrderIdsByDigitalAccountId(digitalAccountId.Value, partnerConfig.Id)).ToList();

        responseFromMarketplace =
            FilterByOrderIdsOnInternalBase(responseFromMarketplace,
                parentOrderIdsFromOrdersOnInternalBase);

        var firstRequestOrders = responseFromMarketplace.MapToOrders();

        if (responseFromMarketplace.Total <= BLOCK_SIZE_FOR_ORDERS)
            return response;

        var items =  await GetOrdersByBatchProcess(firstRequestOrders, responseFromMarketplace.Total, parentOrderIdsFromOrdersOnInternalBase);

        if (items.Any())
        {
            var skip = pagingDataDto.PageSize * (pagingDataDto.PageNumber - 1);
            items = items.Skip(skip!.Value).Take(pagingDataDto.PageSize!.Value).ToList();
        }

        response.Items = items;
        response.TotalItems = items.Count;

        return response;
    }


    private async Task<List<ShopOrderResponseDto>> GetOrdersByBatchProcess(IEnumerable<ShopOrderResponseDto> ordersFromFirstRequest,
       decimal totalOfRemainingItems,
       ICollection<string> orderIdsOnInternalBase)
    {
        var numberOfIterations = Math.Ceiling(totalOfRemainingItems / BLOCK_SIZE_FOR_ORDERS);

        var ordersToReturn = new List<ShopOrderResponseDto>(ordersFromFirstRequest);
        var accOfOrders = 1;

        while (accOfOrders < numberOfIterations)
        {
            var responseWithOffset = await _vertemMarketplaceExternalService.GetOrders(_authTokenAccessor.AccessToken,
                accOfOrders * BLOCK_SIZE_FOR_ORDERS, BLOCK_SIZE_FOR_ORDERS);

            responseWithOffset =
                FilterByOrderIdsOnInternalBase(responseWithOffset, orderIdsOnInternalBase);

            ordersToReturn.AddRange(responseWithOffset.MapToOrders());

            accOfOrders++;
        }

        return ordersToReturn;
    }

    private static MarketplaceOrdersResponseDto FilterByOrderIdsOnInternalBase(
        MarketplaceOrdersResponseDto marketplaceOrders, ICollection<string> orderIdsInInternalBase)
    {
        marketplaceOrders.Orders = marketplaceOrders.Orders.Where(x =>
            orderIdsInInternalBase.Contains(x.ParentOrderId)).ToList();

        return marketplaceOrders;
    }
}
