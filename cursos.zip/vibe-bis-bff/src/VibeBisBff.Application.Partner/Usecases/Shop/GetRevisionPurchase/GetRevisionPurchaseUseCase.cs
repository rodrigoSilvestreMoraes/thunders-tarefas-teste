﻿using AutoMapper;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Shop.GetItem;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.Infra.Auth;
using VibePartner.Dto.Shop.Response;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetRevisionPurchase;

public class GetRevisionPurchaseUseCase : IGetRevisionPurchaseUseCase
{
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthTokenAccessor _authTokenAccessor;
    private readonly IMapper _mapper;
    private readonly IGetItemUseCase _getItemUseCase;

    public GetRevisionPurchaseUseCase(IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthTokenAccessor authTokenAccessor,
        IMapper mapper,
        IGetItemUseCase getItemUseCase)
    {
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _authTokenAccessor = authTokenAccessor;
        _mapper = mapper;
        _getItemUseCase = getItemUseCase;
    }

    public async Task<ErrorOr<ShopRevisionPurshaseResponseDto>> Execute()
    {
        var response = new ShopRevisionPurshaseResponseDto();

        var userToken = _authTokenAccessor.AccessToken;
        var cart = await _vertemMarketplaceExternalService.GetCartItems(userToken);

        var sku = cart.Items.FirstOrDefault()?.Sku;

        if (string.IsNullOrWhiteSpace(sku))
            return Error.NotFound(description: "Não foi encontrado nenhum produto no carrinho");

        // TODO: buscar apenas o produto desejado
        var items = await _getItemUseCase.Execute(new PagingDataDto
        {
            PageSize = PagingDataFixValues.PageMaxSize,
            PageNumber = PagingDataFixValues.PageInitNumber
        });

        if (items.IsError) return items.Errors;

        var product = items.Value.Items.FirstOrDefault(x => x.Id == sku);
        if (product == null)
            return Error.NotFound(description: "O produto não foi encontrado");

        response.Address = _mapper.Map<CartShippingAddressDto, ParticipantAddressDto>(cart.ShippingAddress);

        var shippingResponse = await AddShippingInfo(sku, response.Address.PostalCode, userToken);
        if (shippingResponse.IsError)
            return shippingResponse.Errors;

        response.Id = product.Id;
        response.Name = product.Name;
        response.Category  = product.Category;
        response.Vendor = product.Vendor;
        response.Cost = product.Cost;
        response.CostInCoins = product.CostInCoins;
        response.Description = product.Description;
        response.InformationList = product.InformationList;
        response.Images = product.Images;
        response.Order = product.Order;
        response.Installments = product.Installments;
        response.Shipping = shippingResponse.Value;        

        return response;
    }

    private async Task<ErrorOr<ShopShippingResponseDto>> AddShippingInfo(string productId, string postalCode, string userToken)
    {
        var shippingInfo = await _vertemMarketplaceExternalService.GetShippingCost(postalCode, productId, userToken);

        if (shippingInfo.IsError)
            return shippingInfo.Errors;

        return new ShopShippingResponseDto
        {
            Cost = shippingInfo.Value.Total,
            DeliveryDate = shippingInfo.Value != null && shippingInfo.Value.DeliveryDate.HasValue ? (DateTime)(shippingInfo.Value?.DeliveryDate) : null
        };
    }
}
