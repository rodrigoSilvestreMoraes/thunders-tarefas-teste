﻿using ErrorOr;
using VibePartner.Dto.Shop.Response;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetRevisionPurchase;

public interface IGetRevisionPurchaseUseCase
{
    Task<ErrorOr<ShopRevisionPurshaseResponseDto>> Execute();
}
