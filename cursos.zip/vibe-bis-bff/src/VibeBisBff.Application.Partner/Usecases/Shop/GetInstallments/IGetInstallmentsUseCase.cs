﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Shop;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetInstallments;
public interface IGetInstallmentsUseCase
{
    Task<ErrorOr<List<ShopItemInstallmentDto>>> Execute();
}
