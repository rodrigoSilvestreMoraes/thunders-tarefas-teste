﻿using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Wallets.GetBalance;
using VibeBisBff.CrossCuting.Dto.Shop;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Calculator;
using VibeBisBff.Infra.Auth;

namespace VibeBisBff.Application.Partner.Usecases.Shop.GetInstallments;
public class GetInstallmentsUseCase : IGetInstallmentsUseCase
{
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthTokenAccessor _authTokenAccessor;
    private readonly IPurchaseValueCalculator _purchaseValueCalculator;
    private readonly IGetBalanceUseCase _getBalanceUseCase;

    public GetInstallmentsUseCase(IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthTokenAccessor authTokenAccessor,
        IPurchaseValueCalculator purchaseValueCalculator,
        IGetBalanceUseCase getBalanceUseCase)
    {
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _authTokenAccessor = authTokenAccessor;
        _purchaseValueCalculator = purchaseValueCalculator;
        _getBalanceUseCase = getBalanceUseCase;
    }

    public async Task<ErrorOr<List<ShopItemInstallmentDto>>> Execute()
    {
        //Validação:  MKP retorna erro quando a conta não existe saldo
        var balance = await _getBalanceUseCase.Execute();
        if (balance.IsError || balance.Value.TotalBalance <= 0)
            throw new BusinessException("Você não possui saldo");

        var purchaseValue = await _purchaseValueCalculator.CalculatePurchaseValueByCart();

        if (purchaseValue.IsError)
            return purchaseValue.Errors;

        return await _vertemMarketplaceExternalService.GetInstallments(_authTokenAccessor.AccessToken,
                                                                              purchaseValue.Value.TotalMoneyValue);
    }
}
