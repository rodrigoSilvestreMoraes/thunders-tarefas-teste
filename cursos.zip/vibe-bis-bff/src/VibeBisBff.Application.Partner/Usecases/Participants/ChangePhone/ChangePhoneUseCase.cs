﻿using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Partner.Usecases.Participants.ChangePhone;

public class ChangePhoneUseCase : IChangePhoneUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;
    private readonly AuthenticatedUser _authenticatedUser;

    public ChangePhoneUseCase(IDigitalAccountExternalService digitalAccountExternalService,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        AuthenticatedUser authenticatedUser)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _authenticatedUser = authenticatedUser;
    }

    public async Task<ErrorOr<Success>> Execute(ParticipantPhoneRequestDto participantPhoneRequestDto)
    {
        await _getPartnerAuthenticateUseCase.GetPartnerConfig();
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value, ApplicationType.Vibe);

        if (digitalAccount.DigitalAccountAddresses.Count == 0)
            return Result.Success;

        var phoneId = digitalAccount.DigitalAccountPhones.FirstOrDefault()?.Id;

        await _digitalAccountExternalService.UpdatePhoneNumberFromDigitalAccount(participantPhoneRequestDto.Phone, digitalAccountId.Value, phoneId, ApplicationType.Vibe);

        return Result.Success;
    }
}
