﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Partner.Usecases.Participants.ChangePhone;

public interface IChangePhoneUseCase
{
    Task<ErrorOr<Success>> Execute(ParticipantPhoneRequestDto participantPhoneRequestDto);
}

