﻿using Common.Core.Exceptions;
using ErrorOr;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Partner.Mappers.Participant;
using VibeBisBff.CrossCutting.Options;
using Microsoft.Extensions.Options;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using FluentValidation;
using VibeBisBff.Infra.KeyVault;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.Terms;
using VibeBisBff.ExternalServices.Vertem.Terms.Dto;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCuting.Dto.Participants.Response;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Vertem.IamClientCredentials;

namespace VibeBisBff.Application.Partner.Usecases.Participants.Register;

public class ParticipantsRegisterUseCase : IParticipantsRegisterUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IVertemIamTenantService _vertemIamTenantService;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    private readonly IKeyVaultClientManager _keyVaultClientManager;

    private readonly IValidator<ParticipantsRegisterBaseRequestDto> _partnerParticipantsRegisterRequestValidation;

    private readonly ITermsExternalService _termsExternalService;
    private readonly VertemTermsOptions _vertemTermsOptions;

    private readonly VertemLogsLogger _logger;

    public ParticipantsRegisterUseCase(
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        ITermsExternalService termsExternalService,
        IOptionsSnapshot<VertemTermsOptions> vertemTermsOptions,
        IValidator<ParticipantsRegisterBaseRequestDto> partnerParticipantsRegisterRequestValidation,
        IDigitalAccountExternalService digitalAccountExternalService,
        IKeyVaultClientManager keyVaultClientManager,
        VertemLogsLogger logger,
        IVertemIamTenantService vertemIamTenantService)
    {
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _termsExternalService = termsExternalService;
        _vertemTermsOptions = vertemTermsOptions.Value;
        _digitalAccountExternalService = digitalAccountExternalService;

        _partnerParticipantsRegisterRequestValidation = partnerParticipantsRegisterRequestValidation;
        _keyVaultClientManager = keyVaultClientManager;

        _logger = logger;
        _vertemIamTenantService = vertemIamTenantService;
    }

    public async Task<ErrorOr<ParticipantCreateResponseDto>> Execute(
        ParticipantsRegisterBaseRequestDto participantsRegisterRequestDto,
        ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto)
    {
        var errorsOnInput =
            await HasValidationErrorsOnInputs(participantsRegisterRequestDto);

        if (errorsOnInput.IsError)
            return errorsOnInput.Errors;

        var partnerConfig = await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        if (partnerConfig == null)
            throw new BusinessException("Parceiro não encontrado.");

        var createParticipantRegister = ParticipantProfile.MapToDigitalAccountCreate(participantsRegisterRequestDto);
        participantsRegisterRequestHeaderDto.FillEmptyField();

        var digitalAccount = await _digitalAccountExternalService.Create(createParticipantRegister, ApplicationType.Vibe);

        try
        {
            await AcceptTermsForApp(participantsRegisterRequestHeaderDto, digitalAccount.Response.Id);
            var clientSecret = await _keyVaultClientManager.GetSecret(partnerConfig.KeyVaultClientSecretKey);

            var token = await _vertemIamTenantService.GetAccessTokenForByPos(
                new LoginCredential
                {
                    ClientId = partnerConfig.ClientId,
                    ClientSecret = clientSecret

                }, digitalAccountId: digitalAccount.Response.Id);


            return new ParticipantCreateResponseDto
            {
                AccessToken = token.Value.AccessToken,
                DigitalAccountId = digitalAccount.Response.Id,
                RefreshToken = token.Value.RefreshToken,
                ExpiresIn = token.Value.ExpiresIn,
                Scope = token.Value.Scope,
                TokenType = token.Value.TokenType
            };
        }
        catch (Exception e)
        {
            _logger.LogError(new ExceptionLog(e));
            await _digitalAccountExternalService.DeleteDigitalAccount(digitalAccount.Response.Id, ApplicationType.Vibe);
            return Error.Unexpected(e is not BusinessException
                ? "Erro ao criar o usuário. Tente novamente, por favor"
                : e.Message);
        }
    }

    private async Task AcceptTermsForApp(ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto, string digitalAccountId)
    {
        var defaultRequestForAcceptTerms = new AcceptTermsRequestDto
        {
            DigitalAccountId = digitalAccountId,
            UserAgent = new TermsUserAgentDto()
            {
                Device = participantsRegisterRequestHeaderDto.Device,
                OperationalSystem = participantsRegisterRequestHeaderDto.OperationalSystem,
                Language = participantsRegisterRequestHeaderDto.Language,
                DeviceType = participantsRegisterRequestHeaderDto.DeviceType,
            },
            Geolocation = new TermsGeolocationDto()
            {
                Latitude = participantsRegisterRequestHeaderDto.Latitude,
                Longitude = participantsRegisterRequestHeaderDto.Longitude
            },
            Ip = participantsRegisterRequestHeaderDto.Ip,
        };

        await Task.WhenAll(
            _termsExternalService.AcceptTermsForLastVersion(defaultRequestForAcceptTerms with
            {
                TermId = _vertemTermsOptions.TermIdForUseTerms
            }, ApplicationType.Vibe),
            _termsExternalService.AcceptTermsForLastVersion(defaultRequestForAcceptTerms with
            {
                TermId = _vertemTermsOptions.TermIdForPrivacyPolicy
            }, ApplicationType.Vibe));
    }

    private async Task<ErrorOr<bool>> HasValidationErrorsOnInputs(ParticipantsRegisterBaseRequestDto request)
    {
        var validationResultForBody = await _partnerParticipantsRegisterRequestValidation.ValidateAsync(request);

        if (!validationResultForBody.IsValid)
            return validationResultForBody.Errors.ToValidation().ToList();

        return true;
    }
}
