﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Partner.Usecases.Participants.DeleteParticipant;

public class DeleteParticipantUseCase : IDeleteParticipantUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    public DeleteParticipantUseCase(
        IDigitalAccountExternalService digitalAccountExternalService,
        AuthenticatedUser authenticatedUser,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticatedUser;
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
    }

    public async Task Execute()
    {
        await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            throw new BusinessException("Erro ao obter as informações do usuário");

        var digitalAccount =
            await _digitalAccountExternalService.GetParticipantDetailsById(_authenticatedUser.GetDigitalAccountId().Value, ApplicationType.Vibe);

        if (digitalAccount is null)
            throw new BusinessException("Usuário não encontrado");

        await _digitalAccountExternalService.DeleteDigitalAccount(digitalAccountId.Value, ApplicationType.Vibe);
    }
}
