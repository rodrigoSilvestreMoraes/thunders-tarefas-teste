﻿namespace VibeBisBff.Application.Partner.Usecases.Participants.DeleteParticipant;

public interface IDeleteParticipantUseCase
{
    Task Execute();
}
