﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Partner.Usecases.Participants.ChangeAddress;
public interface IChangeAddressUseCase
{
    Task<ErrorOr<Success>> Execute(ParticipantAddressDto newAddress);
}
