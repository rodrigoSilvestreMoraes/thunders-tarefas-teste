﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Dto;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Partner.Usecases.Participants.ChangeAddress;

public class ChangeAddressUseCase : IChangeAddressUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;

    public ChangeAddressUseCase(IDigitalAccountExternalService digitalAccountExternalService,
        AuthenticatedUser authenticatedUser,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticatedUser;
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
    }

    public async Task<ErrorOr<Success>> Execute(ParticipantAddressDto newAddress)
    {
        await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();
        if (digitalAccountId.IsError)
            throw new BusinessException("Participante não encontrado.");

        var user = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value, ApplicationType.Vibe);

        var newDigitalAccountAddress = new DigitalAccountAddressDto()
        {
            DigitalAccountId = digitalAccountId.Value,
            AddressTypeId = "62c7118af628272722a847b3",
            City = newAddress.City,
            Country = newAddress.Country,
            District = newAddress.District,
            Number = newAddress.Number,
            PostalCode = newAddress.PostalCode,
            Street = newAddress.Street,
            State = newAddress.State,
            Complement = newAddress.Complement
        };

        if (user.DigitalAccountAddresses.Count == 0)
        {
            await _digitalAccountExternalService.CreateAddress(newDigitalAccountAddress, ApplicationType.Vibe);
            return Result.Success;
        }            

        var currentDigitalAccountAddress = user.DigitalAccountAddresses[0];
        newDigitalAccountAddress.Id = currentDigitalAccountAddress.Id;

        await _digitalAccountExternalService.UpdateAddress(newDigitalAccountAddress, ApplicationType.Vibe);
        return Result.Success;
    }
}
