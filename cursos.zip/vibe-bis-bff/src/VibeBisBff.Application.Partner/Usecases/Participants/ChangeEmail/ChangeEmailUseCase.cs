﻿using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.Application.Partner.Usecases.Partner.GetPartnerAuthenticate;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Partner.Usecases.Participants.ChangeEmail;

public class ChangeEmailUseCase : IChangeEmailUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IGetPartnerAuthenticateUseCase _getPartnerAuthenticateUseCase;
    private readonly AuthenticatedUser _authenticatedUser;

    public ChangeEmailUseCase(
        IDigitalAccountExternalService digitalAccountExternalService,
        IGetPartnerAuthenticateUseCase getPartnerAuthenticateUseCase,
        AuthenticatedUser authenticatedUser)
    {
        _getPartnerAuthenticateUseCase = getPartnerAuthenticateUseCase;
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticatedUser;
    }

    public async Task<ErrorOr<Success>> Execute(ParticipantEmailRequestDto participantEmailRequestDto)
    {
        await _getPartnerAuthenticateUseCase.GetPartnerConfig();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value, ApplicationType.Vibe);

        if (digitalAccount.DigitalAccountAddresses.Count == 0)
            return Result.Success;

        var emailId = digitalAccount.DigitalAccountEmails.FirstOrDefault()?.Id;
        await _digitalAccountExternalService.UpdateEmailFromDigitalAccount(participantEmailRequestDto.Email, digitalAccountId.Value, emailId, ApplicationType.Vibe);

        return Result.Success;
    }
}
