﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Partner.Usecases.Participants.ChangeEmail;

public interface IChangeEmailUseCase
{
    Task<ErrorOr<Success>> Execute(ParticipantEmailRequestDto participantEmailRequestDto);
}
