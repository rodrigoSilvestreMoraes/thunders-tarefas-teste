﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Partner.Usecases.Participants.ValidateRegisterKey;
public interface IValidateRegisterKeyUseCase
{
    Task<ErrorOr<bool>> Execute(ValidateKeyBaseRequestDto validateKeyRequestDto);
}
