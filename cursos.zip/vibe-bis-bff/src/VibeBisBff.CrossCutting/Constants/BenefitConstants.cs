﻿namespace VibeBisBff.CrossCutting.Constants;

public static class BenefitConstants
{
    public const string BANNER_IMAGE_TAG = "banner";
    public const string DETAIL_IMAGE_TAG = "detail";
    public const string CARD_IMAGE_TAG = "card";
    public const string LIST_IMAGE_TAG = "list";
}
