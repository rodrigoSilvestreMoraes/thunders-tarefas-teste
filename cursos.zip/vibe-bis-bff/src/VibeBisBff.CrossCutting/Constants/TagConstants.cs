﻿namespace VibeBisBff.CrossCutting.Constants;

public static class TagConstants
{
    public const string TAG_ID = "TAG_ID";
    public const string TAG_ID_EXPIRATION = "TAG_ID_EXPIRATION";
    public const string TAG_ID_SOLD_OFF = "TAG_ID_SOLD_OFF";
    public const string EXPIRATION_DATE = "EXPIRATION_DATE";
}
