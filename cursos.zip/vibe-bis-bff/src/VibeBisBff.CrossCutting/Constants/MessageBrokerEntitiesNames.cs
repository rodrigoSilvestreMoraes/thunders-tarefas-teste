﻿namespace VibeBisBff.CrossCutting.Constants;

public static class MessageBrokerEntitiesNames
{
    public const string REDEEMED_BENEFIT_QUEUE_NAME = "redeemed-benefit";
    public const string CREATE_SERVICE_NOW_USER_QUEUE_NAME = "create-service-now-user";
    public const string RAFFLE_DRAW_MESSAGES_QUEUE_NAME = "raffle_draw_messages";
}
