﻿namespace VibeBisBff.CrossCutting.Constants;

public static class AuthenticationTypes
{
    public const string OTP_CREDENTIALS = "otp_credentials";
    public const string WHATS_CREDENTIALS = "whatsapp_credentials";
    public const string CLIENT_CREDENTIALS = "client_credentials";
}
