﻿namespace VibeBisBff.CrossCutting.Constants;

public static class Constants
{
    public const string SERVICE_ID = "VibeBisBffAPI";
    public const string VERSION = "1.0.0";
    public const string QUEST_CATEGORY_NAME = "Missões";
    public const string PROMO_COMPANY_LOWEST_BENEFIT_VALUE_ATTRIBUTE_KEY = "benefit-lowest-value";
    public const string PROMO_NOTIFICATION_IMAGE_TAG = "NOTIFICATION_IMAGE";
    public const string BUSINESS_AREA_VIBE_EMPRESAS_KEY = "BusinessArea";

    public static class Auth
    {
        public const string SUBSCRIPTION_KEY = "Ocp-Apim-Subscription-Key";
        public const string BEARER = "Bearer";
        public const string CLIENT_GRANT_TYPE = "grant_type";
        public const string CLIENT_CREDENTIALS = "client_credentials";
        public const string TENANT_CONFIG_ID = "tenant.config";
        public const string CLIENT_ID = "client_id";
        public const string CLIENT_SECRET = "client_secret";
        public const string TOKEN_URI = "/connect/token";
        public const string REFRESH_TOKEN = "refresh_token";
    }

    public static class ErrorCodes
    {
        public const string NO_MINIMUM_APP_VERSION_FOUND = "NO-MINIMUM-APP-VERSION-FOUND";
    }

    public static class GenerateOtp
    {
        public const string REDIS_KEY_ONBOARDING_OTP_FLOW = "UserOnboarding_";
    }

    public static class Geolocation
    {
        public const string LATITUDE_HEADER = "x-geolocation-latitude";
        public const string LONGITUDE_HEADER = "x-geolocation-longitude";
        public const string GRANT_HEADER = "x-geolocation-granted";
    }
}
