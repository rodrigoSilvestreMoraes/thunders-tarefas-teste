﻿namespace VibeBisBff.CrossCutting.Constants;

public static class PagingDataFixValues
{
    public const int PageMaxSize = 99;

    public const int PageInitNumber = 1;
    public const int PageInitNumberMkp = 0;
}
