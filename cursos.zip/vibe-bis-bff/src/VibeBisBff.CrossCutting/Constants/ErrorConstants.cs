﻿namespace VibeBisBff.CrossCutting.Constants;

public static class ErrorConstants
{
    public const string TOO_MANY_CODES_REQUESTS =
        "Foram feitas muitas solicitações de código, favor tentar novamente mais tarde.";

    public const string GENERIC_ERROR =
        "Ops! Houve um problema, mas estamos cuidando disso! Tente novamente mais tarde.";
}
