﻿namespace VibeBisBff.CrossCutting.Constants;

public static class DocumentType
{
    public const int Indefinido = 1;
    public const int CPF = 2;
    public const int RG = 3;
    public const int CNPJ = 4;
}
