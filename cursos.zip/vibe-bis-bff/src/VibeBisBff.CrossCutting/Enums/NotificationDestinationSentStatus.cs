﻿namespace VibeBisBff.CrossCutting.Enums;

public enum NotificationDestinationSentStatus
{
    Created,
    Error,
    Success
}
