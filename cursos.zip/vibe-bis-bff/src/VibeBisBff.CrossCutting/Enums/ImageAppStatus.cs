﻿namespace VibeBisBff.CrossCutting.Enums;

public enum ImageAppStatus
{
    Active,
    Desactive
}
