﻿namespace VibeBisBff.CrossCutting.Enums
{
    public enum BenefitPartnerStatus
    {
        Success,
        Unauthorized,
        TwoFA
    }
}
