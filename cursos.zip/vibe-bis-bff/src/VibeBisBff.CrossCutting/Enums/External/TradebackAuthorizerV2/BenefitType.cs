﻿namespace VibeBisBff.CrossCutting.Enums.External.TradebackAuthorizerV2;

public enum BenefitType
{
    Credit = 4,
    Voucher = 12,
    LuckyNumbers = 13,
    VoucherHub= 14
}
