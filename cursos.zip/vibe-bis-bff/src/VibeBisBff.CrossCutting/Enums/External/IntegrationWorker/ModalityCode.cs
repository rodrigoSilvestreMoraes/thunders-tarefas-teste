﻿
namespace VibeBisBff.CrossCutting.Enums.External.IntegrationWorker
{
    public enum ModalityCode
    {
        Tradicional = 1,
        Incentivo = 4,
        Filantropia = 5
    }
}
