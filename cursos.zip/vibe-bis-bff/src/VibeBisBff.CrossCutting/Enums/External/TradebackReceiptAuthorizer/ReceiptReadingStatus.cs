﻿namespace VibeBisBff.CrossCutting.Enums.External.TradebackReceiptAuthorizer;

public enum ReceiptReadingStatus
{
    Pending,
    Processing,
    ProcessedByCache,
    Success,
    Failed
}
