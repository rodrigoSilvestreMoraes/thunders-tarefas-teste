﻿namespace VibeBisBff.CrossCutting.Enums.External.TradebackReceiptAuthorizer;

public enum ReceiptAuthorizationStatus
{
    AwaitingReading,
    Processing,
    Success,
    FailedSend,
    Failed
}
