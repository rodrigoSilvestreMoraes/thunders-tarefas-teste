﻿namespace VibeBisBff.CrossCutting.Enums;

public enum TagStatus
{
    Active,
    Desactive
}
