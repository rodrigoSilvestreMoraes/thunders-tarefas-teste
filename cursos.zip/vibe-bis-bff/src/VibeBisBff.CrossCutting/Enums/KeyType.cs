﻿namespace VibeBisBff.CrossCutting.Enums;

public enum KeyType
{
    Document,
    Email,
    Cellphone,
}
