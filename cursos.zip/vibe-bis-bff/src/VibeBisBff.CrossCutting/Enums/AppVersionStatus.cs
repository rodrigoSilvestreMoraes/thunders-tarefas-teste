﻿namespace VibeBisBff.CrossCutting.Enums;

public enum AppVersionStatus
{
    Active,
    Desactive
}
