﻿namespace VibeBisBff.CrossCutting.Enums;

public enum BenefitStatus
{
    Available,
    Redeemed
}
