﻿namespace VibeBisBff.CrossCutting.Enums;

public enum RaffleStatus
{
    Winner,
    NotWinner,
    Awaiting
}
