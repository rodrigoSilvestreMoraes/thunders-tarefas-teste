﻿namespace VibeBisBff.CrossCutting.Enums;

public enum ParticipantType
{
    CPF,
    CNPJ
}
