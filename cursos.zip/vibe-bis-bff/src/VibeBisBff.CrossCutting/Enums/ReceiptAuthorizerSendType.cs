﻿namespace VibeBisBff.CrossCutting.Enums;

public enum ReceiptAuthorizerSendType
{
    QRCode = 1,
    AccessKey
}
