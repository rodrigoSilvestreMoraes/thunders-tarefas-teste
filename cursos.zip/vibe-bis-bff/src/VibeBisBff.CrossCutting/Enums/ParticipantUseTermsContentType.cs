﻿namespace VibeBisBff.CrossCutting.Enums;

public enum ParticipantUseTermsContentType
{
    Url
}
