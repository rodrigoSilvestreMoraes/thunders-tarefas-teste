﻿namespace VibeBisBff.CrossCutting.Enums;

public enum QuestsStatus
{
    Available,
    Accomplished
}
