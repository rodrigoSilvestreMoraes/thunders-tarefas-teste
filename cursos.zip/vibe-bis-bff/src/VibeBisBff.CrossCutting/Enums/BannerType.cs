﻿namespace VibeBisBff.CrossCutting.Enums;

public enum BannerType
{
    BenefitSale,
    Vendor    
}
