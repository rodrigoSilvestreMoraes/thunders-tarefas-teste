﻿namespace VibeBisBff.CrossCutting.Enums
{
    public enum ParticipantExtractType
    {
        Deposit,
        Redemption,
        Cancellation,
        Reversal,
        Expiration
    }
}
