﻿namespace VibeBisBff.CrossCutting.Enums;

public enum BannerShowcaseStatus
{
    Active,
    Inactive
}

public enum BannerShowcaseItemType
{
    BenefitItem,
    BenefitVendor,
    Quest,
    UrlRedirect
}
