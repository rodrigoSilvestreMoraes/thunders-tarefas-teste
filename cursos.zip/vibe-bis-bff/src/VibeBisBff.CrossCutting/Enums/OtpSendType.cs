﻿namespace VibeBisBff.CrossCutting.Enums
{
    public enum OtpSendType
    {
        SMS,
        Whats,
        Email
    }
}
