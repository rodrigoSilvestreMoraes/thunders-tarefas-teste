﻿namespace VibeBisBff.CrossCutting.Enums
{
    public enum QuestType
    {
        Receipt,
        Redirect,
        Quiz        
    }
}
