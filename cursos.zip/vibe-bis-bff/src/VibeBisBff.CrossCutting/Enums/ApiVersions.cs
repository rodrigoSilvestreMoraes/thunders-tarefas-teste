﻿namespace VibeBisBff.CrossCutting.Enums;

public enum ApiVersions
{
    V1,
    V2
}
