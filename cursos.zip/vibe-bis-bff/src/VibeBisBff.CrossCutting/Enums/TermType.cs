﻿namespace VibeBisBff.CrossCutting.Enums;

public enum TermType
{
    UserTerm = 0,
    PrivacyPolicy = 1
}
