﻿namespace VibeBisBff.CrossCutting.Enums
{
    public enum ReceiptStatus
    {
        Reading,
        Approved,
        Reproved
    }
}
