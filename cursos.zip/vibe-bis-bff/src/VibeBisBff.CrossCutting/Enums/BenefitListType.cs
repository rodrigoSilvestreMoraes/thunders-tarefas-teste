﻿namespace VibeBisBff.CrossCutting.Enums;

public enum BenefitListType
{
    All,
    Banner,
    HomeSection    
}
