﻿namespace VibeBisBff.CrossCutting.Enums;

public enum NotificationDestinationType
{
    Email,
    PushNotification
}
