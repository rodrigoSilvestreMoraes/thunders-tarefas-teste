﻿namespace VibeBisBff.CrossCutting.Enums;

public enum AccomplishedRaffleStatus
{
    Winner,
    NotWinner
}
