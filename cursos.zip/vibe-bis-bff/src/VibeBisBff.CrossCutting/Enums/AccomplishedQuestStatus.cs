﻿namespace VibeBisBff.CrossCutting.Enums;

public enum AccomplishedQuestStatus
{
    Registered,
    Error,
    Resolved
}
