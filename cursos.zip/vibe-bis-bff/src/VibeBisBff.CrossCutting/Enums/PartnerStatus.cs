﻿namespace VibeBisBff.CrossCutting.Enums
{
    public enum PartnerStatus
    {
        Active,
        Desactive           
    }
}
