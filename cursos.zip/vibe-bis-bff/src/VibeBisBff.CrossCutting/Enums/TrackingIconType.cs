﻿namespace VibeBisBff.CrossCutting.Enums;

public enum TrackingIconType
{
    Success,
    Awaiting,
    Error
}
