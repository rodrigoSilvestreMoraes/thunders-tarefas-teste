﻿namespace VibeBisBff.CrossCutting.Enums;

public enum ApplicationType
{
    Vibe,
    VibeEmpresas
}
