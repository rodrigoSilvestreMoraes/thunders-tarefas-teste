﻿namespace VibeBisBff.CrossCutting.Enums
{
    public enum NotificationSourceEvent
    {
        AccomplishedQuest,
        ReceiptInserted,
        VibeShopPurchase,
        NewAvailableQuest,
        NewAvailableBenefit,
        GeneratedLuckyNumber
    }
}
