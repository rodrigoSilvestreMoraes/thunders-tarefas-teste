﻿namespace VibeBisBff.CrossCutting.Enums;

public enum QuestImageReceiptStatus
{
    Registered,
    ImageQrCodeProcessed,
    Processed,
    Error
}
