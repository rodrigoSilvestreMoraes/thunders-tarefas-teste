﻿namespace VibeBisBff.CrossCutting.Enums;

public enum PersonType
{
    INDIVIDUAL = 1,
    COMPANY = 2
}
