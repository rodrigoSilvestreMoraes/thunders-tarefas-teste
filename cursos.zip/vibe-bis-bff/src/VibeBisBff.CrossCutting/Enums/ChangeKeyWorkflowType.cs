﻿namespace VibeBisBff.CrossCutting.Enums;

public enum ChangeKeyWorkflowType
{
    ForgotPassword,
    ChangeCellphone,
    ChangeEmail
}
