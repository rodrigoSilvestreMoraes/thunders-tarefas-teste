﻿namespace VibeBisBff.CrossCutting.Enums;

public enum ParticipantVerificationType
{
    Cellphone,
    Email
}
