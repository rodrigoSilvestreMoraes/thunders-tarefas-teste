﻿using System.Text.RegularExpressions;
using ReverseMarkdown;

namespace VibeBisBff.CrossCutting.Extensions;

public static class MarkdownHelper
{
    public static string ConvertHtmlTextToMarkdown(this string textWithHtml,
        MarkdownHelperConfiguration markdownHelperConfiguration = null)
    {
        var config = new Config
        {
            GithubFlavored = true,
            UnknownTags = Config.UnknownTagsOption.Drop,
            PassThroughTags = new[] {"**"}
        };

        var converter = new Converter(config);

        if (markdownHelperConfiguration is { ShouldConvertHTagToBold: true })
            textWithHtml = ReplaceHTagToBold(textWithHtml);

        var result = converter.Convert(textWithHtml);

        result = result.Replace("\\*", "*");

        return result;
    }

    public static string InBold(string text) => $"**{text}**";

    private static string ReplaceHTagToBold(string textToReplace) => Regex.Replace(textToReplace, @"\\{0,}<\s*\/*h[^>]*>", "**");
}
