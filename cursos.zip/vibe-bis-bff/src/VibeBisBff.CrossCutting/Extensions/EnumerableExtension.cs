﻿namespace VibeBisBff.CrossCutting.Extensions;

public static class EnumerableExtension
{
    public static bool IsNullOrEmpty<T>(this IEnumerable<T> enumerable)
        => !enumerable?.Any() ?? true;
}
