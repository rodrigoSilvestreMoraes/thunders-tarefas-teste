﻿namespace VibeBisBff.CrossCutting.Extensions;

public class MarkdownHelperConfiguration
{
    public bool ShouldConvertHTagToBold { get; set; }
}
