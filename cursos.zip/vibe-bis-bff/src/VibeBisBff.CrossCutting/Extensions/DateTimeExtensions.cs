﻿namespace VibeBisBff.CrossCutting.Extensions
{
    public static class DateTimeExtensions
    {
        public static string FormatToYearMonthDay(this DateTime dateTime) =>
            dateTime.ToString("yyyy-MM-dd");

        public static string ToRfc3339(this DateTime date)
            => date.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss.fffK");
    }
}
