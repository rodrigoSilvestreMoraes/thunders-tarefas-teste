﻿using VibeBisBff.CrossCuting.Dto.Tag;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Extensions;
using VibeBisBff.Dto.Benefit;
using VibeBisBff.Dto.Benefit.V2;
using VibeBisBff.Dto.Offer;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;

namespace VibeBisBff.Application.Mappers.Benefits;

public static class BenefitV2Profile
{
    public static BenefitDetailV2Dto MapBenefit(AdvertisementDataDto advertisement,
        TagConfigResponseDto tag,
        bool isSoldOff,
        List<RulesOfferDto> rules,
        string descriptionCleanImg)
    {
        var response = new BenefitDetailV2Dto
        {
            Id = advertisement.EligibleProduct.Products[0].Code,
            Name = advertisement.Name,
            BenefitDetailId = advertisement.Id,
            Description = descriptionCleanImg,       
            Order = int.Parse(advertisement.Attributes.Find(attribute => attribute.Key == "ranking")?.Value.RemoveHtmlTags() ?? "9999"),

            Image = advertisement.Store?.Chain?.Images?.Find(image => image.Tag == BenefitConstants.CARD_IMAGE_TAG)?.Url,
            BannerImage = advertisement.Store?.Chain?.Images?.Find(image => image.Tag == BenefitConstants.BANNER_IMAGE_TAG)?.Url,
            DetailImage = advertisement.Store?.Chain?.Images?.Find(image => image.Tag == BenefitConstants.DETAIL_IMAGE_TAG)?.Url,

            CategoryId = advertisement.Store?.Chain?.CategoryInfo?.Id,
            CategoryName = advertisement.Store?.Chain?.CategoryInfo?.Name,
            Value = advertisement.ActivationCondition?.FirstLevelCondition?.AvailableWalletBalance?.AvailableAmount?.Amount ?? 0,
            Vendor = new BenefitVendorDto
            {
                Name = advertisement.Store?.Chain?.Name,
                Id = long.Parse(advertisement.Store?.Chain?.Id ?? "0")
            },
            Tag = tag,
            IsSoldOff = isSoldOff,
            Rules = rules,
            HasV2 = rules.Any()
        };

        return response;
    }
}
