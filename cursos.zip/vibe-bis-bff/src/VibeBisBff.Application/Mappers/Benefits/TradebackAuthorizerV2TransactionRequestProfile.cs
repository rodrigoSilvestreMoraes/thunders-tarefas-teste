﻿using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;

namespace VibeBisBff.Application.Mappers.Benefits;

public static class TradebackAuthorizerV2TransactionRequestProfile
{
    public static AuthorizerV2TransactionRequestDto MapToBenefitRequest(
        DigitalAccountParticipantDetail digitalAccountParticipantDetail, string vendorId, string benefitId)
    {
        return new AuthorizerV2TransactionRequestDto
        {
            PartnerTransactionId = Guid.NewGuid().ToString(),
            Merchant = new AuthorizerV2MerchantDto
            {
                Id = vendorId.PadLeft(14, '0')
            },
            Participant = new AuthorizerV2ParticipantDto
            {
                Cellphone = digitalAccountParticipantDetail.GetCellphone(),
                Email = digitalAccountParticipantDetail.GetEmail(),
                Id = digitalAccountParticipantDetail.UserDocument,
                DigitalAccountId = digitalAccountParticipantDetail.Id
            },
            CampaignIds = new List<string>(),
            Products = new List<AuthorizerV2ProductDto>
            {
                new()
                {
                    Id = benefitId,
                    Code = benefitId,
                    Quantity = 1,
                    UnitaryValue = 1
                }
            }
        };
    }
}
