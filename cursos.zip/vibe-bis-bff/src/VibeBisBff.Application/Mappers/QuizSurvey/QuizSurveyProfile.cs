﻿using VibeBisBff.CrossCuting.Dto.Quiz.Register;
using VibeBisBff.ExternalServices.Tradeback.QuizTransaction.Dto.Register;

namespace VibeBisBff.Application.Mappers.QuizSurvey;

public static class QuizSurveyProfile
{
    public static QuizRegisterAnswerDto MapQuiz(this QuizRegisterAnswerRequest request, string participantId)
    {
        return new QuizRegisterAnswerDto
        {
            Id = request.Id,
            ParticipantId = participantId,
            Answers = request.Answers.Select(x => new QuizRegisterDetailAnswersDto
            {
                QuestionId = x.QuestionId,
                ParticipantAlternatives = x.ParticipantAlternatives
            }).ToList()
        };
    }

    public static SurveyRegisterAnswerDto MapSurvey(this QuizRegisterAnswerRequest request, string participantId)
    {
        return new SurveyRegisterAnswerDto
        {
            Id = request.Id,
            ParticipantId = participantId,
            Answers = request.Survey.Select(x => new SurveyRegisterDetailAnswersDto
            {
                QuestionId = x.QuestionId,
                ParticipantAlternatives = x.ParticipantAlternatives.Select(y => new SurveyDetailAnswersDto
                {
                    AlternativeId = y.AlternativeId,
                    Value = y.Value
                }).ToList()
            }).ToList()
        };
    }
}
