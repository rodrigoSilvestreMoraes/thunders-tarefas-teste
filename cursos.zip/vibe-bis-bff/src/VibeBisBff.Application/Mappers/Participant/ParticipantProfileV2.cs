﻿using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;

namespace VibeBisBff.Application.Mappers.Participant;

public static class ParticipantProfileV2
{
    public static DigitalAccountParticipantCreate MapToDigitalAccountCreate(ParticipantsRegisterRequestDto request)
    {
        var isCompany = (request.AppType == ApplicationType.VibeEmpresas ||
                         !string.IsNullOrWhiteSpace(request.TenantConfigId));

        var response = new DigitalAccountParticipantCreate
        {
            PersonName = request.Name.Trim(),
            BirthDate = request.BirthDate,
            PersonTypeEnumId = isCompany ? (int)PersonType.COMPANY : (int)PersonType.INDIVIDUAL,
            DocumentTypeEnumId = isCompany ? DocumentType.CNPJ : DocumentType.CPF,
            Country = request.Address.Country,
            EmailList = new List<EmailListItems> { new() { EmailTypeEnumId = 1, Email = request.Email } },
            PhoneList = new List<PhoneListItems>
            {
                new()
                {
                    PhoneTypeEnumId = 1,
                    DDI = int.Parse(request.Cellphone[..2]),
                    DDD = int.Parse(request.Cellphone[2..4]),
                    Number = int.Parse(request.Cellphone[4..])
                }
            },
            RandomKey = request.Document,
            UserDocument = request.Document,
            AdressList = new List<AdressListItems>
            {
                new()
                {
                    City = request.Address.City,
                    Country = request.Address.Country,
                    AdressTypeEnumId = 1,
                    District = request.Address.District,
                    Number = request.Address.Number,
                    PostalCode = request.Address.PostalCode,
                    State = request.Address.State,
                    Complement = request.Address.Complement,
                    Reference = request.Address.Reference,
                    Street = request.Address.Street
                }
            }
        };

        return response;
    }
}
