﻿using AutoMapper;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCutting.Extensions;
using VibeBisBff.Dto.Participants;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.ExternalServices.Vertem.Terms.Dto;

namespace VibeBisBff.Application.Mappers.Participant;

public class ParticipantProfile : Profile
{
    public ParticipantProfile()
    {
        CreateMap<ParticipantAddressDto, DigitalAccountAddressDto>()
            .ForMember(dest => dest.AddressTypeId,
                opt => opt.MapFrom(_ => "62c7118af628272722a847b3"));

        CreateMap<CartShippingAddressDto, ParticipantAddressDto>()
            .ForMember(dist => dist.PostalCode,
                opt => opt.MapFrom(src => src.ZipCode));

        CreateMap<DigitalAccountAddressDto, ParticipantAddressDto>();

        CreateMap<ProductDto, ProductToRevisionDto>();

        CreateMap<DigitalAccountParticipantDetail, ParticipantDetailDto>()
            .ForMember(dest => dest.PhoneNumber, y =>
                y.MapFrom(src =>
                    src.GetCellphone()))
            .ForMember(dest => dest.Account,
                opt =>
                    opt.MapFrom((_, _, _, context) => context.Items["accountDetails"]))
            .ForMember(dest => dest.Address, opt =>
                opt.MapFrom(src => src.DigitalAccountAddresses[0]))
            .ForMember(dest => dest.Document, opt =>
                opt.MapFrom(src => src.UserDocument))
            .ForMember(dest => dest.Email, opt =>
                opt.MapFrom(src =>
                    string.IsNullOrWhiteSpace(src.GetEmail()) ? src.DigitalAccountEmails[0].Email : src.GetEmail()))
            .ForMember(dest => dest.PhoneNumber, opt =>
                opt.MapFrom(src => src.GetCellphone()))
            .ForMember(dest => dest.Name, opt =>
                opt.MapFrom(x => x.Name.Trim()));

        CreateMap<ParticipantsRegisterRequestDto, CreateUserWithPasswordRequestDto>()
            .ForMember(dest => dest.BirthDate,
                opt => opt.MapFrom(src => src.BirthDate.FormatToYearMonthDay()))
            .ForMember(dest => dest.RandomKey,
                opt => opt.MapFrom(src => src.Document));

        CreateMap<ParticipantsRegisterRequestHeaderDto, AcceptTermsRequestDto>();
    }
}
