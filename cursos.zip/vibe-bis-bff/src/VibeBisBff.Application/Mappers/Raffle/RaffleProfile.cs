﻿using AutoMapper;
using VibeBisBff.CrossCuting.Dto.Raffles;
using VibeBisBff.CrossCuting.Dto.Raffles.Aggregation;

namespace VibeBisBff.Application.Mappers.Raffle;

public class RaffleProfile : Profile
{
    public RaffleProfile()
    {
        CreateMap<RaffleGroupAggregationDto, RaffleGroupDto>();
        CreateMap<RaffleAggregationDto, RaffleDto>();
    }
}
