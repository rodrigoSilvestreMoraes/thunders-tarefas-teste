﻿using VibeBisBff.Dto.Offer;
using VibeBisBff.Dto.Quests.V2;
using VibeBisBff.ExternalServices.Tradeback.Promo.Adm.Dto;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;

namespace VibeBisBff.Application.Mappers.Quest;

public static class QuestV2Profile
{
    public static QuestDetailV2Dto MapQuest(AdvertisementDataDto quest,
        bool isAccomplished,
        List<RulesOfferDto> rules,
        string descriptionCleanImg,
        List<EligiblesProcutResponseDto> products)
    {
        var response = new QuestDetailV2Dto
        {
            Id = quest.Id,
            Name = quest.Name,
            Description = descriptionCleanImg,
            Title = quest.Name,
            CampaignName = quest.Campaign?.Name ?? string.Empty,
            QuizId = quest.QuizId,
            Redirect = quest.Redirect,
            IsRegular = quest.IsRegular,
            Type = quest.QuestType,
            Value = quest.Benefit!.Credit.Amount,
            HasSpending = quest.ActivationCondition?.SecondLevelCondition?.SpendingBehavior
                ?.SpendingBehaviorSettingsId != null,
            IsAccomplished = isAccomplished,
            Image = quest.Image,
            BannerImage = quest.BannerImage,
            DetailImage = quest.DetailImage,
            ListImage = quest.ListImage,
            Rules = rules,
            HasV2 = rules.Any(),
            Products = products.Select(x => x.Name).ToList()
        };

        return response;
    }
}
