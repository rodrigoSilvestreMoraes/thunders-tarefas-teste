﻿using AutoMapper;
using VibeBisBff.Dto.Quests;
using VibeBisBff.ExternalServices.Tradeback.SpendingBehaviorManagement.Dto;

namespace VibeBisBff.Application.Mappers.Quest;

public class QuestProfile : Profile
{
    public QuestProfile()
    {
        CreateMap<SpentDetailResponseDto, AccomplishedQuestSpendingResponseDto>()
            .ForMember(dest => dest.PrizeLimitReached, opt => opt.MapFrom(src => src.PrizeLimitReached))
            .ForMember(dest => dest.TotalValueToBeRewarded, opt => opt.MapFrom(src => src.Balance ))
            .ForMember(dest => dest.RemainingSpendToBeRewarded, opt => opt.MapFrom(src => src.RemainingSpendToBeRewarded))
            .ForMember(dest => dest.TotalSpending, opt => opt.MapFrom(src => src.TotalSpending));
    }
}
