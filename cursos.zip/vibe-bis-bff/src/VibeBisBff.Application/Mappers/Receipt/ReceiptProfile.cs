﻿using AutoMapper;
using Common.Core.Exceptions;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer.Dto;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Enums.External.TradebackReceiptAuthorizer;
using VibeBisBff.Domain.Entities.Benefit;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;

namespace VibeBisBff.Application.Mappers.Receipt
{
    public class ReceiptProfile : Profile
    {
        public ReceiptProfile()
        {
            CreateMap<AdvertisementData, AdvertisementDataDto>().ReverseMap();
            CreateMap<AdvertisementBenefit, AdvertisementBenefitDto>().ReverseMap();

            CreateMap<AdvertisementCampaign, AdvertisementDataCampaignDto>().ReverseMap();

            CreateMap<AdvertisementCreditBenefit, AdvertisementCreditBenefitDto>().ReverseMap();
            CreateMap<AdvertisementImage, PromoImageDto>().ReverseMap();
            CreateMap<Attributes, AttributesDto>().ReverseMap();

            CreateMap<ReceiptResponseExternalServiceDto, ReceiptResponseDto>() // Source / Destination
                .ForMember(dest => dest.TotalItems, opt => opt.MapFrom(src => src.NumberOfRows))
                .ForMember(dest => dest.Items, opt => opt.MapFrom(src => src.Data));

            CreateMap<ReceiptExternalServiceDto, ReceiptDto>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.Status, opt => opt.MapFrom((src, _) => GetReceiptStatus(src.Reading.Status)))
                .ForMember(dest => dest.StoreName, opt => opt.MapFrom(src => src.Merchant.Name))
                .ForMember(dest => dest.OrderDate, opt => opt.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.Products, opt => opt.MapFrom(src => src.Items));

            CreateMap<ReceiptProductExternalServiceDto, ReceiptProductDto>()
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Description))
                .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.UnitaryValue))
                .ForMember(dest => dest.Quantity, opt => opt.MapFrom(src => src.Amount));
        }

        private static ReceiptStatus GetReceiptStatus(ReceiptReadingStatus status)
        {
            return status switch
            {
                ReceiptReadingStatus.Pending or ReceiptReadingStatus.Processing
                    => ReceiptStatus.Reading,
                ReceiptReadingStatus.Success or ReceiptReadingStatus.ProcessedByCache => ReceiptStatus.Approved,
                ReceiptReadingStatus.Failed => ReceiptStatus.Reproved,
                _ => throw new BusinessException("Invalid receipt status")
            };
        }
    }
}
