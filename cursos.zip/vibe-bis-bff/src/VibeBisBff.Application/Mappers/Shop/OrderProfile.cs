﻿using AutoMapper;
using VibeBisBff.Domain.Models;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;

namespace VibeBisBff.Application.Mappers.Shop;

public class OrderProfile : Profile
{
    public OrderProfile()
    {
        CreateMap<MarketplaceOrderDeliveryAddressDto, OrderAddress>();
    }
}
