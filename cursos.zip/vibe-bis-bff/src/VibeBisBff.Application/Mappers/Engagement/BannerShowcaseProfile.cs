﻿using AutoMapper;
using VibeBisBff.CrossCuting.Dto.Engagement;
using VibeBisBff.Domain.Entities.Banners;

namespace VibeBisBff.Application.Mappers.Engagement;

public class BannerShowcaseProfile : Profile
{
    public BannerShowcaseProfile()
    {
        CreateMap<BannerShowcaseItem, BannerItemDto>()
            .ForMember(x => x.ItemType, opt => opt.MapFrom(y => y.Type));

        CreateMap<BannerShowcase, ShowcaseResponseDto>()
            .ForMember(dest => dest.Banners, opt =>
                opt.MapFrom(src => src.Items));
    }
}
