﻿using VibeBisBff.Dto.Notifications;

namespace VibeBisBff.Application.Mappers.Notification;

public static class NotificationMapper
{
    public static NotificationResponseDto Map(Domain.Entities.Notifications.Notification notification)
    {
        return new NotificationResponseDto
        {
            Id = notification.Id,
            Title = notification.Title,
            Description = notification.Description,
            Image = notification.Image,
            GeneratedDate = notification.GeneratedDate,
            SourceEvent = notification.SourceEvent,
            Read = notification.Read
        };
    }
}
