﻿using AutoMapper;
using DnsClient.Protocol.Options;
using System.Reflection.Emit;
using VibeBisBff.CrossCuting.Dto.Engagement;
using VibeBisBff.CrossCuting.Dto.Tag;
using VibeBisBff.Domain.Entities.Banners;
using VibeBisBff.Domain.Entities.Tag;

namespace VibeBisBff.Application.Mappers.Tag;

public class TagProfile : Profile
{
    public TagProfile()
    {
        CreateMap<TagConfig, TagConfigResponseDto>();
    }
}
