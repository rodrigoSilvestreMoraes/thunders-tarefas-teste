﻿using AutoMapper;
using VibeBisBff.Dto.Wallet;

namespace VibeBisBff.Application.Mappers.Wallets;

public class ExtractExpirationPointsProfile : Profile
{
    public ExtractExpirationPointsProfile()
    {
        CreateMap<CreditExpireDetailResponseDto, ExtractExpirationPointsResponseDto>()
            .ForMember(dest => dest.TransactionId, opt => opt.MapFrom(src => src.TransactionId.ToString()))
            .ForMember(dest => dest.OriginId, opt => opt.MapFrom(src => src.CreditStampedId));
    }
}
