﻿using VibeBisBff.ExternalServices.Tradeback.Authorizer.Dto;

namespace VibeBisBff.Application.Helpers.External;

public static class TradebackAuthorizerHelper
{
    private const int BENEFIT_CREDIT_TYPE = 4;

    public static bool IsCreditBenefit(int benefitTypeId) => benefitTypeId == BENEFIT_CREDIT_TYPE;

    public static List<CartProductItemDto> GetDefaultCartItems() => new()
    {
        new CartProductItemDto
        {
            Quantity = 1,
            UnitaryValue = 10,
            ProductCode = "9999999999999",
        }
    };
}
