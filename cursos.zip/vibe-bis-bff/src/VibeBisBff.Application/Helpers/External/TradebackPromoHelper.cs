﻿using Mapster;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Extensions;
using VibeBisBff.Dto;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;

namespace VibeBisBff.Application.Helpers.External;

public static class TradebackPromoHelper
{
    public static void BuildPlaceFilter(CompanySearchFilterDto filter,
        GeolocationFilterRequestDto geolocationFilterRequestDto, string zipCode, int defaultMaxDistance)
    {
        filter ??= new CompanySearchFilterDto();

        if (geolocationFilterRequestDto.HasValidLocationFilter())
        {
            filter.GeoNear = BuildGeolocationFilter(geolocationFilterRequestDto, defaultMaxDistance);
            return;
        }

        filter.ZipCode = zipCode.Replace("-", "");
    }

    public static void BuildPlaceFilter(AdvertisementSearchFilterDto filter,
        GeolocationFilterRequestDto geolocationFilterRequestDto, string zipCode, int defaultMaxDistance)
    {
        if (geolocationFilterRequestDto.HasValidLocationFilter())
        {
            filter.GeoNear = BuildGeolocationFilter(geolocationFilterRequestDto, defaultMaxDistance);
            return;
        }

        filter.Zipcode = zipCode.Replace("-", "");
    }

    public static decimal
        GetLowestBenefitValueByCompanyAttribute(this CompanySearchResponseDataDto companySearchItem) =>
        decimal.Parse(companySearchItem.Attributes?
            .Find(x => x.Key == Constants.PROMO_COMPANY_LOWEST_BENEFIT_VALUE_ATTRIBUTE_KEY)?.Value ?? "0");

    public static List<CompanySearchResponseDataDto> GetCompaniesOnlyWithSales(
        List<CompanySearchResponseDataDto> companies) =>
        companies.IsNullOrEmpty()
            ? companies
            : companies.Where(x => x.SalesAmount > 0).ToList();

    public static IEnumerable<CompanySearchResponseDataDto> OrderCompaniesByRankingAttributeAndId(
        List<CompanySearchResponseDataDto> companies)
    {
        if (companies.IsNullOrEmpty())
            return companies;

        return companies.OrderBy(x =>
                int.Parse(x.Attributes.Find(attribute => attribute.Key == "ranking")?.Value ?? "9999"))
            .ThenBy(x => x.Id);
    }

    private static GeolocationFilterDto BuildGeolocationFilter(
        GeolocationFilterRequestDto geolocationFilterRequestDto, int defaultMaxDistance)
    {
        return new GeolocationFilterDto
        {
            MaxDistance = defaultMaxDistance,
            Location = geolocationFilterRequestDto.Adapt<GeolocationDto>()
        };
    }
}
