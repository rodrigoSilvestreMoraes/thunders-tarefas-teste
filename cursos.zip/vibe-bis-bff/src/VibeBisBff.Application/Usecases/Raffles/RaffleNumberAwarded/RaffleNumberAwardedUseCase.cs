﻿using System.Text.Json;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Usecases.Raffles.RaffleIntegration;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Domain.Repositories.MongoDb.PromoCode;
using VibeBisBff.Domain.Repositories.MongoDb.Raffle;
using VibeBisBff.Dto.RaffleNumberAwarded;
using VibeBisBff.ExternalServices.Icatu;
using VibeBisBff.Infra.ServiceBus;

namespace VibeBisBff.Application.Usecases.Raffles.RaffleNumberAwarded;

public class RaffleNumberAwardedUseCase : IRaffleNumberAwardedUseCase
{
    private readonly IRaffleRepository _raffleRepository;
    private readonly IDistributedPromoCodeRepository _distributedPromoCodeRepository;

    private readonly IRaffleIntegrationExternalService _raffleIntegrationExternalService;
    private readonly IServiceBus _messageBroker;

    private readonly VertemLogsLogger _logger;
    private const string TITLE_LOG = "Realização do Sorteio";

    public RaffleNumberAwardedUseCase(
        IRaffleRepository raffleRepository,
        IDistributedPromoCodeRepository distributedPromoCodeRepository,
        IRaffleIntegrationExternalService raffleIntegrationExternalService,
        VertemLogsLogger vertemLogsLogger,
        IServiceBus messageBroker)
    {
        _raffleRepository = raffleRepository;
        _distributedPromoCodeRepository = distributedPromoCodeRepository;
        _raffleIntegrationExternalService = raffleIntegrationExternalService;
        _logger = vertemLogsLogger;
        _messageBroker = messageBroker;
    }

    public async Task Execute(CancellationToken cancellationToken)
    {
        var groupsActive = await _raffleRepository.ListActive();

        if (groupsActive is null || !groupsActive.Any())
            return;

        var groupsActiveAsDictionary = groupsActive.ToDictionary(x => x.Id);

        var filterDate = DateTime.UtcNow.Date;

        var raffleToday =
            await _raffleRepository.ListRaffleByGroupIdsAndDate(filterDate, groupsActiveAsDictionary.Keys.ToList());

        foreach (var raffle in raffleToday)
        {
            var raffleNumberResponse =
                await _raffleIntegrationExternalService.GetRaffleNumberAwarded(raffle.RaffleDate);

            if (!raffleNumberResponse.Success || string.IsNullOrEmpty(raffleNumberResponse.RaffleNumber))
            {
                await RaffleError(raffle.Id, groupsActiveAsDictionary[raffle.RaffleGroupId].Title, raffle.RaffleDate);
                continue;
            }

            var raffleNumberWinner = raffleNumberResponse.RaffleNumber;

            var winnerPromoCode = await _distributedPromoCodeRepository.GetRaffleByRaffleNumber(raffleNumberWinner);

            if (winnerPromoCode is null)
            {
                await RaffleError(raffle.Id, groupsActiveAsDictionary[raffle.RaffleGroupId].Title, raffle.RaffleDate);
                continue;
            }

            var resultUpdate =
                await _raffleRepository.UpdateRaffleWithLuckyNumberAwarded(raffle.Id, raffleNumberWinner, DateTime.Now);

            if (!resultUpdate)
            {
                await RaffleError(raffle.Id, groupsActiveAsDictionary[raffle.RaffleGroupId].Title, raffle.RaffleDate);
                continue;
            }

            var requestMessage = new RaffleResultRequestDto
            {
                RaffleNumber = winnerPromoCode.Code,
                RaffleDate = raffle.RaffleDate,
                RaffleId = raffle.Id,
                Success = true
            };

            await _messageBroker.SendMessage(MessageBrokerEntitiesNames.RAFFLE_DRAW_MESSAGES_QUEUE_NAME,
                JsonSerializer.Serialize(requestMessage));
        }
    }

    private async Task RaffleError(string raffleId, string groupTitle, DateTime raffleDate)
    {
        _logger.LogInformation(TITLE_LOG,
            $"Provedor de sorteio não retornou número da sorte, ou falhou para o sorteio Id {raffleId}, grupo: {groupTitle}:");

        await _messageBroker.SendMessage(MessageBrokerEntitiesNames.RAFFLE_DRAW_MESSAGES_QUEUE_NAME,
            JsonSerializer.Serialize(
                new RaffleResultRequestDto
                {
                    RaffleNumber = string.Empty,
                    RaffleId = raffleId,
                    RaffleDate = raffleDate,
                    Success = false
                }));
    }
}
