﻿namespace VibeBisBff.Application.Usecases.Raffles.RaffleIntegration;
public interface IRaffleNumberAwardedUseCase
{
    Task Execute(CancellationToken cancellationToken);
}
