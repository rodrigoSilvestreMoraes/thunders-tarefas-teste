﻿using VibeBisBff.CrossCuting.Dto.Raffles;

namespace VibeBisBff.Application.Usecases.Raffles.GetRaffle;
public interface IGetRaffleUseCase
{
    Task<RaffleGroupDto> Execute();
}
