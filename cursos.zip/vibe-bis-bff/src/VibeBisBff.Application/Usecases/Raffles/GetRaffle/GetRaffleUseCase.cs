﻿using AutoMapper;
using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Domain.Repositories.MongoDb.PromoCode;
using VibeBisBff.Domain.Repositories.MongoDb.Raffle;
using VibeBisBff.CrossCuting.Dto.Raffles.Aggregation;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.CrossCuting.Dto.Raffles;
using VibeBisBff.ExternalServices.Vertem.Terms;
using VibeBisBff.ExternalServices.Tradeback.SpendingBehaviorManagement;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;

namespace VibeBisBff.Application.Usecases.Raffles.GetRaffle;

public class GetRaffleUseCase : IGetRaffleUseCase
{
    private readonly IRaffleRepository _raffleRepository;
    private readonly ITermsExternalService _termsExternalService;
    private readonly IMapper _mapper;

    private readonly ITradebackSpendingBehaviorManagementExternalService
        _tradebackSpendingBehaviorManagementExternalService;

    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IDistributedPromoCodeRepository _distributedPromoCodeRepository;

    private readonly IDigitalAccountExternalService _digitalAccountExternalService;

    public GetRaffleUseCase(IRaffleRepository raffleRepository, ITermsExternalService termsExternalService,
        IMapper mapper,
        ITradebackSpendingBehaviorManagementExternalService tradebackSpendingBehaviorManagementExternalService,
        IDistributedPromoCodeRepository distributedPromoCodeRepository,
        AuthenticatedUser authenticatedUser, IDigitalAccountExternalService digitalAccountExternalService)
    {
        _raffleRepository = raffleRepository;
        _termsExternalService = termsExternalService;
        _mapper = mapper;
        _tradebackSpendingBehaviorManagementExternalService = tradebackSpendingBehaviorManagementExternalService;
        _distributedPromoCodeRepository = distributedPromoCodeRepository;
        _authenticatedUser = authenticatedUser;
        _digitalAccountExternalService = digitalAccountExternalService;
    }

    public async Task<RaffleGroupDto> Execute()
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            throw new BusinessException("Erro ao buscar o identificador do usuário");

        var raffleGroup = await _raffleRepository.GetAsync();

        if (raffleGroup is null)
            throw new BusinessException("Sorteio não encontrado");

        var raffleGroupDto = _mapper.Map<RaffleGroupDto>(raffleGroup);

        await AppendAdditionalInfoToRaffleResultInParallel(raffleGroupDto, raffleGroup,
            digitalAccountId.Value);

        raffleGroupDto.Raffles = raffleGroupDto.Raffles.OrderByDescending(x => x.StartDate).ToList();

        return raffleGroupDto;
    }

    private async Task AppendAdditionalInfoToRaffleResultInParallel(
        RaffleGroupDto raffleGroupDto, RaffleGroupAggregationDto raffleAggregationResult, string digitalAccountId)
    {
        var appendSummaryRegulationTask = Task.Run(async () =>
            await AppendTermsContentToRegulationOnRaffleGroup(raffleGroupDto, raffleAggregationResult));

        var appendReceivedLuckyNumbersToRafflesTask = Task.Run(async () =>
            await AppendReceivedLuckyNumbersAndStatusToRafflesPerPeriod(raffleGroupDto.Raffles, digitalAccountId));

        var appendSpentDetailToRaffleGroupTask = Task.Run(async () =>
            await AppendSpentDetailToRaffleGroup(raffleGroupDto, raffleAggregationResult));

        await Task.WhenAll(appendSummaryRegulationTask, appendReceivedLuckyNumbersToRafflesTask,
            appendSpentDetailToRaffleGroupTask);
    }

    private async Task AppendTermsContentToRegulationOnRaffleGroup(RaffleGroupDto raffleGroupDto,
        RaffleGroupAggregationDto raffleGroupAggregationDto)
    {
        var appendSummaryRegulationTask = Task.Run(async () =>
        {
            raffleGroupDto.SummaryRegulation =
                await _termsExternalService.GetTermContentAsStringForLastFileVersion(raffleGroupAggregationDto
                    .SummaryRegulationTermId);
        });

        var appendFullRegulationUrlTask = Task.Run(async () =>
        {
            raffleGroupDto.FullRegulationUrl =
                (await _termsExternalService.GetTermById(raffleGroupAggregationDto.FullRegulationTermId))?.Data
                ?.GetFileForLastVersion()?.ContentUrl;
        });

        await Task.WhenAll(appendSummaryRegulationTask, appendFullRegulationUrlTask);
    }

    private async Task AppendReceivedLuckyNumbersAndStatusToRafflesPerPeriod(List<RaffleDto> raffles,
        string digitalAccountId)
    {
        if (raffles is null || !raffles.Any())
            return;

        var getMostOldStartDateRaffle = raffles.MinBy(x => x.StartDate);

        var getMostRecentEndDateRaffle = raffles.MaxBy(x => x.EndDate);

        var userReceivedLuckyNumbersInRafflesRange = await _distributedPromoCodeRepository
            .GetAllByPeriodAndDigitalAccountId(
                getMostOldStartDateRaffle.StartDate, getMostRecentEndDateRaffle.EndDate, digitalAccountId);

        foreach (var raffle in raffles)
        {
            var assignedLuckyNumbersOnRafflePeriod = userReceivedLuckyNumbersInRafflesRange
                .Where(receivedLuckyNumber =>
                    receivedLuckyNumber.CreatedDate >= raffle.StartDate &&
                    receivedLuckyNumber.CreatedDate <= raffle.EndDate);

            // ReSharper disable once PossibleMultipleEnumeration
            raffle.ReceivedLuckyNumbers = assignedLuckyNumbersOnRafflePeriod
                .Select(receivedLuckyNumber => receivedLuckyNumber.Code).ToList();

            // ReSharper disable once PossibleMultipleEnumeration
            raffle.AssignedLuckyNumbers = assignedLuckyNumbersOnRafflePeriod.Select(x => new AssignedLuckyNumberDto
            {
                Code = x.Code,
                AssignedDate = x.CreatedDate
            }).ToList();

            raffle.Status = GetRaffleStatus(raffle);

            raffle.AnnouncementDate = raffle.RaffleDate.Date.AddDays(4);

            //TODO: Tratativa temporária enquanto o front não altera para o novo campo
            raffle.EndDate = !string.IsNullOrWhiteSpace(raffle.LuckyNumberAwarded)
                ? raffle.RaffleDate
                : raffle.AnnouncementDate;
        }

        raffles.RemoveAll(x =>
            x.ReceivedLuckyNumbers is null || !x.ReceivedLuckyNumbers.Any() &&
            x.Status is RaffleStatus.NotWinner or RaffleStatus.Awaiting);
    }

    private async Task AppendSpentDetailToRaffleGroup(RaffleGroupDto raffleGroupDto,
        RaffleGroupAggregationDto raffleGroupAggregationDto)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            throw new BusinessException(ErrorConstants.GENERIC_ERROR);

        var userOnDigitalAccount =
            await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        var spentDetail = await _tradebackSpendingBehaviorManagementExternalService
            .GetSpentDetail(raffleGroupAggregationDto.SpendingSettingsId, userOnDigitalAccount!.UserDocument);

        var hasAlreadySpentSomething = spentDetail.Value != null && spentDetail.Value.Any();

        if (!hasAlreadySpentSomething)
        {
            var spendingSettingsDetail =
                await _tradebackSpendingBehaviorManagementExternalService.GetSettingsById(raffleGroupAggregationDto
                    .SpendingSettingsId);

            raffleGroupDto.SpentBalance = new RaffleSpentBalanceDto
            {
                CurrentAccumulatedInVirtualCoins = 0,
                RemainingVirtualCoinsToReceiveLuckyNumber = spendingSettingsDetail.Value?.SpentValueToBeRewarded ?? 0,
            };

            return;
        }

        var spentDetailValue = spentDetail.Value[0];

        raffleGroupDto.SpentBalance = new RaffleSpentBalanceDto
        {
            CurrentAccumulatedInVirtualCoins = spentDetailValue.Balance,
            RemainingVirtualCoinsToReceiveLuckyNumber =
                spentDetailValue.RemainingSpendToBeRewarded
        };
    }


    private static RaffleStatus GetRaffleStatus(RaffleDto raffle)
    {
        if (raffle.LuckyNumberAwarded is null)
            return RaffleStatus.Awaiting;

        if (raffle.ReceivedLuckyNumbers is null)
            return RaffleStatus.NotWinner;

        return raffle.ReceivedLuckyNumbers.Contains(raffle.LuckyNumberAwarded)
            ? RaffleStatus.Winner
            : RaffleStatus.NotWinner;
    }
}
