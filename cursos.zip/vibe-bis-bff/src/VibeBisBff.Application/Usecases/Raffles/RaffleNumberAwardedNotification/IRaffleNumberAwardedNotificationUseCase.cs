﻿using VibeBisBff.Dto.RaffleNumberAwarded;

namespace VibeBisBff.Application.Usecases.Raffles.RaffleNumberAwardedNotification;

public interface IRaffleNumberAwardedNotificationUseCase
{
    public Task Execute(RaffleResultRequestDto raffleResultRequestDto);
    
}
