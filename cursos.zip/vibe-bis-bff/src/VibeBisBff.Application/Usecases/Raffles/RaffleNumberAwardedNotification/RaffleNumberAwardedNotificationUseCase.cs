﻿using Microsoft.Extensions.Options;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Entities.LuckyNumber;
using VibeBisBff.Domain.Entities.Raffles;
using VibeBisBff.Domain.Repositories.MongoDb.PromoCode;
using VibeBisBff.Domain.Repositories.MongoDb.Raffle;
using VibeBisBff.Dto.RaffleNumberAwarded;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;
using VibeBisBff.ExternalServices.Vertem.Notification;
using VibeBisBff.ExternalServices.Vertem.Notification.Dto;

namespace VibeBisBff.Application.Usecases.Raffles.RaffleNumberAwardedNotification;

public class RaffleNumberAwardedNotificationUseCase : IRaffleNumberAwardedNotificationUseCase
{
    private readonly IRaffleRepository _raffleRepository;

    private readonly INotificationExternalService _notificationExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;

    private readonly IDistributedPromoCodeRepository _distributedPromoCodeRepository;

    private readonly TenantConfigOptions _tenantConfigOptions;
    private readonly RaffleResultNotificationOptions _raffleResultNotificationOptions;

    private readonly IVertemLogsLogger _logger;

    public RaffleNumberAwardedNotificationUseCase(
        IRaffleRepository raffleRepository,
        INotificationExternalService notificationExternalService,
        IDigitalAccountExternalService digitalAccountExternalService,
        IDistributedPromoCodeRepository distributedPromoCodeRepository,
        IOptionsSnapshot<TenantConfigOptions> tenantConfigOptions,
        IOptionsSnapshot<RaffleResultNotificationOptions> raffleResultNotificationOptions,
        IVertemLogsLogger logger)
    {
        _raffleRepository = raffleRepository;

        _notificationExternalService = notificationExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _distributedPromoCodeRepository = distributedPromoCodeRepository;
        _logger = logger;

        _tenantConfigOptions = tenantConfigOptions.Value;
        _raffleResultNotificationOptions = raffleResultNotificationOptions.Value;
    }

    public async Task Execute(RaffleResultRequestDto raffleResultRequestDto)
    {
        var tenantConfigId = string.IsNullOrEmpty(raffleResultRequestDto.TenantConfigId)
            ? _tenantConfigOptions.TenantConfigIdVibe
            : raffleResultRequestDto.TenantConfigId;

        var raffle = await _raffleRepository.GetById(raffleResultRequestDto.RaffleId);

        if (!raffleResultRequestDto.Success || raffleResultRequestDto.RaffleNumber is null)
        {
            await SendMessageForRaffleError(raffle, tenantConfigId);
            return;
        }

        var raffleParticipants =
            await _distributedPromoCodeRepository.GetAllByTimeRange(raffle.StartDate, raffle.EndDate);

        var promoCodeAwarded = raffleParticipants.Find(x => x.Code == raffleResultRequestDto.RaffleNumber);

        await SendMessages(raffle, raffleResultRequestDto.RaffleNumber, raffleParticipants, promoCodeAwarded,
            tenantConfigId);
    }

    private async Task SendMessages(
        Raffle raffle,
        string raffleNumber,
        List<DistributedPromoCode> rafflePromoCodes,
        DistributedPromoCode distributedPromoCodeAwarded,
        string tenantConfigId)
    {
        var digitalAccountWinner = distributedPromoCodeAwarded != null
            ? await _digitalAccountExternalService.GetDigitalAccountByDocument(
                distributedPromoCodeAwarded.ParticipantDocument, tenantConfigId: tenantConfigId)
            : null;

        var losersDigitalAccountIds = rafflePromoCodes
            .Where(x => x.DigitalAccountId != digitalAccountWinner?.Id)
            .Select(x => x.DigitalAccountId)
            .Distinct()
            .ToList();

        if (distributedPromoCodeAwarded is null)
        {
            await SendEmailToOpsTeamWhenCodeIsNotFoundOnInternalBase(raffleNumber, tenantConfigId, raffle);

            await SendLosersEmails(losersDigitalAccountIds, raffleNumber, raffle, tenantConfigId);
            return;
        }

        if (digitalAccountWinner == null)
        {
            await SendEmailToOpsTeamWhenWinnerNotFound(distributedPromoCodeAwarded.ParticipantDocument,
                distributedPromoCodeAwarded.Code, tenantConfigId, raffle);

            await SendLosersEmails(losersDigitalAccountIds, distributedPromoCodeAwarded.Code, raffle, tenantConfigId);

            return;
        }

        var hasRaffleDate =
            await _distributedPromoCodeRepository.HasRaffleDate(digitalAccountWinner.UserDocument, raffleNumber);

        if (hasRaffleDate)
            return;

        await SendWinnerEmails(digitalAccountWinner, raffle, distributedPromoCodeAwarded.Code,
            tenantConfigId);

        await SendLosersEmails(losersDigitalAccountIds,
            distributedPromoCodeAwarded.Code, raffle, tenantConfigId);
    }

    private async Task SendEmailToOpsTeamWhenWinnerNotFound(string possibleWinnerDocument, string awardedPromoCode,
        string tenantConfigId, Raffle raffle)
    {
        await SendEmail(templateId: _raffleResultNotificationOptions.TemplateIdEmailIdErrorWinner,
            messageValues: GetMessageValues(name: "N/D",
                document: possibleWinnerDocument, luckyNumber: awardedPromoCode,
                raffleDate: GetDateFormatted(raffle.RaffleDate), winnerPhoneNumber: "N/D", winnerEmail: "N/D"),
            subject:
            $"Existe um vencedor porém não foi encontrado no digital account, Id do sorteio: {raffle.Id}",
            emailTo: _raffleResultNotificationOptions.EmailTeamVertem,
            tenantConfigId: tenantConfigId);
    }

    private async Task SendEmailToOpsTeamWhenCodeIsNotFoundOnInternalBase(string awardedPromoCode,
        string tenantConfigId, Raffle raffle)
    {
        await SendEmail(templateId: _raffleResultNotificationOptions.TemplateIdEmailIdErrorWinner,
            messageValues: GetMessageValues(name: "Não encontrado",
                document: "N/D", luckyNumber: awardedPromoCode,
                raffleDate: GetDateFormatted(raffle.RaffleDate), winnerPhoneNumber: "N/D", winnerEmail: "N/D"),
            subject:
            $"Existe um vencedor porém o número vencedor não corresponde a nenhum em nossa base. Id do sorteio: {raffle.Id}",
            emailTo: _raffleResultNotificationOptions.EmailTeamVertem,
            tenantConfigId: tenantConfigId);
    }

    private async Task SendLosersEmails(List<string> digitalAccountIdsLosers, string awardedPromoCode, Raffle raffle,
        string tenantConfigId)
    {
        var digitalAccountLosers =
            await _digitalAccountExternalService.GetParticipantDetailsByIds(digitalAccountIdsLosers);

        foreach (var digitalAccount in digitalAccountLosers)
        {
            var messageValuesForLosers = GetMessageValues(name: digitalAccount.Name, document: string.Empty,
                luckyNumber: awardedPromoCode, raffleDate: GetDateFormatted(raffle.RaffleDate));

            await SendEmail(_raffleResultNotificationOptions.TemplateIdEmailParticipantLoserWithWinner,
                messageValuesForLosers,
                _raffleResultNotificationOptions.EmailSubjectForLosers ?? "", digitalAccount.GetEmail(),
                tenantConfigId);
        }
    }

    private async Task SendWinnerEmails(DigitalAccountParticipantDetail digitalAccountWinner, Raffle raffle,
        string awardedPromoCode, string tenantConfigId)
    {
        var messageValuesWinner = GetMessageValues(name: digitalAccountWinner.Name,
            document: digitalAccountWinner.UserDocument, luckyNumber: awardedPromoCode,
            raffleDate: GetDateFormatted(raffle.RaffleDate), winnerPhoneNumber: digitalAccountWinner.GetCellphone(),
            winnerEmail: digitalAccountWinner.GetEmail());

        var resultSendEmail = await SendEmail(
            templateId: _raffleResultNotificationOptions.TemplateIdEmailParticipantWinner,
            messageValues: messageValuesWinner,
            subject: _raffleResultNotificationOptions.EmailSubjectForWinner ?? "",
            emailTo: digitalAccountWinner.GetEmail(),
            tenantConfigId: tenantConfigId);

        await SendEmail(templateId: _raffleResultNotificationOptions.TemplateIdEmailTeamWinner,
            messageValuesWinner, $"Notificação vencedor do sorteio Vibe - {raffle.Id}",
            _raffleResultNotificationOptions.EmailTeamVertem, tenantConfigId);

        if (resultSendEmail)
            await _distributedPromoCodeRepository.UpdateRaffleDate(digitalAccountWinner.UserDocument,
                awardedPromoCode,
                raffle.RaffleDate);
    }

    private async Task SendMessageForRaffleError(Raffle raffle, string tenantConfigId)
    {
        await SendEmail(templateId: _raffleResultNotificationOptions.TemplateIdEmailIdErrorWinner,
            messageValues: GetMessageValues(name: "N/D", document: "N/D", luckyNumber: "N/D",
                raffleDate: GetDateFormatted(raffle.RaffleDate), winnerPhoneNumber: "N/D", winnerEmail: "N/D"),
            subject: $"Falha no processamento do sorteio Id {raffle.Id}",
            emailTo: _raffleResultNotificationOptions.EmailTeamVertem,
            tenantConfigId: tenantConfigId);
    }

    private async Task<bool> SendEmail(string templateId, Dictionary<string, string> messageValues, string subject,
        string emailTo, string tenantConfigId)
    {
        try
        {
            var result = await _notificationExternalService.SendEmail(new SendEmailRequestDto
            {
                TemplateId = templateId,
                Parameters = messageValues,
                Subject = subject,
                To = new List<string> { emailTo }
            }, tenantConfigId: tenantConfigId);

            return result.success;
        }
        catch (Exception ex)
        {
            _logger.LogError(new ExceptionLog(ex));
            return false;
        }
    }

    private static string GetDateFormatted(DateTime date) => date.ToString("dd/MM/yyyy");

    private static Dictionary<string, string> GetMessageValues(string name, string document, string luckyNumber,
        string raffleDate, string winnerPhoneNumber = null, string winnerEmail = null)
    {
        var messageValues = new Dictionary<string, string>();

        if (!string.IsNullOrEmpty(name))
            messageValues.Add("name", name);

        if (!string.IsNullOrEmpty(document))
            messageValues.Add("document", document);

        if (!string.IsNullOrEmpty(luckyNumber))
            messageValues.Add("luckyNumber", luckyNumber);

        if (!string.IsNullOrEmpty(raffleDate))
            messageValues.Add("raffleDate", raffleDate);

        if (!string.IsNullOrWhiteSpace(winnerPhoneNumber))
            messageValues.Add("phoneNumber", winnerPhoneNumber);

        if (!string.IsNullOrWhiteSpace(winnerEmail))
            messageValues.Add("email", winnerEmail);

        return messageValues;
    }
}
