﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Shop;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.Infra.Auth;

namespace VibeBisBff.Application.Usecases.Shop.GetCardBrands;

public class GetCardBrandsUseCase : IGetCardBrandsUseCase
{
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthTokenAccessor _authTokenAccessor;

    public GetCardBrandsUseCase(IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthTokenAccessor authTokenAccessor)
    {
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _authTokenAccessor = authTokenAccessor;
    }
    public async Task<ErrorOr<List<CardBrandsResponseDto>>> Execute() =>
        await _vertemMarketplaceExternalService.GetCardBrands(_authTokenAccessor.AccessToken);
}
