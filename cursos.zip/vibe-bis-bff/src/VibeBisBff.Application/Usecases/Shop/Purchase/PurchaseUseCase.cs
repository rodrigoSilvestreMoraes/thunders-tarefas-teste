﻿using Common.Core.Exceptions;
using ErrorOr;
using FluentValidation;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Usecases.Shop.InsertOrder;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Calculator;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.Infra.Auth;

namespace VibeBisBff.Application.Usecases.Shop.Purchase;

public class PurchaseUseCase : IPurchaseUseCase
{
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly IValidator<CreditCardPaymentRequestDto> _validation;
    private readonly AuthTokenAccessor _tokenAccessor;
    private readonly IPurchaseValueCalculator _purchaseValueCalculator;
    private readonly IInsertOrderUseCase _insertOrderUseCase;
    private readonly VertemLogsLogger _logger;

    public PurchaseUseCase(IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        IValidator<CreditCardPaymentRequestDto> validation,
        AuthTokenAccessor tokenAccessor, IPurchaseValueCalculator purchaseValueCalculator,
        IInsertOrderUseCase insertOrderUseCase, VertemLogsLogger logger)
    {
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _validation = validation;
        _tokenAccessor = tokenAccessor;
        _purchaseValueCalculator = purchaseValueCalculator;
        _insertOrderUseCase = insertOrderUseCase;
        _logger = logger;
    }

    public async Task<ErrorOr<long>> Execute(CreditCardPaymentRequestDto creditCardPaymentRequest)
    {
        var validationResult = await _validation.ValidateAsync(creditCardPaymentRequest);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var purchaseValue = await _purchaseValueCalculator.CalculatePurchaseValueByCart();

        if (purchaseValue.IsError)
            return purchaseValue.Errors;

        creditCardPaymentRequest.PointsValue = purchaseValue.Value.TotalMoneyValueWithoutTax;

        var parentOrderId =
            await _vertemMarketplaceExternalService.PurchaseCart(creditCardPaymentRequest, _tokenAccessor.AccessToken);

        try
        {
            var insertOrderResult = await _insertOrderUseCase.Execute(parentOrderId.ToString(), purchaseValue.Value);

            if (insertOrderResult.IsError)
                throw new BusinessException(string.Join(',', insertOrderResult.Errors.Select(x => x.Description)));
        }
        catch (Exception ex)
        {
            _logger.LogError(new ExceptionLog(ex));
        }

        return parentOrderId;
    }
}
