﻿using ErrorOr;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;

namespace VibeBisBff.Application.Usecases.Shop.Purchase;
public interface IPurchaseUseCase
{
    Task<ErrorOr<long>> Execute(CreditCardPaymentRequestDto creditCardPaymentRequest);
}
