﻿using Common.Core.Exceptions;
using ErrorOr;
using Microsoft.Extensions.Options;
using System.Collections.Concurrent;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.CrossCuting.Dto.Shop;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Entities.Benefit.Mapper;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Helpers;

namespace VibeBisBff.Application.Usecases.Shop.GetItems;

public class GetShopItemsUseCase : IGetShopItemsUseCase
{
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthTokenAccessor _tokenAccessor;
    private readonly VertemMarketplaceOptions _vertemMarketplaceOptions;
    private readonly VertemLogsLogger _logger;
    private readonly ITenantService _tenantService;

    public GetShopItemsUseCase(
        IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthTokenAccessor tokenAccessor,
        IOptionsSnapshot<VertemMarketplaceOptions> vertemMarketplaceOptions,
        VertemLogsLogger logger,
        ITenantService tenantService)
    {
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _tokenAccessor = tokenAccessor;
        _vertemMarketplaceOptions = vertemMarketplaceOptions.Value;
        _logger = logger;
        _tenantService = tenantService;
    }

    public async Task<ErrorOr<List<ShopItemsDto>>> Execute()
    {
        var marketplaceOptions = await _tenantService.GetMarketplaceOptions();

        var resultFromMarketplace =
            await _vertemMarketplaceExternalService.GetProductsByShowCase<ShowCaseProductDto>(
                marketplaceOptions.ShowCaseIdForShop,
                _tokenAccessor.AccessToken,
                marketplaceOptions.CampaignId);

        var availableProducts = await GetAvailableProductsAndAppendPrice(resultFromMarketplace.Products, _tokenAccessor.AccessToken);

        return availableProducts.GroupBy(product =>
                new { product.Subcategory.Category.Id, product.Subcategory.Category.Name })
            .Select(x => new ShopItemsDto
            {
                CategoryId = x.Key.Id.ToString(),
                CategoryName = x.Key.Name,
                Products = x
                    .Select(product => new ProductDto
                    {
                        Id = product.Sku,
                        Cost = product.Price,
                        CostInCoins = product.Availability.PointsCash.PartialPoints,
                        Name = product.Name,
                        Description = product.Description,
                        DetailImages = product.Images.ToList(),
                        BannerImage = product.ImageUrl,
                        Vendor = new VendorDto
                        {
                            Id = product.Vendor.Id,
                            Name = product.Vendor.Name
                        },
                        Installments = product.Availability.Cash.Installments.Select(installment => new ShopItemInstallmentDto
                        {
                            Description = installment.Description,
                            Installment = installment.Installment,
                            Value = installment.Value
                        }).ToList()
                    }).ToList()
            }).ToList();
    }

    private async Task<ConcurrentBag<ShowCaseProductDto>> GetAvailableProductsAndAppendPrice(IEnumerable<ShowCaseProductDto> products,
        string accessToken)
    {
        var availableProducts = new ConcurrentBag<ShowCaseProductDto>();

        await Parallel.ForEachAsync(products, async (product, cancellationToken) =>
        {
            if (cancellationToken.IsCancellationRequested)
                return;

            try
            {
                var productAvailabilityResultTask = _vertemMarketplaceExternalService.GetAvailabilityAndPriceBySku(
                    new ProductAvailabilityRequestDto
                    {
                        Sku = product.Sku,
                        OriginalId = product.OriginalId,
                        VendorId = product.Vendor.Id.ToString()
                    }, _tokenAccessor.AccessToken);

                var productDetailTask = _vertemMarketplaceExternalService.GetProductDetail(product.Sku, _tokenAccessor.AccessToken);

                await Task.WhenAll(new List<Task>
                {
                    productAvailabilityResultTask,
                    productDetailTask
                });

                if (productAvailabilityResultTask.Result.Available)
                {
                    await CalculatePriceAndPoints(productAvailabilityResultTask.Result, accessToken);

                    product.Price = productAvailabilityResultTask.Result.Price;
                    product.Available = true;
                    product.Availability = productAvailabilityResultTask.Result;
                    product.Images = productDetailTask.Result.Value.Skus
                        .Find(x => x.Sku == product.Sku)
                        .Images
                        .OrderBy(x => x.Order)
                        .Select(x => x.LargeImage);
                    product.Description = MarketplaceProductHelper
                        .GetFormattedDescriptionAsMarkdownWithFeatures(productDetailTask.Result.Value.Description, FeatureProfile.Map(productDetailTask.Result.Value.Features));

                    availableProducts.Add(product);
                }
            }
            catch (Exception exception)
            {
                _logger.LogError(new ExceptionLog(exception));
            }
        });

        return availableProducts;
    }

    private async Task CalculatePriceAndPoints(ProductAvailabilityResponseDto productAvailability, string accessToken)
    {
        var catalogConfiguratons = await _vertemMarketplaceExternalService.GetCatalogConfigurations(accessToken);

        if (catalogConfiguratons.IsError)
            throw new BusinessException(catalogConfiguratons.FirstError.Description);

        productAvailability.PointsCash.PartialPoints = catalogConfiguratons.Value.CalculateCostInCoins(productAvailability.Price,
            _vertemMarketplaceOptions.PercentageInPoints);

        productAvailability.Price = catalogConfiguratons.Value.CalculateCost(productAvailability.Price,
            percentageInPoints: _vertemMarketplaceOptions.PercentageInPoints);

        productAvailability.Cash.Installments = new List<InstallmentsDto>();
    }
}
