﻿using ErrorOr;
using VibeBisBff.Dto.Shop;

namespace VibeBisBff.Application.Usecases.Shop.GetItems;

public interface IGetShopItemsUseCase
{
    Task<ErrorOr<List<ShopItemsDto>>> Execute();
}
