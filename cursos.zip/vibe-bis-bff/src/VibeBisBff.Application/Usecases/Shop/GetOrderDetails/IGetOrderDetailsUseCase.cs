﻿using VibeBisBff.Dto.Shop;

namespace VibeBisBff.Application.Usecases.Shop.GetOrderDetails
{
    public interface IGetOrderDetailsUseCase
    {
        Task<OrderDetailsDto> Execute(string parentOrderId, string vendorOrderId, string productSkuId);
    }
}
