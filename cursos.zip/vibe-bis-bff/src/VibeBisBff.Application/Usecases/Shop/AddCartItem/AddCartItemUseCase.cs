﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.MarketplaceCartItem;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Mapper;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Shop.AddCartItem;

public class AddCartItemUseCase : IAddCartItemUseCase
{
    private readonly IAddMarketplaceCartItem _addMarketplaceCartItem;
    private readonly AuthTokenAccessor _authTokenAccessor;
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;

    public AddCartItemUseCase(IAddMarketplaceCartItem addMarketplaceCartItem,
        AuthTokenAccessor authTokenAccessor,
        IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthenticationProvider authenticationProvider,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _addMarketplaceCartItem = addMarketplaceCartItem;
        _authTokenAccessor = authTokenAccessor;
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
        _digitalAccountExternalService = digitalAccountExternalService;
    }

    public async Task<ErrorOr<Success>> Execute(AddShopCartItemRequestDto addShopCartItemRequestDto)
    {
        var response = await _addMarketplaceCartItem.Execute(addShopCartItemRequestDto.ProductId, addShopCartItemRequestDto.VendorId);

        if (response.IsError) return response.Errors;

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        var cartRequestAddressDto = CartAddAddressProfile.Map(digitalAccount, addShopCartItemRequestDto.Address, _authenticatedUser.IsVibeTenant().Value);

        var addCartResponse = await _vertemMarketplaceExternalService.AddCartAddress(cartRequestAddressDto, _authTokenAccessor.AccessToken);

        if(addCartResponse.IsError)
            return addCartResponse.Errors;

        return Result.Success;
    }
}
