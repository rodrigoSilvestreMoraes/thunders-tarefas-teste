﻿using ErrorOr;
using VibeBisBff.Dto.Shop;

namespace VibeBisBff.Application.Usecases.Shop.AddCartItem;

public interface IAddCartItemUseCase
{
    Task<ErrorOr<Success>> Execute(AddShopCartItemRequestDto addShopCartItemRequestDto);
}
