﻿using VibeBisBff.Dto.Shop;

namespace VibeBisBff.Application.Usecases.Shop.GetOrders;

public interface IGetOrdersUseCase
{
    Task<List<OrderDto>> Execute();
}
