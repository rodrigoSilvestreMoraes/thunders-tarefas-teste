﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using VibeBisBff.Application.Extensions.Mappers;
using VibeBisBff.Domain.Repositories.MongoDb.Shop;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Shop.GetOrders;

public class GetOrdersUseCase : IGetOrdersUseCase
{
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthTokenAccessor _authTokenAccessor;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IOrderRepository _orderRepository;
    private const int BLOCK_SIZE_FOR_ORDERS = 50;

    public GetOrdersUseCase(IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthTokenAccessor authTokenAccessor,
        AuthenticatedUser authenticatedUser,
        IOrderRepository orderRepository)
    {
        _authTokenAccessor = authTokenAccessor;
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _authenticatedUser = authenticatedUser;
        _orderRepository = orderRepository;
    }

    public async Task<List<OrderDto>> Execute()
    {
        var responseFromMarketplace =
            await _vertemMarketplaceExternalService.GetOrders(_authTokenAccessor.AccessToken, 0,
                BLOCK_SIZE_FOR_ORDERS);

        if (responseFromMarketplace.Total == 0)
            return new List<OrderDto>();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            throw new BusinessException(
                $"Erro ao obter o identificador do participante - {string.Join(',', digitalAccountId.Errors.Select(x => x.Code))}");

        var parentOrderIdsFromOrdersOnInternalBase =
            (await _orderRepository.GetParentOrderIdsByDigitalAccountId(digitalAccountId.Value))
            .ToList();

        responseFromMarketplace =
            FilterByOrderIdsOnInternalBase(responseFromMarketplace,
                parentOrderIdsFromOrdersOnInternalBase);

        var firstRequestOrders = responseFromMarketplace.MapToOrders();

        if (responseFromMarketplace.Total <= BLOCK_SIZE_FOR_ORDERS)
            return firstRequestOrders;

        return await GetOrdersByBatchProcess(firstRequestOrders, responseFromMarketplace.Total,
            parentOrderIdsFromOrdersOnInternalBase
        );
    }

    private async Task<List<OrderDto>> GetOrdersByBatchProcess(IEnumerable<OrderDto> ordersFromFirstRequest,
        decimal totalOfRemainingItems,
        ICollection<string> orderIdsOnInternalBase)
    {
        var numberOfIterations = Math.Ceiling(totalOfRemainingItems / BLOCK_SIZE_FOR_ORDERS);

        var ordersToReturn = new List<OrderDto>(ordersFromFirstRequest);
        var accOfOrders = 1;

        while (accOfOrders < numberOfIterations)
        {
            var responseWithOffset = await _vertemMarketplaceExternalService.GetOrders(_authTokenAccessor.AccessToken,
                accOfOrders * BLOCK_SIZE_FOR_ORDERS, BLOCK_SIZE_FOR_ORDERS);

            responseWithOffset =
                FilterByOrderIdsOnInternalBase(responseWithOffset, orderIdsOnInternalBase);

            ordersToReturn.AddRange(responseWithOffset.MapToOrders());

            accOfOrders++;
        }

        return ordersToReturn;
    }

    private static MarketplaceOrdersResponseDto FilterByOrderIdsOnInternalBase(
        MarketplaceOrdersResponseDto marketplaceOrders, ICollection<string> orderIdsInInternalBase)
    {
        marketplaceOrders.Orders = marketplaceOrders.Orders.Where(x =>
            orderIdsInInternalBase.Contains(x.ParentOrderId)).ToList();

        return marketplaceOrders;
    }
}
