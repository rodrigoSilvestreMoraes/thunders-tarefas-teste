﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Shop;

namespace VibeBisBff.Application.Usecases.Shop.GetInstallments;

public interface IGetInstallmentsUseCase
{
    Task<ErrorOr<List<ShopItemInstallmentDto>>> GetInstallments();
}
