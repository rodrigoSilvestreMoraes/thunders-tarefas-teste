﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Shop;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Calculator;
using VibeBisBff.Infra.Auth;

namespace VibeBisBff.Application.Usecases.Shop.GetInstallments;

public class GetInstallmentsUseCase : IGetInstallmentsUseCase
{
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthTokenAccessor _authTokenAccessor;
    private readonly IPurchaseValueCalculator _purchaseValueCalculator;

    public GetInstallmentsUseCase(IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthTokenAccessor authTokenAccessor,
        IPurchaseValueCalculator purchaseValueCalculator)
    {
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _authTokenAccessor = authTokenAccessor;
        _purchaseValueCalculator = purchaseValueCalculator;
    }

    public async Task<ErrorOr<List<ShopItemInstallmentDto>>> GetInstallments()
    {
        var purchaseValue = await _purchaseValueCalculator.CalculatePurchaseValueByCart();

        if (purchaseValue.IsError)
            return purchaseValue.Errors;

        return await _vertemMarketplaceExternalService.GetInstallments(_authTokenAccessor.AccessToken,
            purchaseValue.Value.TotalMoneyValue);
    }
}
