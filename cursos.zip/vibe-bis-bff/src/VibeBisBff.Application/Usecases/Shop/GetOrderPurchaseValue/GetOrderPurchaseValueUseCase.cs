﻿using ErrorOr;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Calculator;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;

namespace VibeBisBff.Application.Usecases.Shop.GetOrderPurchaseValue;

public class GetOrderPurchaseValueUseCase : IGetOrderPurchaseValueUseCase
{
    private readonly IPurchaseValueCalculator _purchaseValueCalculator;

    public GetOrderPurchaseValueUseCase(IPurchaseValueCalculator purchaseValueCalculator)
    {
        _purchaseValueCalculator = purchaseValueCalculator;
    }

    public async Task<ErrorOr<PurchaseValueResponseDto>> Execute() =>
        await _purchaseValueCalculator.CalculatePurchaseValueByCart();
}
