﻿using ErrorOr;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;

namespace VibeBisBff.Application.Usecases.Shop.GetOrderPurchaseValue;

public interface IGetOrderPurchaseValueUseCase
{
    Task<ErrorOr<PurchaseValueResponseDto>> Execute();
}
