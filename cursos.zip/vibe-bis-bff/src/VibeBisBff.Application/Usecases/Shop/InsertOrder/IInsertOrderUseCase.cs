﻿using ErrorOr;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;

namespace VibeBisBff.Application.Usecases.Shop.InsertOrder
{
    public interface IInsertOrderUseCase
    {
        Task<ErrorOr<Success>> Execute(string parentOrderId, PurchaseValueResponseDto orderValueSummary);
    }
}
