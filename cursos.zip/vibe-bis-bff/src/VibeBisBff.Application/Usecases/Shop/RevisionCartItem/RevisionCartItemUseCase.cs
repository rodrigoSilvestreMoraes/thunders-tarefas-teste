﻿using AutoMapper;
using ErrorOr;
using VibeBisBff.Application.Usecases.Shop.GetItems;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.Infra.Auth;

namespace VibeBisBff.Application.Usecases.Shop.RevisionCartItem;

public class RevisionCartItemUseCase : IRevisionCartItemUseCase
{
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthTokenAccessor _authTokenAccessor;
    private readonly IMapper _mapper;
    private readonly IGetShopItemsUseCase _getShopItemsUseCase;

    public RevisionCartItemUseCase(IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthTokenAccessor authTokenAccessor,
        IMapper mapper,
        IGetShopItemsUseCase getShopItemsUseCase)
    {
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _authTokenAccessor = authTokenAccessor;
        _mapper = mapper;
        _getShopItemsUseCase = getShopItemsUseCase;
    }

    public async Task<ErrorOr<ProductToRevisionDto>> Execute()
    {
        var userToken = _authTokenAccessor.AccessToken;

        var cart = await _vertemMarketplaceExternalService.GetCartItems(userToken);

        var sku = cart.Items.FirstOrDefault()?.Sku;

        if (string.IsNullOrWhiteSpace(sku))
            return Error.NotFound(description: "Não foi encontrado nenhum produto no carrinho");

        // TODO: buscar apenas o produto desejado
        var items = await _getShopItemsUseCase.Execute();

        if (items.IsError) return items.Errors;

        var product = _mapper.Map<ProductDto, ProductToRevisionDto>(items.Value
            .Select(x => x.Products)
            .SelectMany(x => x)
            .FirstOrDefault(x => x.Id == sku));

        if (product == null)
            return Error.NotFound(description: "O produto não foi encontrado");

        product.Address = _mapper.Map<CartShippingAddressDto, ParticipantAddressDto>(cart.ShippingAddress);

        var shippingResult = await AddShippingInfo(product, userToken);

        if (shippingResult.IsError)
            return shippingResult.Errors;

        return product;
    }

    private async Task<ErrorOr<Success>> AddShippingInfo(ProductToRevisionDto product, string userToken)
    {
        var shippingInfo = await _vertemMarketplaceExternalService.GetShippingCost(product.Address.PostalCode, product.Id, userToken);

        if (shippingInfo.IsError)
            return shippingInfo.Errors;

        product.Shipping = new ShippingDto
        {
            Cost = shippingInfo.Value.Total,
            DeliveryDate = shippingInfo.Value.DeliveryDate
        };

        return Result.Success;
    }
}
