﻿using ErrorOr;
using VibeBisBff.Dto.Shop;

namespace VibeBisBff.Application.Usecases.Shop.RevisionCartItem;

public interface IRevisionCartItemUseCase
{
    Task<ErrorOr<ProductToRevisionDto>> Execute();
}
