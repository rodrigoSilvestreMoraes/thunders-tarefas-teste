﻿using VibeBisBff.Dto.Quests.Webhook;

namespace VibeBisBff.Application.Usecases.Quests.AccomplishedQuest;

public interface IAccomplishedQuestUseCase
{
    Task Execute(AccomplishedQuestWebhookRequestDto request, CancellationToken cancellationToken = default);
}
