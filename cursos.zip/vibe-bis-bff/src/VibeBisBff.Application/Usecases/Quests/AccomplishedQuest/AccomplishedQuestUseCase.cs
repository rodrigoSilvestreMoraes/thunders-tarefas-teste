﻿using System.Globalization;
using AutoMapper;
using Common.Core.Exceptions;
using Microsoft.Extensions.Options;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Helpers.External;
using VibeBisBff.Application.Notification.Usecases;
using VibeBisBff.CrossCuting.Dto.Notification;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Extensions;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Entities.Benefit;
using VibeBisBff.Domain.Entities.Notifications;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.Dto.Quests.Webhook;
using VibeBisBff.ExternalServices.Insider;
using VibeBisBff.ExternalServices.Insider.Dto;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;
using AccomplishedEntitie = VibeBisBff.Domain.Entities.Quest;
using AttributesDto = VibeBisBff.ExternalServices.Insider.Dto.AttributesDto;

namespace VibeBisBff.Application.Usecases.Quests.AccomplishedQuest;

public class AccomplishedQuestUseCase : IAccomplishedQuestUseCase
{
    private readonly IAccomplishedQuestsRepository _accomplishedQuestsRepository;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly ITradebackPromoExternalService _tradebackPromoExternalService;
    private readonly IMapper _mapper;
    private readonly IInsiderExternalService _insiderExternalService;
    private readonly IVertemLogsLogger _logger;
    private readonly TenantConfigOptions _tenantConfigOptions;


    private readonly NotificationOptions _notificationOptions;
    private readonly IUserPushNotificationTokenRepository _userPushNotificationTokenRepository;
    private readonly INotificationUseCase _notificationUseCase;

    public AccomplishedQuestUseCase(IAccomplishedQuestsRepository accomplishedQuestsRepository,
        IDigitalAccountExternalService digitalAccountExternalService,
        ITradebackPromoExternalService tradebackPromoExternalService,
        IMapper mapper,
        IInsiderExternalService insiderExternalService,
        IVertemLogsLogger logger,
        IUserPushNotificationTokenRepository userPushNotificationTokenRepository,
        INotificationUseCase notificationUseCase,
        IOptionsSnapshot<TenantConfigOptions> tenantConfigOptions,
        IOptionsSnapshot<NotificationOptions> notificationOptions)
    {
        _accomplishedQuestsRepository = accomplishedQuestsRepository;
        _digitalAccountExternalService = digitalAccountExternalService;
        _tradebackPromoExternalService = tradebackPromoExternalService;
        _mapper = mapper;

        _insiderExternalService = insiderExternalService;
        _logger = logger;
        _tenantConfigOptions = tenantConfigOptions.Value;

        _notificationOptions = notificationOptions.Value;
        _userPushNotificationTokenRepository = userPushNotificationTokenRepository;
        _notificationUseCase = notificationUseCase;
    }

    public async Task Execute(AccomplishedQuestWebhookRequestDto request, CancellationToken cancellationToken = default)
    {
        if (request.Benefits.IsNullOrEmpty())
            return;

        var benefits = request.Benefits
            .Where(x => TradebackAuthorizerHelper.IsCreditBenefit(x.BenefitTypeId)).ToList();

        if (benefits.IsNullOrEmpty())
            return;

        var saleIds = benefits.Select(x => x.Sale.Id);

        var accomplishedQuests = benefits.Select(benefit =>
            new AccomplishedEntitie.AccomplishedQuest(request.ClientId, benefit.Sale.Id, benefit.Credit?.Value,
                request.TransactionId, benefit.Sale?.SaleName)).ToList();

        try
        {
            await _accomplishedQuestsRepository.InsertMany(accomplishedQuests);

            var digitalAccountForParticipant =
                await _digitalAccountExternalService.GetDigitalAccountByDocument(request.ClientId,
                    tenantConfigId: _tenantConfigOptions.TenantConfigIdVibe);

            if (digitalAccountForParticipant == null)
                return;

            try
            {
                var phoneNumber = digitalAccountForParticipant.GetCellphone();
                var email = digitalAccountForParticipant.GetEmail();

                if (string.IsNullOrWhiteSpace(phoneNumber))
                    phoneNumber =
                        request.Attributes.Find(x => x.Key.Equals("cellphone", StringComparison.OrdinalIgnoreCase))
                            ?.Values.FirstOrDefault() ?? string.Empty;

                if (string.IsNullOrWhiteSpace(email))
                    email = request.Attributes.Find(x => x.Key.Equals("email", StringComparison.OrdinalIgnoreCase))
                        ?.Values.FirstOrDefault() ?? string.Empty;

                var insiderErrorMessage = await SendInsiderEvent(accomplishedQuests, digitalAccountForParticipant,
                    phoneNumber, email);

                if (!string.IsNullOrWhiteSpace(insiderErrorMessage))
                    _logger.LogError(new ExceptionLog(
                        new BusinessException(
                            $"Erro ao enviar eventos do usuário para insider: {insiderErrorMessage}")));
            }
            catch (Exception e)
            {
                _logger.LogError(new ExceptionLog(e));
            }

            var advertisements = await _tradebackPromoExternalService.SearchAdvertisements
            (new AdvertisementSearchRequestDto
                (new PromoPaginationDto(99, 1),
                    new AdvertisementSearchFilterDto
                    {
                        SaleIds = saleIds,
                        ParticipantIdentifier = request.ClientId
                    }),
                appType: ApplicationType.Vibe, cancellationToken: cancellationToken);

            if (advertisements.IsError)
                throw new Exception(string.Join(", ", advertisements.Errors));

            foreach (var accomplishedQuest in accomplishedQuests)
            {
                accomplishedQuest.AddDigitalAccountId(digitalAccountForParticipant.Id);

                var advertisement = advertisements.Value.Data.FirstOrDefault(x => x.Id == accomplishedQuest.QuestId);
                accomplishedQuest.Advertisement = _mapper.Map<AdvertisementData>(advertisement);

                if (accomplishedQuest.Advertisement != null)
                    accomplishedQuest.HasSpending = advertisement?.ActivationCondition?.SecondLevelCondition
                        ?.SpendingBehavior?.SpendingBehaviorSettingsId != null;
            }

            await SendPushes(accomplishedQuests, cancellationToken);
        }
        catch (Exception ex)
        {
            foreach (var accomplishedQuest in accomplishedQuests)
            {
                accomplishedQuest.RegisterError(ex.Message);
            }

            throw;
        }
        finally
        {
            await Task.WhenAll(accomplishedQuests.Select(x =>
                _accomplishedQuestsRepository.Update(x)
            ));
        }
    }

    private async Task<string> SendInsiderEvent(
        IReadOnlyCollection<AccomplishedEntitie.AccomplishedQuest> accomplishedQuests,
        DigitalAccountParticipantDetail digitalAccountForParticipant, string phoneNumber, string email)
    {
        //TODO: Refatorar para utilizar uma factory ou useCases específicos para cada tipo de evento para que essa lógica de envio não fique especializada aqui nos próximos eventos
        List<UserDto> users = new();
        List<EventDto> events = new();
        accomplishedQuests.AsParallel().ForAll(x =>
        {
            var eventParams = new EventParamsDto();
            eventParams.AddCustom("id_da_missao", x.QuestId);

            eventParams.AddCustom("nome_da_missao", x.QuestName);

            if (x.VirtualCoinsEarned.HasValue)
                eventParams.AddCustom("valor_do_beneficio",
                    x.VirtualCoinsEarned.Value.ToString(CultureInfo.InvariantCulture));

            var eventDto = new EventDto("missao_cumprida", DateTimeOffset.UtcNow.DateTime.ToRfc3339());
            eventDto.AddEventParams(eventParams);
            events.Add(eventDto);
        });

        var identifiers = new IdentifiersDto
        {
            PhoneNumber = phoneNumber.StartsWith('+') ? phoneNumber : $"+{phoneNumber}",
            Email = email,
            Uuid = digitalAccountForParticipant.Id
        };

        identifiers.AddCustom("cpf", digitalAccountForParticipant.UserDocument);

        var attributes = new AttributesDto
        {
            Name = digitalAccountForParticipant.Name,
            EmailOptin = true,
            SmsOptin = true,
            WhatsappOptin = true
        };

        var user = new UserDto(identifiers, events);
        user.AddAttributes(attributes);
        users.Add(user);

        var response = await _insiderExternalService.SendEvent(new SendEventRequestDto { Users = users });

        return !response.success
            ? response.errorMessage
            : string.Empty;
    }

    private async Task SendPushes(IEnumerable<AccomplishedEntitie.AccomplishedQuest> accomplishedQuests,
        CancellationToken cancellationToken)
    {
        foreach (var quest in accomplishedQuests.ToList())
        {
            var token = await _userPushNotificationTokenRepository.GetTokenById(quest.DigitalAccountId,
                cancellationToken);

            if (string.IsNullOrEmpty(token))
                continue;

            var imageUrl =
                quest.Advertisement?.Images.Find(x => x.Tag == Constants.PROMO_NOTIFICATION_IMAGE_TAG)?.Tag ??
                quest.Advertisement?.Images?.FirstOrDefault()?.Url;

            var messageValues = new List<KeyValuePair<string, string>>
            {
                new("{message}", $"{quest.QuestName} - Parabéns, uma missão foi concluída"),
                new("link", $"vibe://quest-accomplished/{quest.QuestId}"),
            };

            var pushNotification = new NotificationPush(
                templateId: _notificationOptions.FreeMessagePushNotificationTemplateId,
                title: GetTitleForNotification(quest),
                token: token,
                messageValues: messageValues);

            var requestNotification = new NotificationRequestDto
            {
                CorrelationId = quest.Id,
                DigitalAccountId = quest.DigitalAccountId,
                Description = quest.QuestName,
                SourceEvent = NotificationSourceEvent.AccomplishedQuest,
                Title = GetTitleForNotification(quest),
                TenantConfigId = _tenantConfigOptions.TenantConfigIdVibe,
                ImageUrl = imageUrl,
            };

            await _notificationUseCase.SendNotification(requestNotification, pushNotification);
        }
    }

    private static string GetTitleForNotification(AccomplishedEntitie.AccomplishedQuest accomplishedQuest) =>
        $"Oba! Você cumpriu uma missão e ganhou {accomplishedQuest.VirtualCoinsEarned} vibes!";
}
