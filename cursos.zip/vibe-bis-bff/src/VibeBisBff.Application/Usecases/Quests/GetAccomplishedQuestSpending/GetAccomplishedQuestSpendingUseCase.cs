﻿using AutoMapper;
using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.Dto.Quests;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.SpendingBehaviorManagement;
using VibeBisBff.ExternalServices.Tradeback.SpendingBehaviorManagement.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Quests.GetAccomplishedQuestSpending;

public class GetAccomplishedQuestSpendingUseCase : IGetAccomplishedQuestSpendingUseCase
{
    private readonly ITradebackPromoExternalService _tradebackPromoExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IAccomplishedQuestsRepository _questsAccomplishedRepository;

    private readonly ITradebackSpendingBehaviorManagementExternalService
        _tradebackSpendingBehaviorManagementExternalService;

    private readonly IMapper _mapper;

    public GetAccomplishedQuestSpendingUseCase(ITradebackPromoExternalService tradebackPromoExternalService,
        IDigitalAccountExternalService digitalAccountExternalService,
        AuthenticatedUser authenticatedUser,
        ITradebackSpendingBehaviorManagementExternalService tradebackSpendingBehaviorManagementExternalService,
        IAccomplishedQuestsRepository questsAccomplishedRepository,
        IMapper mapper)
    {
        _tradebackPromoExternalService = tradebackPromoExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticatedUser;
        _tradebackSpendingBehaviorManagementExternalService = tradebackSpendingBehaviorManagementExternalService;
        _mapper = mapper;
        _questsAccomplishedRepository = questsAccomplishedRepository;
    }

    public async Task<ErrorOr<AccomplishedQuestSpendingResponseDto>> Execute(string questId)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var participantDetails = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        var advertisements = await _tradebackPromoExternalService.SearchAdvertisements
        (new AdvertisementSearchRequestDto
        (new PromoPaginationDto(99, 1),
            new AdvertisementSearchFilterDto
            {
                SaleIds = new List<string> { questId },
                ParticipantIdentifier = participantDetails.UserDocument
            }));


        if (advertisements.IsError) return advertisements.Errors;

        if (!advertisements.Value.Data.Any()) return Error.NotFound(description: "A missão não foi encontrada");

        var advertisement = advertisements.Value.Data.First();

        var settingsId = advertisement.ActivationCondition?.SecondLevelCondition?.SpendingBehavior
            ?.SpendingBehaviorSettingsId;

        if (string.IsNullOrWhiteSpace(settingsId))
            return Error.Validation("A missão informada não possui configurações de valor acumulado associadas");

        var accomplishedQuestSpending =
            await _tradebackSpendingBehaviorManagementExternalService.GetSpentDetail(settingsId,
                participantDetails.UserDocument);

        if (accomplishedQuestSpending.IsError) return accomplishedQuestSpending.Errors;

        var alreadySpentSomething = accomplishedQuestSpending.Value.Any();

        var spendingResult = alreadySpentSomething
            ? _mapper.Map<SpentDetailResponseDto, AccomplishedQuestSpendingResponseDto>
                (accomplishedQuestSpending.Value.Find(x => x.CounterGroupKey.Contains(questId)))
            : await GetDefaultSpendingResponse(settingsId);

        spendingResult.VirtualCoinsToBeEarned = advertisement.Benefit.Credit.Amount;

        await AppendTotalAccumulatedInVirtualCoinsToResult(spendingResult, alreadySpentSomething,
            digitalAccountId.Value, advertisement.Id);

        return spendingResult;
    }

    private async Task AppendTotalAccumulatedInVirtualCoinsToResult(AccomplishedQuestSpendingResponseDto result,
        bool alreadySpentSomething,
        string digitalAccountId, string questId)
    {
        if (!alreadySpentSomething)
            return;

        var virtualCoinsEarned =
            await _questsAccomplishedRepository.GetVirtualCoinsEarnedByDigitalAccountIdAndQuestId(digitalAccountId,
                questId);

        result.TotalAccumulatedInVirtualCoins = virtualCoinsEarned.Sum(x => x!.Value);
    }

    private async Task<AccomplishedQuestSpendingResponseDto> GetDefaultSpendingResponse(string spendingSettingsId)
    {
        var settings = await _tradebackSpendingBehaviorManagementExternalService.GetSettingsById(spendingSettingsId);

        if (settings.IsError)
            throw new BusinessException(
                "Ops! Houve um problema, mas estamos cuidando disso! Tente novamente mais tarde.");

        return new AccomplishedQuestSpendingResponseDto()
        {
            TotalSpending = 0,
            PrizeLimitReached = false,
            RemainingSpendToBeRewarded = settings.Value.SpentValueToBeRewarded,
            TotalValueToBeRewarded = 0,
            TotalAccumulatedInVirtualCoins = 0
        };
    }
}
