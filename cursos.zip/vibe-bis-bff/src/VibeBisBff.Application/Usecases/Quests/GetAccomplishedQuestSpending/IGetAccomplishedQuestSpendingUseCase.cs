﻿using ErrorOr;
using VibeBisBff.Dto.Quests;

namespace VibeBisBff.Application.Usecases.Quests.GetAccomplishedQuestSpending
{
    public interface IGetAccomplishedQuestSpendingUseCase
    {
        Task<ErrorOr<AccomplishedQuestSpendingResponseDto>> Execute(string questId);
    }
}
