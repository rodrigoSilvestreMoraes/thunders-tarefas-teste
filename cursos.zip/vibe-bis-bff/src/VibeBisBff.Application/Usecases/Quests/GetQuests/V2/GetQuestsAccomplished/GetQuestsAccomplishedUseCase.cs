﻿using ErrorOr;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.Dto.Quests;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.CrossCuting.Dto;
using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using FluentValidation;

namespace VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestsAccomplished;

public class GetQuestsAccomplishedUseCase : IGetQuestsAccomplishedUseCase
{
    private readonly IAccomplishedQuestsRepository _accomplishedQuestsRepository;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IValidator<PagingDataDto> _pagingValidator;

    public GetQuestsAccomplishedUseCase(
        IAccomplishedQuestsRepository accomplishedQuestsRepository,
        AuthenticationProvider authenticationProvider, IValidator<PagingDataDto> pagingValidator)
    {
        _accomplishedQuestsRepository = accomplishedQuestsRepository;
        _pagingValidator = pagingValidator;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
    }

    public async Task<ErrorOr<PagingDataResponseDto<QuestsV2Dto>>> Execute(PagingDataDto pagingData)
    {
        var pagingValidationResult = await _pagingValidator.ValidateAsync(pagingData);

        if (!pagingValidationResult.IsValid)
            return pagingValidationResult.Errors.ToValidation();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var accomplishedQuestsIdsAndQuestIds =
            await _accomplishedQuestsRepository.GetAllIdsAndQuestsIdsByDigitalAccountId(digitalAccountId.Value);

        if (!accomplishedQuestsIdsAndQuestIds.Any())
            return new PagingDataResponseDto<QuestsV2Dto>()
            {
                TotalItems = 0,
                Items = new List<QuestsV2Dto>()
            };

        var accomplishedQuestsIdsDistinguishedByQuestId =
            accomplishedQuestsIdsAndQuestIds.DistinctBy(x => x.QuestId).Select(x => x.Id).ToList();

        var accomplishedQuests =
            await _accomplishedQuestsRepository.GetByIdsWithPagination(accomplishedQuestsIdsDistinguishedByQuestId, pagingData);

        var quests = accomplishedQuests.Select(accomplishedQuest => new QuestsV2Dto
        {
            IsAccomplished = true,
            Description = accomplishedQuest.Advertisement.Description,
            Title = accomplishedQuest.Advertisement.Name,
            CampaignName = accomplishedQuest.Advertisement.Campaign != null
                ? accomplishedQuest.Advertisement.Campaign.Name
                : string.Empty,
            Id = accomplishedQuest.Advertisement.Id,
            Image = accomplishedQuest.Image,
            BannerImage = accomplishedQuest.BannerImage,
            DetailImage = accomplishedQuest.DetailImage,
            ListImage = accomplishedQuest.ListImage,
            Value = accomplishedQuest.Advertisement.Benefit.Credit.Amount,
            Redirect = accomplishedQuest.Redirect,
            IsRegular = accomplishedQuest.IsRegular,
            Type = accomplishedQuest.QuestType,
            HasSpending = accomplishedQuest.HasSpending
        }).ToList();

        return new PagingDataResponseDto<QuestsV2Dto>()
        {
            Items = quests,
            TotalItems = accomplishedQuestsIdsDistinguishedByQuestId.Count
        };
    }
}
