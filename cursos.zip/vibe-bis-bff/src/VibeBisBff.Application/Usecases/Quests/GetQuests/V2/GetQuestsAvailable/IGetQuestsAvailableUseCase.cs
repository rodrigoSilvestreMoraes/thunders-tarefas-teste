﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.Dto;
using VibeBisBff.Dto.Quests;

namespace VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestsAvailable;

public interface IGetQuestsAvailableUseCase
{
    Task<ErrorOr<PagingDataResponseDto<QuestsV2Dto>>> Execute(string name, PagingDataDto pagingData, GeolocationFilterRequestDto geolocationFilterRequestDto);
}
