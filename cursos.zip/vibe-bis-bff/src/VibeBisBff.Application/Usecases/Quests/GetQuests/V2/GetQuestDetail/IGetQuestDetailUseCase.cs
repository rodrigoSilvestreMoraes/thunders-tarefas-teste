﻿using ErrorOr;
using VibeBisBff.Dto.Quests.V2;

namespace VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestDetail;

public interface IGetQuestDetailUseCase
{
    Task<ErrorOr<QuestDetailV2Dto>> Execute(string questId, CancellationToken cancellationToken);
}
