﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using FluentValidation;

using MongoDB.Bson.IO;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.Dto.Offer;

using Mapster;
using Microsoft.Extensions.Options;
using VibeBisBff.Application.Helpers.External;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.Dto;

using VibeBisBff.Dto.Quests;
using VibeBisBff.Dto.Quests.V2;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.ExternalServices.Tradeback.Promo.Options;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestsAvailable;

public class GetQuestsAvailableUseCase : IGetQuestsAvailableUseCase
{
    private readonly ITradebackPromoExternalService _tradebackPromoExternalService;
    private readonly IAccomplishedQuestsRepository _accomplishedQuestsRepository;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IValidator<PagingDataDto> _pagingValidator;
    private readonly TradebackPromoOptions _tradebackPromoOptions;

    public GetQuestsAvailableUseCase(
        ITradebackPromoExternalService tradebackPromoExternalService,
        IAccomplishedQuestsRepository accomplishedQuestsRepository,
        AuthenticationProvider authenticationProvider,
        IDigitalAccountExternalService digitalAccountExternalService,
        IValidator<PagingDataDto> pagingValidator,
        IOptionsSnapshot<TradebackPromoOptions> tradebackPromoOptions)
    {
        _tradebackPromoExternalService = tradebackPromoExternalService;
        _accomplishedQuestsRepository = accomplishedQuestsRepository;
        _digitalAccountExternalService = digitalAccountExternalService;
        _pagingValidator = pagingValidator;
        _tradebackPromoOptions = tradebackPromoOptions.Value;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
    }

    public async Task<ErrorOr<PagingDataResponseDto<QuestsV2Dto>>> Execute(string name, PagingDataDto pagingData, GeolocationFilterRequestDto geolocationFilterRequestDto)
    {
        var validationResult = await _pagingValidator.ValidateAsync(pagingData);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        var advertisements = await GetAdvertisements(name, digitalAccount.UserDocument, digitalAccount.GetAddress().PostalCode, geolocationFilterRequestDto);

        if (advertisements.IsError)
            return advertisements.Errors;

        var quests = advertisements.Value.Data
            .Where(IsCreditBenefit)
            .Select(advertisement => new QuestsV2Dto
            {
                Description = advertisement.Description,
                Title = advertisement.Name,
                CampaignName = advertisement.Campaign?.Name ?? string.Empty,
                QuizId = advertisement.QuizId,
                Id = advertisement.Id,
                Image = advertisement.Image,
                BannerImage = advertisement.BannerImage,
                DetailImage = advertisement.DetailImage,
                ListImage = advertisement.ListImage,
                Redirect = advertisement.Redirect,
                IsRegular = advertisement.IsRegular,
                Type = advertisement.QuestType,
                Value = advertisement.Benefit!.Credit.Amount,
                HasSpending = advertisement.ActivationCondition?.SecondLevelCondition?.SpendingBehavior
                    ?.SpendingBehaviorSettingsId != null
            }).ToList();

        await RemoveNotRegularAccomplishedQuests(quests, digitalAccountId.Value);

        var totalOfItemsBeforeLimit = quests.Count;

        var skip = pagingData.PageSize * (pagingData.PageNumber - 1);

        quests = quests.Skip(skip!.Value).Take(pagingData.PageSize!.Value).ToList();

        return new PagingDataResponseDto<QuestsV2Dto>
        {
            Items = quests,
            TotalItems = totalOfItemsBeforeLimit
        };
    }

    private async Task RemoveNotRegularAccomplishedQuests(List<QuestsV2Dto> quests, string digitalAccountId)
    {
        var accomplishedQuests = await _accomplishedQuestsRepository.GetQuestIdsByDigitalAccountId(digitalAccountId);

        quests?.RemoveAll(q => !q.IsRegular && accomplishedQuests.Any(aq => aq.QuestId == q.Id));
    }

    private static bool IsCreditBenefit(AdvertisementDataDto advertisementDataDto) =>
        advertisementDataDto?.Benefit?.Credit != null;

    private async Task<ErrorOr<AdvertisementResponseDto>> GetAdvertisements(string name, string userDocument, string zipCode, GeolocationFilterRequestDto geolocationFilterRequestDto)
    {
        var filter = new AdvertisementSearchRequestDto
        (new PromoPaginationDto(100, 1),
            new AdvertisementSearchFilterDto
            {
                Name = name,
                ParticipantIdentifier = userDocument,
                Chain = new AdvertisementChainFilterDto
                {
                    Categories = new List<string> { Constants.QUEST_CATEGORY_NAME }
                }
            });

        //TODO: Descomentar quando o pessoal configurar CORRETAMENTE a geolocalização das lojas das missões e ser OPCIONAL
        // TradebackPromoHelper.BuildPlaceFilter(filter.Filter, geolocationFilterRequestDto,
        //     zipCode, _tradebackPromoOptions.DefaultMaxDistance);

        return await _tradebackPromoExternalService.SearchAdvertisements(filter);
    }
}
