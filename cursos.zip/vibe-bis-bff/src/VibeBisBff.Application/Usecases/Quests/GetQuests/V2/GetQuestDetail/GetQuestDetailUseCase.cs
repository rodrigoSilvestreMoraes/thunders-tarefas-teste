﻿using Common.Core.Authentication.Models;
using ErrorOr;
using System.Text.Json;
using VibeBisBff.Application.Mappers.Quest;
using VibeBisBff.Application.Usecases.Offers.GenerateRules;
using VibeBisBff.Application.Usecases.Offers.GetOfferDetail;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.Dto.Quests.V2;
using VibeBisBff.ExternalServices.Tradeback.Promo.Adm;
using VibeBisBff.ExternalServices.Tradeback.Promo.Adm.Dto;
using VibeBisBff.Infra.Cache;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestDetail;

public class GetQuestDetailUseCase : IGetQuestDetailUseCase
{
    private readonly IGetOfferDetailUseCase _getOfferDetailUseCase;
    private readonly ITradebackPromoAdmExternalService _tradebackPromoAdmExternalService;

    private readonly IAccomplishedQuestsRepository _accomplishedQuestsRepository;
    private readonly IGenerateRulesUseCase _generateRulesUseCase;

    private readonly IRedisService _redisService;
    private readonly AuthenticatedUser _authenticatedUser;

    private static long HOURS_IN_SECONDS = 3600;

    public GetQuestDetailUseCase(
        IGetOfferDetailUseCase getOfferDetailUseCase,
        IGenerateRulesUseCase generateRulesUseCase,
        IAccomplishedQuestsRepository accomplishedQuestsRepository,
        IRedisService redisService,
        AuthenticatedUser authenticatedUser,
        ITradebackPromoAdmExternalService tradebackPromoAdmExternalService)
    {
        _getOfferDetailUseCase = getOfferDetailUseCase;
        _accomplishedQuestsRepository = accomplishedQuestsRepository;
        _generateRulesUseCase = generateRulesUseCase;

        _redisService = redisService;
        _authenticatedUser = authenticatedUser;
        _tradebackPromoAdmExternalService = tradebackPromoAdmExternalService;
    }

    public async Task<ErrorOr<QuestDetailV2Dto>> Execute(string questId, CancellationToken cancellationToken)
    {
        var CACHE_KEY = $"v2-get-quest-detail-{questId}";
        var dataRedis = await _redisService.Get(CACHE_KEY);

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        if (dataRedis != null)
            return JsonSerializer.Deserialize<QuestDetailV2Dto>(dataRedis);

        var quest = await _getOfferDetailUseCase.Execute(questId, cancellationToken);

        if (quest.IsError)
            return quest.Errors;

        var isAccomplished = await _accomplishedQuestsRepository.IsAccomplished(questId, digitalAccountId.Value, cancellationToken);

        var (rules, descripionV1) = await _generateRulesUseCase.Execute(quest.Value.Description, cancellationToken);
        var products = await _tradebackPromoAdmExternalService.SearchProcutsForSaleId(questId, cancellationToken);

        var response = QuestV2Profile.MapQuest(quest.Value, isAccomplished, rules, descripionV1, products.IsError ? new  List<EligiblesProcutResponseDto>() : products.Value.Data);
        await _redisService.Set(CACHE_KEY, response, HOURS_IN_SECONDS * 3);

        return response;
    }
}
