﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.Dto.Quests;

namespace VibeBisBff.Application.Usecases.Quests.GetQuests.V2.GetQuestsAccomplished;

public interface IGetQuestsAccomplishedUseCase
{
    Task<ErrorOr<PagingDataResponseDto<QuestsV2Dto>>> Execute(PagingDataDto pagingData);
}
