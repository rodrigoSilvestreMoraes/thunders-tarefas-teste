﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Domain.Entities.Quest;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.Dto.Quests;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.UseCases.Quests.GetQuests.V1;

public class GetQuestsUsecase : IGetQuestsUsecase
{
    private readonly ITradebackPromoExternalService _tradebackPromoExternalService;
    private readonly IAccomplishedQuestsRepository _accomplishedQuestsRepository;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public GetQuestsUsecase(ITradebackPromoExternalService tradebackPromoExternalService,
        IAccomplishedQuestsRepository accomplishedQuestsRepository,
        AuthenticationProvider authenticationProvider,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _tradebackPromoExternalService = tradebackPromoExternalService;
        _accomplishedQuestsRepository = accomplishedQuestsRepository;
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
    }

    public async Task<ErrorOr<List<QuestsDto>>> Execute(QuestsStatus questsStatus)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var accomplishedQuests = await _accomplishedQuestsRepository.GetByDigitalAccountId(digitalAccountId.Value);

        var advertisements =
            await GetAdvertisementsFromQuestStatus(accomplishedQuests, questsStatus, digitalAccountId.Value);

        if (advertisements.IsError) return advertisements.Errors;

        var quests = advertisements.Value.Data
            .Where(a => a.Benefit?.Credit != null)
            .Select(advertisement => new QuestsDto
            {
                Description = advertisement.Description,
                Title = advertisement.Name,
                Id = advertisement.Id,
                CampaignName = advertisement.Campaign?.Name,
                Image = advertisement.Image,
                BannerImage = advertisement.BannerImage,
                DetailImage = advertisement.DetailImage,
                ListImage = advertisement.ListImage,
                Redirect = advertisement.Redirect,
                IsRegular = advertisement.IsRegular,
                Type = advertisement.QuestType,
                Value = advertisement.Benefit.Credit.Amount,
                HasSpending = advertisement.ActivationCondition?.SecondLevelCondition?.SpendingBehavior
                    ?.SpendingBehaviorSettingsId != null
            }).ToList();

        RemoveNotRegularAccomplishedQuestsWhenQuestStatusIsAvailable(questsStatus,
            quests,
            accomplishedQuests
        );

        return quests;
    }

    private static void RemoveNotRegularAccomplishedQuestsWhenQuestStatusIsAvailable(QuestsStatus questsStatus,
        List<QuestsDto> quests,
        List<AccomplishedQuest> accomplishedQuests)
    {
        if (questsStatus != QuestsStatus.Available)
            return;

        quests?.RemoveAll(q => !q.IsRegular && accomplishedQuests.Any(aq => aq.QuestId == q.Id));
    }

    private async Task<ErrorOr<AdvertisementResponseDto>> GetAdvertisementsFromQuestStatus(
        List<AccomplishedQuest> accomplishedQuests,
        QuestsStatus questsStatus, string digitalAccountId)
    {
        var saleIds = new List<string>();

        if (questsStatus == QuestsStatus.Accomplished)
        {
            if (!accomplishedQuests.Any())
                return new AdvertisementResponseDto();

            saleIds = accomplishedQuests.Select(aq => aq.QuestId)?.ToList();
        }

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId);

        return await _tradebackPromoExternalService.SearchAdvertisements
        (new AdvertisementSearchRequestDto
        (new PromoPaginationDto(99, 1), new AdvertisementSearchFilterDto()
        {
            SaleIds = saleIds,
            Chain = new AdvertisementChainFilterDto()
            {
                Categories = new List<string> { Constants.QUEST_CATEGORY_NAME }
            },
            ParticipantIdentifier = digitalAccount.UserDocument
        }));
    }
}
