﻿using ErrorOr;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Quests;

namespace VibeBisBff.Application.UseCases.Quests.GetQuests.V1;

public interface IGetQuestsUsecase
{
    Task<ErrorOr<List<QuestsDto>>> Execute(QuestsStatus questsStatus);
}
