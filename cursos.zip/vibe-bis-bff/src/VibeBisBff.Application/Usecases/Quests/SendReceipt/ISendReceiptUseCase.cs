﻿using ErrorOr;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer.Dto;

namespace VibeBisBff.Application.Usecases.Quests.SendReceipt;

public interface ISendReceiptUseCase
{
    Task<ErrorOr<string>> Execute(SendReceiptRequestDto sendReceiptRequestDto);
}
