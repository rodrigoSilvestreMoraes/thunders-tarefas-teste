﻿using VibeBisBff.Dto.Quests;
using ErrorOr;

namespace VibeBisBff.Application.Usecases.Quests.GetQuestById;

public interface IGetQuestByIdUseCase
{
    Task<ErrorOr<QuestsV2Dto>> Execute(string questId, CancellationToken cancellationToken);
}
