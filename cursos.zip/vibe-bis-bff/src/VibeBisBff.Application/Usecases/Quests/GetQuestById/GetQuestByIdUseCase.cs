﻿using Common.Core.Authentication.Models;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.Dto.Quests;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using ErrorOr;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Quests.GetQuestById;

public class GetQuestByIdUseCase : IGetQuestByIdUseCase
{
    private readonly IAccomplishedQuestsRepository _accomplishedQuestsRepository;
    private readonly ITradebackPromoExternalService _tradebackPromoExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public GetQuestByIdUseCase(IAccomplishedQuestsRepository accomplishedQuestsRepository,
        ITradebackPromoExternalService tradebackPromoExternalService,
        AuthenticatedUser authenticatedUser)
    {
        _accomplishedQuestsRepository = accomplishedQuestsRepository;
        _tradebackPromoExternalService = tradebackPromoExternalService;
        _authenticatedUser = authenticatedUser;
    }

    public async Task<ErrorOr<QuestsV2Dto>> Execute(string questId, CancellationToken cancellationToken)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var questFromTradebackPromo = await _tradebackPromoExternalService.SearchAdvertisements(
            new AdvertisementSearchRequestDto(new PromoPaginationDto(1, 1), new AdvertisementSearchFilterDto()
            {
                SaleIds = new[] { questId }
            }), cancellationToken);

        if (questFromTradebackPromo.IsError)
            return questFromTradebackPromo.Errors;

        if (questFromTradebackPromo.Value.NumberOfRows == 0)
            return Error.Validation("NO-QUEST", "A missão informada não foi encontrada");

        var quest = questFromTradebackPromo.Value.Data[0];

        var isAccomplished = await _accomplishedQuestsRepository.IsAccomplished(questId, digitalAccountId.Value, cancellationToken);

        return new QuestsV2Dto
        {
            Description = quest.Description,
            Title = quest.Name,
            CampaignName = quest.Campaign?.Name ?? string.Empty,
            QuizId = quest.QuizId,
            Id = quest.Id,
            Image = quest.Image,
            BannerImage = quest.BannerImage,
            DetailImage = quest.DetailImage,
            ListImage = quest.ListImage,
            Redirect = quest.Redirect,
            IsRegular = quest.IsRegular,
            Type = quest.QuestType,
            Value = quest.Benefit!.Credit.Amount,
            HasSpending = quest.ActivationCondition?.SecondLevelCondition?.SpendingBehavior
                ?.SpendingBehaviorSettingsId != null,
            IsAccomplished = isAccomplished
        };
    }
}
