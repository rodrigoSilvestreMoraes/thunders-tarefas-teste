﻿using ErrorOr;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer.Dto;

namespace VibeBisBff.Application.Usecases.Quests.GetReceipts
{
    public interface IGetReceiptsUsecase
    {
        Task<ErrorOr<ReceiptResponseDto>> Execute(int offset, int limit, DateTime? start = null, DateTime? end = null);
    }
}
