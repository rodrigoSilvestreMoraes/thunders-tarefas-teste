﻿using System.Globalization;
using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.CrossCutting.Enums.External.TradebackReceiptAuthorizer;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer;
using VibeBisBff.ExternalServices.Tradeback.ReceiptAuthorizer.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Quests.GetReceipts;

public class GetReceiptsUsecase : IGetReceiptsUsecase
{
    private readonly IReceiptAuthorizerExternalService _receiptAuthorizerExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IMapper _mapper;

    public GetReceiptsUsecase(IReceiptAuthorizerExternalService receiptAuthorizerExternalService,
        AuthenticatedUser authenticatedUser,
        IMapper mapper, IDigitalAccountExternalService digitalAccountExternalService)
    {
        _receiptAuthorizerExternalService = receiptAuthorizerExternalService;
        _authenticatedUser = authenticatedUser;
        _mapper = mapper;
        _digitalAccountExternalService = digitalAccountExternalService;
    }

    public async Task<ErrorOr<ReceiptResponseDto>> Execute(int offset, int limit, DateTime? start = null,
        DateTime? end = null)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var userOnDigitalAccount =
            await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        var receiptResponseExternalService =
            await _receiptAuthorizerExternalService.SearchReceipt(1, 100, userOnDigitalAccount!.UserDocument, start,
                end);

        if (receiptResponseExternalService.IsError) return receiptResponseExternalService.Errors;

        var dtoWithMessage = SetReturnMessageForEachReceipt(receiptResponseExternalService.Value);

        return _mapper.Map<ReceiptResponseExternalServiceDto, ReceiptResponseDto>(dtoWithMessage);
    }

    private static ReceiptResponseExternalServiceDto SetReturnMessageForEachReceipt(ReceiptResponseExternalServiceDto model)
    {
        foreach (var invoice in model.Data)
        {
            switch (invoice.Reading.Status)
            {
                case ReceiptReadingStatus.Failed:
                    invoice.Message = "Erro ocorrido ao ler cumpom.";
                    continue;
                case ReceiptReadingStatus.Pending or ReceiptReadingStatus.Processing:
                    SetInvoiceMessageWhenIsReading(invoice);
                    continue;
                default:
                    switch (invoice.Authorization.Status)
                    {
                        case ReceiptAuthorizationStatus.FailedSend:
                            SetInvoiceFailureWhenAuthorizationFailedSend(invoice);
                            continue;
                        case ReceiptAuthorizationStatus.Failed:
                            SetInvoiceFailureWhenAuthorizationFailed(invoice);
                            continue;
                        case ReceiptAuthorizationStatus.AwaitingReading or ReceiptAuthorizationStatus.Processing:
                            SetInvoiceMessageWhenIsReading(invoice);
                            invoice.Reading.Status = ReceiptReadingStatus.Pending;
                            continue;
                        default:
                            SetInvoiceMessageWhenSuccess(invoice);
                            break;
                    }

                    break;
            }
        }

        return model;
    }
    private static void SetInvoiceMessageWhenIsReading(ReceiptExternalServiceDto invoice) => invoice.Message = "Nota fiscal aguardando o processamento.\nA validação pode demorar até 3 dias.";
    private static void SetInvoiceFailureWhenAuthorizationFailedSend(ReceiptExternalServiceDto invoice)
    {
        invoice.Message = "Não foi possível identificar o produto na nota fiscal enviada.";
        invoice.Reading.Status = ReceiptReadingStatus.Failed;
    }
    private static void SetInvoiceFailureWhenAuthorizationFailed(ReceiptExternalServiceDto invoice)
    {
        if (invoice.Authorization.FailureReason?.Equals("Produto nao elegivel.",
                StringComparison.OrdinalIgnoreCase) ?? false)
        {
            invoice.Message = "Não foi possível identificar o produto na nota fiscal enviada.";
            invoice.Reading.Status = ReceiptReadingStatus.Failed;
            return;
        }

        invoice.Message = "Nota fiscal aprovada. Continue acumulando para ganhar mais Vibes.";
    }
    private static void SetInvoiceMessageWhenSuccess(ReceiptExternalServiceDto invoice)
    {
        var sumOfCreditBenefit =
            invoice.Authorization?.Result?.Benefits?.Sum(x => x.Credit?.Value ?? 0) ?? 0;
        if (sumOfCreditBenefit > 0)
        {
            invoice.TotalCreditReceived = sumOfCreditBenefit;
            invoice.Message =
                $"Nota fiscal aprovada. Você ganhou {GetFormattedDecimal(invoice.TotalCreditReceived)} Vibes por esta compra.";
            return;
        }

        invoice.Message = "Nota fiscal aprovada. Continue acumulando para ganhar mais Vibes.";
    }
    private static string GetFormattedDecimal(decimal number)
    {
        var numberAsString = number.ToString("0.##", CultureInfo.GetCultureInfo("pt-BR"));

        if (!numberAsString.Contains(',')) return numberAsString;

        var parts = numberAsString.Split(",");

        if (parts[1].Length == 1)
            numberAsString = $"{parts[0]},{parts[1]}0";

        return numberAsString;
    }
}
