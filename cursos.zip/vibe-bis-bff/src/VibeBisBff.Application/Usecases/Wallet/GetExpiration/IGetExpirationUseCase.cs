﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.Dto.Wallet;

namespace VibeBisBff.Application.Usecases.Wallet.GetExpiration;

public interface IGetExpirationUseCase
{
    Task<ErrorOr<PagingDataResponseDto<ExtractExpirationPointsResponseDto>>> Execute(ExtractExpirationPointsRequestDto request, PagingDataDto pagingDataDto);
}
