﻿using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using FluentValidation;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.Dto.Wallet;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Vertem.WalletVertem;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Wallet.GetExpiration;

public class GetExpirationUseCase : IGetExpirationUseCase
{
    private readonly IWalletVertemExternalService _walletVertemExternalService;
    private readonly ITenantService _tenantService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IMapper _mapper;
    private readonly IValidator<PagingDataDto> _validatorPaging;
    private readonly IValidator<ExtractExpirationPointsRequestDto> _validatorRequest;

    public GetExpirationUseCase(IWalletVertemExternalService walletVertemExternalService,
       AuthenticatedUser authenticatedUser,
       IMapper mapper,
       IValidator<PagingDataDto> validatorPaging,
       IValidator<ExtractExpirationPointsRequestDto> validatorRequest,
       ITenantService tenantService)
    {
        _walletVertemExternalService = walletVertemExternalService;
        _authenticatedUser = authenticatedUser;
        _mapper = mapper;
        _validatorPaging = validatorPaging;
        _validatorRequest = validatorRequest;
        _tenantService = tenantService;
    }

    public async Task<ErrorOr<PagingDataResponseDto<ExtractExpirationPointsResponseDto>>> Execute(ExtractExpirationPointsRequestDto request, PagingDataDto pagingDataDto)
    {
        var validationPagingResult = await _validatorPaging.ValidateAsync(pagingDataDto);
        if (!validationPagingResult.IsValid)
            return validationPagingResult.Errors.ToValidation();

        var validationRequestResult = await _validatorRequest.ValidateAsync(request);
        if (!validationRequestResult.IsValid)
            return validationRequestResult.Errors.ToValidation();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();
        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var walletConfiguration = await _tenantService.GetWalletConfiguration();

        var participantExtractResult = await _walletVertemExternalService.GetCreditExpire(
            digitalAccountId.Value,
            walletConfiguration.VirtualCoinsAccountingLedgerId,
            request.BeginDate);

        if (participantExtractResult.IsError)
            return participantExtractResult.Errors;

        if (participantExtractResult.Value is null || !participantExtractResult.Value.Any())
            return new PagingDataResponseDto<ExtractExpirationPointsResponseDto>()
            {
                TotalItems = 0,
                Items = new List<ExtractExpirationPointsResponseDto>()
            };

        var extractItems = _mapper.Map<List<CreditExpireDetailResponseDto>,
            List<ExtractExpirationPointsResponseDto>>(participantExtractResult.Value);

        var response = new PagingDataResponseDto<ExtractExpirationPointsResponseDto>()
        {
            TotalItems = extractItems.Count
        };

        var skip = pagingDataDto.PageSize * (pagingDataDto.PageNumber - 1);
        extractItems = extractItems.Skip(skip!.Value).Take(pagingDataDto.PageSize!.Value).ToList();
        response.Items = extractItems;

        return response;
    }
}
