﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Quiz;

namespace VibeBisBff.Application.Usecases.Quiz.GetQuizSurvey;
public interface IGetQuizSurveyUseCase
{
    Task<ErrorOr<QuizDetailView>> Execute(string id, CancellationToken cancellationToken);    
}
