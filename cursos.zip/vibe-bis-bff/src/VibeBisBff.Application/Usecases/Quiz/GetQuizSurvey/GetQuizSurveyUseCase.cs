﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Quiz;
using VibeBisBff.CrossCuting.Dto.Quiz.Register;
using VibeBisBff.ExternalServices.Tradeback.QuizTransaction;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Quiz.GetQuizSurvey;

public class GetQuizSurveyUseCase : IGetQuizSurveyUseCase
{
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly AuthTokenAccessor _tokenAccessor;
    private readonly IQuizTransactionExternalService _quizTransactionExternalService;

    public GetQuizSurveyUseCase(
        AuthenticationProvider authenticationProvider,
        AuthTokenAccessor tokenAccessor,
        IQuizTransactionExternalService quizTransactionExternalService)
    {
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
        _tokenAccessor = tokenAccessor;
        _quizTransactionExternalService = quizTransactionExternalService;
    }

    public async Task<ErrorOr<QuizDetailView>> Execute(string id, CancellationToken cancellationToken)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var result = await  _quizTransactionExternalService.GetQuiz(id, digitalAccountId.Value, _tokenAccessor.AccessToken, cancellationToken);

        if(result.IsError)
            return result.Errors;

        if(result.Value == null)
            result = await _quizTransactionExternalService.GetSurvey(id, digitalAccountId.Value, _tokenAccessor.AccessToken, cancellationToken);

        if (result.IsError)
            return result.Errors;

        var quizDto = result.Value;

        if (quizDto == null)
            return new ErrorOr<QuizDetailView>();

        return new QuizDetailView
        {
            Name = quizDto.Name,
            Description = quizDto.Description,
            Type = (string.IsNullOrEmpty(quizDto.ExternalQuizId) ? RegisterAnswerType.Survey : RegisterAnswerType.Quiz),
            Questions = quizDto.Questions.Select(x => new QuizDetailQuestionsView
            {
                Id = x.Id,
                Description = x.Description,
                Index = x.Index,
                MaxAlternativesAnswer = x.MaxAlternativesAnswer,
                Type = x.Type,
                Alternatives = x.Alternatives.Select(y => new QuizDetailAlternativesAnswerView
                {
                    Id = y.Id,
                    Description = y.Description,
                    Index = y.Index
                }).ToList()
            }).ToList()
        };
    }
}
