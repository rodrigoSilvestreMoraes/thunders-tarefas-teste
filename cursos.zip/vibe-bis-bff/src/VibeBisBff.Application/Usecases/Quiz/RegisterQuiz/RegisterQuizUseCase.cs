﻿using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using FluentValidation;
using VibeBisBff.Application.Mappers.QuizSurvey;
using VibeBisBff.CrossCuting.Dto.Quiz.Register;
using VibeBisBff.Domain.Entities.Benefit;
using VibeBisBff.Domain.Entities.Quest;
using VibeBisBff.Domain.Repositories.MongoDb.Quest;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.ExternalServices.Tradeback.QuizTransaction;
using VibeBisBff.ExternalServices.Tradeback.QuizTransaction.Dto.Register;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Quiz.RegisterQuiz;

public class RegisterQuizUseCase : IRegisterQuizUseCase
{
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly AuthTokenAccessor _tokenAccessor;
    private readonly ITradebackPromoExternalService _tradebackPromoExternalService;
    private readonly IQuizTransactionExternalService _quizTransactionExternalService;
    private readonly IAccomplishedQuestsRepository _accomplishedQuestsRepository;
    private readonly IMapper _mapper;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;

    private readonly IValidator<QuizRegisterAnswerRequest> _validation;

    public RegisterQuizUseCase(AuthenticatedUser authenticatedUser,
        AuthTokenAccessor tokenAccessor,
        IQuizTransactionExternalService quizTransactionExternalService,
        ITradebackPromoExternalService tradebackPromoExternalService,
        IValidator<QuizRegisterAnswerRequest> validation,
        IMapper mapper, IAccomplishedQuestsRepository accomplishedQuestsRepository,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _authenticatedUser = authenticatedUser;
        _tokenAccessor = tokenAccessor;
        _tradebackPromoExternalService = tradebackPromoExternalService;
        _quizTransactionExternalService = quizTransactionExternalService;
        _validation = validation;
        _mapper = mapper;
        _accomplishedQuestsRepository = accomplishedQuestsRepository;
        _digitalAccountExternalService = digitalAccountExternalService;
    }

    public async Task<ErrorOr<QuizRegisterAnswerResponse>> Execute(QuizRegisterAnswerRequest request,
        CancellationToken cancellationToken)
    {
        var validationResult = await _validation.ValidateAsync(request, cancellationToken);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var userOnDigitalAccount =
            await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        var tenantConfig = _authenticatedUser.GetTenantConfig();

        if (tenantConfig.IsError)
            return tenantConfig.Errors;

        var correspondentAdvertisement = await GetAdvertisementByQuestId(request.QuestId);

        if (correspondentAdvertisement.IsError)
            return correspondentAdvertisement.Errors;

        ErrorOr<QuizRegisterAnswerResponseDto> result = Error.Failure(description: "Erro ao registrar a resposta ao Quiz. Tente novamente, por favor.");

        if (request.Answers.Any())
        {
            result = await _quizTransactionExternalService.RegisterQuiz(
                request.MapQuiz(digitalAccountId.Value),
                _tokenAccessor.AccessToken,
                cancellationToken);
        }

        if (request.Survey.Any())
        {
            result = await _quizTransactionExternalService.RegisterSurvey(
                request.MapSurvey(digitalAccountId.Value),
                _tokenAccessor.AccessToken,
                cancellationToken);
        }

        if (result.IsError)
            return result.Errors;

        var receivedAmount = result.Value.ParticipantGotPrize
            ? correspondentAdvertisement.Value.Benefit?.Credit.Amount ?? 0
            : 0;

        await SaveAccomplishedQuest(userOnDigitalAccount!.UserDocument, correspondentAdvertisement.Value, receivedAmount,
            digitalAccountId.Value, tenantConfig.Value, request.Id, cancellationToken);

        return new QuizRegisterAnswerResponse
        {
            FundsReceive = receivedAmount,
            Winner = result.Value.ParticipantGotPrize
        };
    }

    private async Task SaveAccomplishedQuest(string username, AdvertisementDataDto advertisement, decimal receivedAmount,
        string digitalAccountId, string tenantConfigId, string quizId, CancellationToken cancellationToken)
    {
        var accomplishedQuest = new AccomplishedQuest(username,
            advertisement.Id, receivedAmount, null, advertisement.Name,
            _mapper.Map<AdvertisementData>(advertisement));

        accomplishedQuest.AddDigitalAccountId(digitalAccountId);

        accomplishedQuest.AddTenantConfig(tenantConfigId);

        accomplishedQuest.AddQuizId(quizId);

        await _accomplishedQuestsRepository.Insert(accomplishedQuest, cancellationToken);
    }

    private async Task<ErrorOr<AdvertisementDataDto>> GetAdvertisementByQuestId(string questId)
    {
        var advertisementResponse = await _tradebackPromoExternalService
            .SearchAdvertisements(new AdvertisementSearchRequestDto(new PromoPaginationDto(1, 1),
                new AdvertisementSearchFilterDto
                {
                    SaleIds = new[] { questId }
                }));

        if (advertisementResponse.IsError)
            return advertisementResponse.Errors;

        if (!advertisementResponse.Value.Data.Any()) return Error.NotFound(description: "A missão não foi encontrada");

        var correspondentAdvertisement = advertisementResponse.Value.Data.First();

        if (correspondentAdvertisement.Benefit?.Credit?.Amount is null or 0)
            return Error.Validation("A missão especificada é inválida");

        return correspondentAdvertisement;
    }
}
