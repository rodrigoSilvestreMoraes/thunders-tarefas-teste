﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Quiz.Register;

namespace VibeBisBff.Application.Usecases.Quiz.RegisterQuiz;

public interface IRegisterQuizUseCase
{
    Task<ErrorOr<QuizRegisterAnswerResponse>> Execute(QuizRegisterAnswerRequest request, CancellationToken cancellationToken);
}
