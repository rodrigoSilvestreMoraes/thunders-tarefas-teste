﻿using AutoMapper;
using VibeBisBff.CrossCuting.Dto.Tag;
using VibeBisBff.Domain.Entities.Tag;
using VibeBisBff.Domain.Repositories.MongoDb.Tag;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;

namespace VibeBisBff.Application.Usecases.Tags.GetTag;

public class GetTagUseCase : IGetTagUseCase
{
    private readonly IMapper _mapper;
    private Dictionary<string, TagConfig> _tagsHashMap;
    private readonly ITagRepository _tagRepository;

    public GetTagUseCase(IMapper mapper, ITagRepository tagRepository)
    {
        _mapper = mapper;
        _tagRepository = tagRepository;
    }

    //TODO: VALIDAR SE É RESPONSABILIDADE DA TAG CALCULAR SE O BENEFÍCIO ESTÁ ESGOTADO OU NÃO. VALIDAR CRIAÇÃO DE OBJETO ESPECIALIZADO PARA ISSO
    public async Task<(TagConfigResponseDto tag, bool isSoldOff)> Execute(
        string tagId,
        string tagIdSoldOff,
        string tagIdExpiration,
        DateTime? expirationDate,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(tagId) &&
            !expirationDate.HasValue)
            return (null, false);

        await TryToLoadTagsDictionary(cancellationToken);

        if (!string.IsNullOrEmpty(tagId))
        {
            return !_tagsHashMap.TryGetValue(tagId, out var tag)
                ? (null, false)
                : (_mapper.Map<TagConfig, TagConfigResponseDto>(tag), false);
        }

        if ((expirationDate!.Value.ToUniversalTime() - DateTime.UtcNow).TotalSeconds <= 0)
        {
            return !_tagsHashMap.TryGetValue(tagIdSoldOff, out var soldOffTag)
                ? (null, false)
                : (_mapper.Map<TagConfig, TagConfigResponseDto>(soldOffTag), true);
        }

        if (!_tagsHashMap.TryGetValue(tagIdExpiration, out var expirationTag))
            return (null, false);

        var tagResponse =
            _mapper.Map<TagConfig, TagConfigResponseDto>(expirationTag);

        tagResponse.ExpirationTime = expirationDate;

        return (tagResponse, false);
    }

    private async Task TryToLoadTagsDictionary(CancellationToken cancellationToken)
    {
        if (_tagsHashMap != null)
            return;

        _tagsHashMap = (await _tagRepository.LoadTags(cancellationToken)).ToDictionary(x => x.Id);
    }
}
