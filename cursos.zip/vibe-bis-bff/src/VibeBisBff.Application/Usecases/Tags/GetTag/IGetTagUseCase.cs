﻿using VibeBisBff.CrossCuting.Dto.Tag;
namespace VibeBisBff.Application.Usecases.Tags.GetTag;

public interface IGetTagUseCase
{
    Task<(TagConfigResponseDto tag, bool isSoldOff)> Execute(
        string tagId,
        string tagIdSoldOff,
        string tagIdExpiration,
        DateTime? expirationDate,
        CancellationToken cancellationToken);
}
