﻿using System.Text.RegularExpressions;
using VibeBisBff.Domain.Repositories.MongoDb.Images;
using VibeBisBff.Dto.Offer;

namespace VibeBisBff.Application.Usecases.Offers.GenerateRules;

public class GenerateRulesUseCase : IGenerateRulesUseCase
{
    private readonly IImageAppRepository _imageAppRepository;

    public GenerateRulesUseCase(IImageAppRepository imageAppRepository)
    {
        _imageAppRepository = imageAppRepository;
    }

    public async Task<(List<RulesOfferDto>, string)> Execute(string description, CancellationToken cancellationToken)
    {
        Regex yourRegex = new Regex(@"img\{{([^\}]+)\}}");
        string resultForV1 = yourRegex.Replace(description, string.Empty);

        List<RulesOfferDto> rulesOfferDtos = new List<RulesOfferDto>();
        StringReader strReader = new StringReader(description);
        string line;
        while (true)
        {
            line = strReader.ReadLine();
            if (line != null)
            {
                var rule = await GetRule(line, cancellationToken);
                if(rule != null) 
                    rulesOfferDtos.Add(rule);
            }
            else
                break;
        }
        return (rulesOfferDtos, resultForV1);
    }

    async Task<RulesOfferDto> GetRule(string line, CancellationToken cancellationToken)
    {
        RulesOfferDto rule = null;
        if (line.IndexOf('-') != -1 && line.IndexOf("img{{") != -1)
        {
            rule = new RulesOfferDto();
            var keyImage = line.Substring(line.IndexOf("img{{"), line.LastIndexOf("}}"));
            keyImage = keyImage.Substring(keyImage.IndexOf("{{") + 2, (keyImage.LastIndexOf("}}") - keyImage.IndexOf("{{") - 2));
            var image = await _imageAppRepository.GetImage(keyImage, cancellationToken);
            rule.ImageUrl = image?.Url;
            rule.Text = line.Substring(line.LastIndexOf("}}") + 2, (line.Length - (line.LastIndexOf("}}") + 2))).Trim();
        }
        return rule;
    }    
}
