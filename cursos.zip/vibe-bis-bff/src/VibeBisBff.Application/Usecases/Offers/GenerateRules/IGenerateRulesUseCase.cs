﻿using VibeBisBff.Dto.Offer;

namespace VibeBisBff.Application.Usecases.Offers.GenerateRules;

public interface IGenerateRulesUseCase
{
    Task<(List<RulesOfferDto>, string)> Execute(string description, CancellationToken cancellationToken);
}
