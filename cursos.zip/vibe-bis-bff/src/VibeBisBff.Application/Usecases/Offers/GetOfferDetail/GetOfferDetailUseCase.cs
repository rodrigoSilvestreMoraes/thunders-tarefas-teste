﻿using Common.Core.Authentication.Models;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.Infra.Extensions;
using ErrorOr;

namespace VibeBisBff.Application.Usecases.Offers.GetOfferDetail;

public class GetOfferDetailUseCase : IGetOfferDetailUseCase
{
    private readonly ITradebackPromoExternalService _tradebackPromoExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public GetOfferDetailUseCase(
        ITradebackPromoExternalService tradebackPromoExternalService,
        AuthenticatedUser authenticatedUser)
    {
        _tradebackPromoExternalService = tradebackPromoExternalService;
        _authenticatedUser = authenticatedUser;
    }

    public async Task<ErrorOr<AdvertisementDataDto>> Execute(string offerId, CancellationToken cancellationToken)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var offerFromTradebackPromo = await _tradebackPromoExternalService.SearchAdvertisements(
            new AdvertisementSearchRequestDto(new PromoPaginationDto(1, 1), new AdvertisementSearchFilterDto()
            {
                SaleIds = new[] { offerId }
            }), cancellationToken);

        if (offerFromTradebackPromo.IsError)
            return offerFromTradebackPromo.Errors;

        if (offerFromTradebackPromo.Value.NumberOfRows == 0)
            return Error.Validation("NO-QUEST", "Registro não encontrado");

        return offerFromTradebackPromo.Value.Data[0];
    }
}
