﻿using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using ErrorOr;

namespace VibeBisBff.Application.Usecases.Offers.GetOfferDetail;

public interface IGetOfferDetailUseCase
{
    Task<ErrorOr<AdvertisementDataDto>> Execute(string offerId, CancellationToken cancellationToken);
}
