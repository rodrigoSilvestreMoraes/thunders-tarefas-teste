﻿using VibeBisBff.Dto.Notifications;
using ErrorOr;

namespace VibeBisBff.Application.Usecases.Notifications.GetNotReadNotifications;

public interface IGetNotReadNotificationsUseCase
{
    Task<ErrorOr<List<NotificationResponseDto>>> Execute();
}
