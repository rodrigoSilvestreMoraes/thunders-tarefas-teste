﻿using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.Application.Mappers.Notification;
using VibeBisBff.Domain.Repositories.MongoDb.Notifications;
using VibeBisBff.Dto.Notifications;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Notifications.GetNotReadNotifications;

public class GetNotReadNotificationsUseCase : IGetNotReadNotificationsUseCase
{
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly INotificationRepository _notificationRepository;

    public GetNotReadNotificationsUseCase(AuthenticatedUser authenticatedUser,
        INotificationRepository notificationRepository)
    {
        _authenticatedUser = authenticatedUser;
        _notificationRepository = notificationRepository;
    }

    public async Task<ErrorOr<List<NotificationResponseDto>>> Execute()
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var notifications = await _notificationRepository.GetNotRead(digitalAccountId.Value);

        return notifications.Select(NotificationMapper.Map).ToList();
    }
}
