﻿using ErrorOr;

namespace VibeBisBff.Application.Usecases.Notifications.PushNotification;

public interface IPushNotificationUseCase
{
    Task<ErrorOr<Success>> Execute(List<string> ids, CancellationToken cancellationToken = default);
}
