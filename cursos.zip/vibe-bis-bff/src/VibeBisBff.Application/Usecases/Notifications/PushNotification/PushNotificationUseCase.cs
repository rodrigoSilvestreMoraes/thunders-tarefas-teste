﻿using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.Domain.Repositories.MongoDb.Notifications;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Notifications.PushNotification;

public class PushNotificationUseCase : IPushNotificationUseCase
{
    private readonly INotificationRepository _notificationRepository;
    private readonly AuthenticatedUser _authenticatedUser;

    public PushNotificationUseCase(INotificationRepository notificationRepository, AuthenticatedUser authenticatedUser)
    {
        _notificationRepository = notificationRepository;
        _authenticatedUser = authenticatedUser;
    }

    public async Task<ErrorOr<Success>> Execute(List<string> ids, CancellationToken cancellationToken = default)
    {
        if (ids is null || !ids.Any())
            return Error.Validation("É necessário informar pelo menos um ID de notificação para marcá-la como lida");

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var tenantConfigId = _authenticatedUser.GetTenantConfig();

        if (tenantConfigId.IsError)
            return tenantConfigId.Errors;

        await _notificationRepository.UpdateManyToRead(ids, tenantConfigId.Value, cancellationToken);

        return Result.Success;
    }
}
