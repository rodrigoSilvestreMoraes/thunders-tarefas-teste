﻿using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.Application.Mappers.Notification;
using VibeBisBff.Domain.Repositories.MongoDb.Notifications;
using VibeBisBff.Dto.Notifications;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Notifications.GetNotifications;

public class GetNotificationsUseCase : IGetNotificationsUseCase
{
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly INotificationRepository _notificationRepository;

    public GetNotificationsUseCase(AuthenticatedUser authenticatedUser, INotificationRepository notificationRepository)
    {
        _authenticatedUser = authenticatedUser;
        _notificationRepository = notificationRepository;
    }

    public async Task<ErrorOr<List<NotificationResponseDto>>> Execute(int offset, int limit)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var notifications = await _notificationRepository.GetByDigitalAccountAndSortByNotReadFirst(digitalAccountId.Value, offset, limit);

        return notifications.Select(NotificationMapper.Map).ToList();
    }
}
