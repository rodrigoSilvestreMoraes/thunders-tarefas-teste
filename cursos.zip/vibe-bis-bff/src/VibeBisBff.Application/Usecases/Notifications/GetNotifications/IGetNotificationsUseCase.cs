﻿using ErrorOr;
using VibeBisBff.Dto.Notifications;

namespace VibeBisBff.Application.Usecases.Notifications.GetNotifications
{
    public interface IGetNotificationsUseCase
    {
        Task<ErrorOr<List<NotificationResponseDto>>> Execute(int offset, int limit);
    }
}
