﻿using VibeBisBff.CrossCuting.Dto.Version;
using ErrorOr;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.Application.Usecases.Version.GetVersion;

public interface IGetVersionUseCase
{
    Task<ErrorOr<VersionResponseDto>> Execute(CancellationToken cancellationToken,
        string tenantConfigId = null, ApplicationType? appType = ApplicationType.Vibe);
}
