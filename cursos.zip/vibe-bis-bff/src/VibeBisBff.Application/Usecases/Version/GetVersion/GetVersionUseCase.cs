﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Version;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.ExternalServices.TenantConfigService;

namespace VibeBisBff.Application.Usecases.Version.GetVersion;

public class GetVersionUseCase : IGetVersionUseCase
{
    private readonly ITenantService _tenantService;

    public GetVersionUseCase(
        ITenantService tenantService) =>
        _tenantService = tenantService;

    //TODO: Usar os serviços IGoogleApiExternalServices e IAppleApiExternalServices quando for implementada a feature de versão atual.
    public async Task<ErrorOr<VersionResponseDto>> Execute(
        CancellationToken cancellationToken,
        string tenantConfigId = null, ApplicationType? appType = ApplicationType.Vibe)
    {
        var minimumAppVersion = await _tenantService.GetMinimumAppVersion(appType, tenantConfigId, cancellationToken);

        if (string.IsNullOrWhiteSpace(minimumAppVersion))
            return Error.Validation(Constants.ErrorCodes.NO_MINIMUM_APP_VERSION_FOUND,
                "Versão mínima para o app não definida");

        return new VersionResponseDto
        {
            MinimumAppVersion = minimumAppVersion
        };
    }
}
