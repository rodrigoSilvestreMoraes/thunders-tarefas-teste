﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Engagement;

namespace VibeBisBff.Application.Usecases.Banners.GetShowcaseByListExternalId;

public interface IGetShowcaseByListExternalIdUseCase
{
    Task<ErrorOr<List<ShowcaseResponseDto>>> Execute(List<string> identifiers, CancellationToken cancellationToken);
}
