﻿using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Engagement;
using VibeBisBff.Domain.Entities.Banners;
using VibeBisBff.Domain.Repositories.MongoDb.Banners;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Banners.GetShowcaseByListExternalId;

public class GetShowcaseByListExternalIdUseCase : IGetShowcaseByListExternalIdUseCase
{
    private readonly IBannerShowcaseRepository _bannerShowcaseRepository;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IMapper _mapper;

    public GetShowcaseByListExternalIdUseCase(
        IBannerShowcaseRepository bannerShowcaseRepository,
        AuthenticatedUser authenticatedUser,
        IMapper mapper)
    {
        _bannerShowcaseRepository = bannerShowcaseRepository;
        _authenticatedUser = authenticatedUser;
        _mapper = mapper;
    }

    public async Task<ErrorOr<List<ShowcaseResponseDto>>> Execute(List<string> identifiers, CancellationToken cancellationToken)
    {
        var tenantConfigId = _authenticatedUser.GetTenantConfig();

        if (tenantConfigId.IsError)
            return tenantConfigId.Errors;

        return _mapper.Map<List<BannerShowcase>, List<ShowcaseResponseDto>>
        (await _bannerShowcaseRepository.GetActiveByExternalIdentifiers(identifiers, tenantConfigId.Value, cancellationToken));
    }
}
