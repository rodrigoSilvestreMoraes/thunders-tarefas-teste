﻿using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Engagement;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Extensions;
using VibeBisBff.Domain.Entities.Banners;
using VibeBisBff.Domain.Repositories.MongoDb.Banners;
using VibeBisBff.ExternalServices.Tradeback.ParticipantSegment;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Banners.GetShowcase;

public class GetAvailableShowcaseUseCase : IGetAvailableShowcaseUseCase
{
    private readonly IBannerShowcaseRepository _bannerShowcaseRepository;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly ITradebackParticipantSegmentExternalService _tradebackParticipantSegmentExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IMapper _mapper;

    public GetAvailableShowcaseUseCase(
        IBannerShowcaseRepository bannerShowcaseRepository,
        IMapper mapper,
        AuthenticatedUser authenticatedUser,
        ITradebackParticipantSegmentExternalService tradebackParticipantSegmentExternalService,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _bannerShowcaseRepository = bannerShowcaseRepository;
        _mapper = mapper;
        _authenticatedUser = authenticatedUser;
        _tradebackParticipantSegmentExternalService = tradebackParticipantSegmentExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
    }

    public async Task<ErrorOr<List<ShowcaseResponseDto>>> Execute(string identifier,
        CancellationToken cancellationToken)
    {
        var tenantConfigId = _authenticatedUser.GetTenantConfig();

        if (tenantConfigId.IsError)
            return tenantConfigId.Errors;

        var bannerShowcases = await _bannerShowcaseRepository.GetActiveByExternalIdentifier(identifier,
            tenantConfigId.Value, cancellationToken);

        if (bannerShowcases.IsNullOrEmpty())
            return new ErrorOr<List<ShowcaseResponseDto>>();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var userOnDigitalAccount =
            await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        var segmentIds = await _tradebackParticipantSegmentExternalService
            .GetSegmentsIdsByParticipant(userOnDigitalAccount!.UserDocument, cancellationToken);

        if (segmentIds.IsError)
            return Error.Failure("SEGMENT-CONSULT-ERROR", ErrorConstants.GENERIC_ERROR);

        var segmentIdsAsHashSet = new HashSet<string>(segmentIds.Value);

        foreach (var bannerShowcase in bannerShowcases)
        {
            bannerShowcase.Items = bannerShowcase.Items.Where(banner =>
                    (banner.ParticipantSegmentIds.IsNullOrEmpty() ||
                     banner.ParticipantSegmentIds.Exists(segmentId => segmentIdsAsHashSet.Contains(segmentId))
                    ) && (banner.ExclusionParticipantSegmentIds.IsNullOrEmpty() ||
                          !banner.ExclusionParticipantSegmentIds.Exists(segmentId =>
                              segmentIdsAsHashSet.Contains(segmentId))))
                .ToList();
        }

        return _mapper.Map<List<BannerShowcase>, List<ShowcaseResponseDto>>(bannerShowcases);
    }
}
