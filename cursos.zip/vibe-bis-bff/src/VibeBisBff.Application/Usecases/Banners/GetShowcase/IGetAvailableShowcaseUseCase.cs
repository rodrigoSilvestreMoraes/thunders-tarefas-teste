﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Engagement;

namespace VibeBisBff.Application.Usecases.Banners.GetShowcase;

public interface IGetAvailableShowcaseUseCase
{
    Task<ErrorOr<List<ShowcaseResponseDto>>> Execute(string identifier, CancellationToken cancellationToken);
}
