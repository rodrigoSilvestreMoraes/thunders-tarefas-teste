﻿using ErrorOr;
using FluentValidation;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.Dto.ContactUs;

namespace VibeBisBff.Application.Usecases.ContactUs.Send
{
    public class SendContactUsLoggedOutUserUseCase : ISendContactUsLoggedOutUserUseCase
    {
        private readonly IValidator<ContactUsLoggedOutUserRequestDto> _validationContactUsLoggedOutUserRequest;
        private readonly IContactUsRepository _contactUsRepository;

        public SendContactUsLoggedOutUserUseCase(IValidator<ContactUsLoggedOutUserRequestDto> validationContactUsLoggedOutUserRequest,
            IContactUsRepository contactUsRepository)
        {
            _validationContactUsLoggedOutUserRequest = validationContactUsLoggedOutUserRequest;
            _contactUsRepository = contactUsRepository;
        }

        public async Task<ErrorOr<Success>> Execute(ContactUsLoggedOutUserRequestDto contactUsLoggedOutUserRequest)
        {
            var validationResult = await _validationContactUsLoggedOutUserRequest.ValidateAsync(contactUsLoggedOutUserRequest);

            if (!validationResult.IsValid) return validationResult.Errors.ToValidation();

            var contactUs = MapToContactUs(contactUsLoggedOutUserRequest);

            await _contactUsRepository.Insert(contactUs);

            return Result.Success;
        }

        private static Domain.Entities.ContactUs MapToContactUs(ContactUsLoggedOutUserRequestDto contactUsLoggedOutUserRequest) =>
         new(contactUsLoggedOutUserRequest.Name,
             contactUsLoggedOutUserRequest.CellPhone,
             contactUsLoggedOutUserRequest.Email,
             contactUsLoggedOutUserRequest.Subject,
             contactUsLoggedOutUserRequest.Message);
    }
}
