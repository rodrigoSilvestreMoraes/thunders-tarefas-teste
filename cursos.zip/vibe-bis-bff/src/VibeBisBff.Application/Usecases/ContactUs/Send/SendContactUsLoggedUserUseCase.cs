﻿using Common.Core.Authentication.Models;
using ErrorOr;
using FluentValidation;
using Microsoft.Extensions.Options;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.Dto.ContactUs;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.Infra.Files;

namespace VibeBisBff.Application.Usecases.ContactUs.Send
{
    public class SendContactUsLoggedUserUseCase : ISendContactUsLoggedUserUseCase
    {
        private readonly IValidator<ContactUsLoggedUserRequestDto> _validationContactUsLoggedUserRequest;
        private readonly IContactUsRepository _contactUsRepository;
        private readonly AuthenticatedUser _authenticatedUser;
        private readonly IUploaderFile _uploaderFile;
        private readonly StorageAccountOptions _storageAccountOption;

        public SendContactUsLoggedUserUseCase(
            IValidator<ContactUsLoggedUserRequestDto> validationContactUsLoggedUserRequest,
            IContactUsRepository contactUsRepository,
            AuthenticatedUser authenticatedUser,
            IUploaderFile uploaderFile, IOptionsSnapshot<StorageAccountOptions> storageAccountOption)
        {
            _validationContactUsLoggedUserRequest = validationContactUsLoggedUserRequest;
            _contactUsRepository = contactUsRepository;
            _authenticatedUser = authenticatedUser;
            _uploaderFile = uploaderFile;
            _storageAccountOption = storageAccountOption.Value;
        }

        public async Task<ErrorOr<Success>> Execute(ContactUsLoggedUserRequestDto contactUsLoggedUserRequest)
        {
            var validationResult =
                await _validationContactUsLoggedUserRequest.ValidateAsync(contactUsLoggedUserRequest);

            if (!validationResult.IsValid) return validationResult.Errors.ToValidation();

            var fileUrl = await UploadAndReturnUrlIfHasFile(contactUsLoggedUserRequest);

            var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

            if (digitalAccountId.IsError) return digitalAccountId.Errors;

            var contactUs = MapToContactUs(digitalAccountId.Value, contactUsLoggedUserRequest, fileUrl);

            await _contactUsRepository.Insert(contactUs);

            return Result.Success;
        }

        private async Task<string> UploadAndReturnUrlIfHasFile(ContactUsLoggedUserRequestDto contactUsLoggedUserRequest) =>
            contactUsLoggedUserRequest.File is { Length: > 0 }
                ? await _uploaderFile.Upload(contactUsLoggedUserRequest.File, _storageAccountOption.VibeContactUsBlobContainer)
                : null;

        private static Domain.Entities.ContactUs MapToContactUs(string digitalAccountId,
            ContactUsLoggedUserRequestDto contactUsLoggedUserRequest,
            string fileUrl) =>
            new(digitalAccountId,
                contactUsLoggedUserRequest.Subject,
                contactUsLoggedUserRequest.Message,
                fileUrl);
    }
}
