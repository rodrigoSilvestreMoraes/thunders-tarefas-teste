﻿using ErrorOr;
using VibeBisBff.Dto.ContactUs;

namespace VibeBisBff.Application.Usecases.ContactUs.Send
{
    public interface ISendContactUsLoggedUserUseCase
    {
        Task<ErrorOr<Success>> Execute(ContactUsLoggedUserRequestDto contactUsLoggedUserRequest);
    }
}
