﻿using ErrorOr;
using VibeBisBff.Dto.ContactUs;

namespace VibeBisBff.Application.Usecases.ContactUs.Send
{
    public interface ISendContactUsLoggedOutUserUseCase
    {
        Task<ErrorOr<Success>> Execute(ContactUsLoggedOutUserRequestDto contactUsLoggedOutUserRequest);
    }
}
