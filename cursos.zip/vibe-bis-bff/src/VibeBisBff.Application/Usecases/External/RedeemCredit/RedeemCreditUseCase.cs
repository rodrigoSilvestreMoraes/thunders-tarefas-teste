﻿using ErrorOr;
using FluentValidation;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Helpers.External;
using VibeBisBff.CrossCuting.Dto.External.Request;
using VibeBisBff.CrossCuting.Dto.External.Response;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Extensions;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Tradeback.Authorizer;
using VibeBisBff.ExternalServices.Tradeback.Authorizer.Dto;

namespace VibeBisBff.Application.Usecases.External.RedeemCredit;

public class RedeemCreditUseCase : IRedeemCreditUseCase
{
    private readonly ITradebackAuthorizerExternalService _tradebackAuthorizerExternalService;
    private readonly IValidator<RedeemCreditRequestDto> _validator;
    private readonly ITenantService _tenantService;
    private readonly VertemLogsLogger _logger;

    public RedeemCreditUseCase(ITradebackAuthorizerExternalService tradebackAuthorizerExternalService,
        IValidator<RedeemCreditRequestDto> validator, ITenantService tenantService, VertemLogsLogger logger)
    {
        _tradebackAuthorizerExternalService = tradebackAuthorizerExternalService;
        _validator = validator;
        _tenantService = tenantService;
        _logger = logger;
    }

    public async Task<ErrorOr<RedeemCreditResponseDto>> Execute(RedeemCreditRequestDto request,
        CancellationToken cancellationToken)
    {
        var validationResult = await _validator.ValidateAsync(request, cancellationToken);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var redeemCreditConfiguration =
            await _tenantService.GetRedeemCreditConfiguration(request.AppType, request.TenantConfigId,
                cancellationToken);

        if (redeemCreditConfiguration is null or { TradebackCampaignId: null, TradebackStoreId: null })
            return Error.Failure("NO-REDEEM-CREDIT-CONFIGURATION", ErrorConstants.GENERIC_ERROR);

        try
        {
            var transactionResult = await _tradebackAuthorizerExternalService.GenerateAndConfirmBenefit(
                request.ParticipantDocument,
                redeemCreditConfiguration.TradebackStoreId,
                new List<int> { redeemCreditConfiguration.TradebackCampaignId!.Value },
                TradebackAuthorizerHelper.GetDefaultCartItems(),
                Guid.NewGuid().ToString(),
                attributes: new[]
                {
                    new CartAttributeItemDto
                    {
                        Key = "cellphone",
                        Values = new[] { request.Cellphone },
                        Description = "Telefone do participante"
                    },
                    new CartAttributeItemDto
                    {
                        Key = "optin",
                        Values = new[] { request.OptIn.ToString() },
                        Description = "O participante aceitou os termos e condições"
                    }
                },
                appType: request.AppType,
                tenantConfigId: request.TenantConfigId,
                pinCode: request.PinCode);

            if (transactionResult.Benefits.IsNullOrEmpty())
                return new RedeemCreditResponseDto
                {
                    Success = false,
                    ReceivedAmount = 0
                };

            var creditBenefits =
                transactionResult.Benefits!
                    .Where(benefit => TradebackAuthorizerHelper.IsCreditBenefit(benefit.BenefitTypeId)).ToArray();

            if (creditBenefits.IsNullOrEmpty())
                return new RedeemCreditResponseDto
                {
                    Success = false,
                    ReceivedAmount = 0
                };

            return new RedeemCreditResponseDto
            {
                Success = true,
                ReceivedAmount = creditBenefits.Sum(x => x.BenefitValue)
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(new ExceptionLog(ex));
            return Error.Unexpected("ERROR-AUTHORIZER-CALL", ErrorConstants.GENERIC_ERROR);
        }
    }
}
