﻿using VibeBisBff.CrossCuting.Dto.External.Request;
using VibeBisBff.CrossCuting.Dto.External.Response;
using ErrorOr;

namespace VibeBisBff.Application.Usecases.External.RedeemCredit;

public interface IRedeemCreditUseCase
{
    Task<ErrorOr<RedeemCreditResponseDto>> Execute(RedeemCreditRequestDto request,
        CancellationToken cancellationToken);
}
