﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using Common.Core.Exceptions;
using ErrorOr;
using VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflowNewKey;

public class ChangeKeyWorkflowNewKeyUseCase : IChangeKeyWorkflowNewKeyUseCase
{
    private readonly IChangeKeyWorkflowRepository _changeKeyWorkflowRepository;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;

    public ChangeKeyWorkflowNewKeyUseCase(IChangeKeyWorkflowRepository changeKeyWorkflowRepository,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        AuthenticationProvider authenticationProvider,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _changeKeyWorkflowRepository = changeKeyWorkflowRepository;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
    }

    public async Task<ErrorOr<Success>> Execute(string changeKeyWorkflowId, string newKey)
    {
        var workflow = await _changeKeyWorkflowRepository.GetById(changeKeyWorkflowId);

        if (workflow is null)
            return Error.Validation(description: "Foi enviado um processo de validação não existente");

        if (!workflow.IsOtpValidated)
            return Error.Validation(description: "Fluxo não validado!");

        if (workflow.IsNewOtpValidated)
            return Result.Success;

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(workflow.DigitalAccountId);

        // TODO: Pensar em uma melhor abordagem
        switch (workflow.Workflow)
        {
            case ChangeKeyWorkflowType.ChangeCellphone:
                var phoneId = digitalAccount.DigitalAccountPhones.FirstOrDefault()?.Id;

                await _digitalAccountExternalService.UpdatePhoneNumberFromDigitalAccount(newKey, workflow.DigitalAccountId, phoneId);
                break;
            case ChangeKeyWorkflowType.ChangeEmail:
                var emailId = digitalAccount.DigitalAccountEmails.FirstOrDefault()?.Id;

                await _digitalAccountExternalService.UpdateEmailFromDigitalAccount(newKey, workflow.DigitalAccountId, emailId);
                break;
        }

        var otp = await SendOtpByWorkflowType(workflow.Workflow, newKey, digitalAccountId.Value);

        if(otp.IsTooManyRequest)
            return Error.Failure(description: ErrorConstants.TOO_MANY_CODES_REQUESTS);

        workflow.SetNewKeyOtpId(otp.OtpId);
        workflow.SetNewKey(newKey);

        await _changeKeyWorkflowRepository.Update(workflow);

        return Result.Success;
    }

    private async Task<OtpReturnDto> SendOtpByWorkflowType(ChangeKeyWorkflowType changeKeyWorkflowType,
        string key,
        string digitalAccountId
    )
    {
        // TODO: Enviar OTP de Validação
        return changeKeyWorkflowType switch
        {
            ChangeKeyWorkflowType.ChangeCellphone => await _identityAccessManagementExternalService.SendCellphoneOtp(
                    key,
                    digitalAccountId
                ),
            ChangeKeyWorkflowType.ChangeEmail => await _identityAccessManagementExternalService.SendEmailValidationOtp(key, digitalAccountId),
            ChangeKeyWorkflowType.ForgotPassword => throw new BusinessException("Tipo inválido"),
                _ => throw new BusinessException("Tipo inválido")
        };
    }
}
