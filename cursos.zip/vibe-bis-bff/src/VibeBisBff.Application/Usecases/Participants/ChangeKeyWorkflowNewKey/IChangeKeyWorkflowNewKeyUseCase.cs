﻿using ErrorOr;

namespace VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflowNewKey;

public interface IChangeKeyWorkflowNewKeyUseCase
{
    Task<ErrorOr<Success>> Execute(string changeKeyWorkflowId, string newKey);
}
