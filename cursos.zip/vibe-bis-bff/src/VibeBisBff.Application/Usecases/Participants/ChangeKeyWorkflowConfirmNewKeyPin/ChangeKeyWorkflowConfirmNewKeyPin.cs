﻿using ErrorOr;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;

namespace VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflowConfirmNewKeyPin;

public class ChangeKeyWorkflowConfirmNewKeyPin : IChangeKeyWorkflowConfirmNewKeyPin
{
    private readonly IChangeKeyWorkflowRepository _changeKeyWorkflowRepository;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;

    public ChangeKeyWorkflowConfirmNewKeyPin(IChangeKeyWorkflowRepository changeKeyWorkflowRepository,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService)
    {
        _changeKeyWorkflowRepository = changeKeyWorkflowRepository;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
    }

    public async Task<ErrorOr<Success>> Execute(ChangeKeyValidateNewKeyDto changeKeyValidateNewKeyDto)
    {
        var workflow = await _changeKeyWorkflowRepository.GetById(changeKeyValidateNewKeyDto.ChangeKeyWorkflowId);

        if (workflow is null)
            return Error.Validation(description: "Foi enviado um processo de validação não existente");

        var validationResult = await _identityAccessManagementExternalService.ValidateOtpCode(workflow.NewKeyOtpId, changeKeyValidateNewKeyDto.Pin,
            appType: changeKeyValidateNewKeyDto.AppType, tenantConfigId: changeKeyValidateNewKeyDto.TenantConfigId);

        if (!validationResult.Success)
            return Error.Validation(description: "PIN inválido");

        workflow.SetIsNewOtpValidated();

        await _changeKeyWorkflowRepository.Update(workflow);

        return Result.Success;
    }
}
