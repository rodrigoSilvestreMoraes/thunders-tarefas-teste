﻿using ErrorOr;
using VibeBisBff.Dto.Participants;

namespace VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflowConfirmNewKeyPin;

public interface IChangeKeyWorkflowConfirmNewKeyPin
{
    Task<ErrorOr<Success>> Execute(ChangeKeyValidateNewKeyDto changeKeyValidateNewKeyDto);
}
