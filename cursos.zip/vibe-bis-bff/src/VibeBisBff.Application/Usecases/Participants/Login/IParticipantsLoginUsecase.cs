﻿using ErrorOr;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;

namespace VibeBisBff.Application.Usecases.Participants.Login;

public interface IParticipantsLoginUsecase
{
    Task<Tuple<ErrorOr<AccessTokenResponseDto>, NotPhoneValidatedResponseDto>> Execute(ParticipantsLoginDto participantsLoginRequest);
}
