﻿using ErrorOr;
using FluentValidation;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;

namespace VibeBisBff.Application.Usecases.Participants.Login;

public class ParticipantsLoginUsecase : IParticipantsLoginUsecase
{
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly IValidator<ParticipantsLoginDto> _participantsLoginValidator;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly ITenantService _tenantService;

    public ParticipantsLoginUsecase(IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        IValidator<ParticipantsLoginDto> participantsLoginValidator,
        IDigitalAccountExternalService digitalAccountExternalService,
        ITenantService tenantService)
    {
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _participantsLoginValidator = participantsLoginValidator;
        _digitalAccountExternalService = digitalAccountExternalService;
        _tenantService = tenantService;
    }

    public async Task<Tuple<ErrorOr<AccessTokenResponseDto>, NotPhoneValidatedResponseDto>> Execute(ParticipantsLoginDto participantsLoginRequest)
    {
        var validationResult = await _participantsLoginValidator.ValidateAsync(participantsLoginRequest);

        if (!validationResult.IsValid)
            return GetTupleToAccessTokenResponseAndNotPhoneValidatedResponse(validationResult.Errors.ToValidation());

        var loginCredentials = await _tenantService.GetUserClientConfig(participantsLoginRequest.AppType, participantsLoginRequest.TenantConfigId);

        var accessTokenResponse = await _identityAccessManagementExternalService.Login(participantsLoginRequest.Username,
            participantsLoginRequest.Password, loginCredentials);

        if (accessTokenResponse.IsError)
            return GetTupleToAccessTokenResponseAndNotPhoneValidatedResponse(accessTokenResponse);

        var digitalAccountId = accessTokenResponse.Value.GetDigitalAccountId();

        var digitalAccount =  await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId, participantsLoginRequest.AppType, participantsLoginRequest.TenantConfigId);

        if (digitalAccount.HasValidatedPhone())
            return GetTupleToAccessTokenResponseAndNotPhoneValidatedResponse(accessTokenResponse);

        var otp = await _identityAccessManagementExternalService.SendCellphoneOtp(digitalAccount.GetCellphone(), digitalAccountId,
            "onboarding", participantsLoginRequest.AppType, participantsLoginRequest.TenantConfigId);

        return otp.IsTooManyRequest
            ? GetTupleToAccessTokenResponseAndNotPhoneValidatedResponse(Error.Failure(description: ErrorConstants.TOO_MANY_CODES_REQUESTS))
            : GetTupleToAccessTokenResponseAndNotPhoneValidatedResponse(accessTokenResponse, new NotPhoneValidatedResponseDto(digitalAccountId, otp.OtpId));
    }

    private static Tuple<ErrorOr<AccessTokenResponseDto>, NotPhoneValidatedResponseDto> GetTupleToAccessTokenResponseAndNotPhoneValidatedResponse
        (ErrorOr<AccessTokenResponseDto> accessTokenResponse, NotPhoneValidatedResponseDto notPhoneValidatedResponse = null)
    {
        return Tuple.Create(accessTokenResponse, notPhoneValidatedResponse);
    }
}
