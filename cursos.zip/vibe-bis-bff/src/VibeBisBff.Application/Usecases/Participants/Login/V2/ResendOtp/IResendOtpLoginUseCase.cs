﻿using ParticipantsDto = VibeBisBff.Dto.Participants;
using ErrorOr;
using VibeBisBff.Dto.Participants.V2.Request;

namespace VibeBisBff.Application.Usecases.Participants.Login.V2.ResendOtp;

public interface IResendOtpLoginUseCase
{
    Task<ErrorOr<ParticipantsDto.SendOtpResponseDto>> Execute(ParticipantLoginDto participantLoginDto);
}
