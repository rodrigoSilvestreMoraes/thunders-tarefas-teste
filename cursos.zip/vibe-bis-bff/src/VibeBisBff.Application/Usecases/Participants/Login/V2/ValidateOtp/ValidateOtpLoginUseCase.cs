﻿using System.Text.Json;
using Common.Core.Exceptions;
using ErrorOr;
using FluentValidation;
using VibeBisBff.CrossCuting.Dto.Authentication.Request;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Dto.Participants.V2.Request;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Vertem.IamClientCredentials;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;
using VibeBisBff.Infra.Cache;
using ParticipantsDto = VibeBisBff.Dto.Participants;

namespace VibeBisBff.Application.Usecases.Participants.Login.V2.ValidateOtp;

public class ValidateOtpLoginUseCase : IValidateOtpLoginUseCase
{
    private readonly IRedisService _redisService;

    private readonly IValidator<ParticipantLoginOtpDto> _validator;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly IVertemIamTenantService _vertemIamTenantService;
    private readonly ITenantService _tenantService;

    public ValidateOtpLoginUseCase(
        IRedisService redisService,
        IValidator<ParticipantLoginOtpDto> validator,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        IVertemIamTenantService vertemIamTenantService,
        ITenantService tenantService)
    {
        _redisService = redisService;
        _validator = validator;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _vertemIamTenantService = vertemIamTenantService;
        _tenantService = tenantService;
    }

    public async Task<ErrorOr<AccessTokenResponseDto>> Execute(ParticipantLoginOtpDto participantLoginOtpDto)
    {
        var validationResult = await _validator.ValidateAsync(participantLoginOtpDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var token = await ValidateOtpWithIamOnboardingFlow(participantLoginOtpDto);

        if (token != null)
            return token;

        return await ValidateOtpWithIamAuthenticationFlow(participantLoginOtpDto);
    }

    private async Task<AccessTokenResponseDto> ValidateOtpWithIamAuthenticationFlow(
        ParticipantLoginOtpDto participantLoginOtpDto)
    {
        var client =
            await _tenantService.GetIamClientId(participantLoginOtpDto.AppType, participantLoginOtpDto.TenantConfigId);

        var secret =
            await _tenantService.GetIamClientSecret(participantLoginOtpDto.AppType,
                participantLoginOtpDto.TenantConfigId);

        var result = await _vertemIamTenantService.GetObjectAccessTokenForOtpCredentials(new TokenRequestDto
        {
            ClientId = client,
            ClientSecret = secret,
            OtpCode = participantLoginOtpDto.Code,
            OtpId = participantLoginOtpDto.OtpId,
        });

        if (result is null)
            throw new BusinessException(ErrorConstants.GENERIC_ERROR);

        return result;
    }

    private async Task<AccessTokenResponseDto> ValidateOtpWithIamOnboardingFlow(
        ParticipantLoginOtpDto participantLoginOtpDto)
    {
        var otpOnboarding = await _redisService.Get($"{Constants.GenerateOtp.REDIS_KEY_ONBOARDING_OTP_FLOW}_{participantLoginOtpDto.OtpId}");

        if (string.IsNullOrEmpty(otpOnboarding)) return null;

        var otpRequestOnboarding = JsonSerializer.Deserialize<ParticipantsDto.SendOtpResponseDto>(otpOnboarding);

        var result = await _identityAccessManagementExternalService.ValidateOtpCode(
            otpId: otpRequestOnboarding.PinId,
            code: participantLoginOtpDto.Code,
            flow: "onboarding",
            generateToken: true,
            appType: participantLoginOtpDto.AppType,
            tenantConfigId: participantLoginOtpDto.TenantConfigId);

        if (!result.Success)
            throw new BusinessException(result.GetFriendlyErrorMessage()!);

        return result.GetGeneratedToken();
    }
}
