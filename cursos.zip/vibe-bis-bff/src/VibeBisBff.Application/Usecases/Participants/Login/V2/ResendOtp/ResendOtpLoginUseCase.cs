﻿using ErrorOr;
using VibeBisBff.Application.Usecases.Participants.Login.V2.GenerateOtp;
using VibeBisBff.Dto.Participants;
using VibeBisBff.Dto.Participants.V2.Request;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;

namespace VibeBisBff.Application.Usecases.Participants.Login.V2.ResendOtp
{
    public class ResendOtpLoginUseCase : IResendOtpLoginUseCase
    {
        private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
        private readonly IGenerateOtpUseCase _generateOtpUseCase;

       public ResendOtpLoginUseCase(
           IIdentityAccessManagementExternalService identityAccessManagementExternalService,
           IGenerateOtpUseCase generateOtpUseCase)
        {
            _identityAccessManagementExternalService = identityAccessManagementExternalService;
            _generateOtpUseCase = generateOtpUseCase;
        }

        public async Task<ErrorOr<SendOtpResponseDto>> Execute(ParticipantLoginDto participantLoginDto)
            => await _generateOtpUseCase.Execute(participantLoginDto, _identityAccessManagementExternalService.SendWhatsappOtp);
    }
}
