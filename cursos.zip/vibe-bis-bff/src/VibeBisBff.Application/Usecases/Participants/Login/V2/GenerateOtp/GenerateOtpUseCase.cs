﻿using ErrorOr;
using FluentValidation;
using VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Participants;
using VibeBisBff.Dto.Participants.V2.Request;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Cache;

namespace VibeBisBff.Application.Usecases.Participants.Login.V2.GenerateOtp;

public class GenerateOtpUseCase : IGenerateOtpUseCase
{
    private readonly IRedisService _redisService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IValidator<ParticipantLoginDto> _validator;

    private const long HOURS_IN_SECONDS = 1200;

    public GenerateOtpUseCase(
        IRedisService redisService,
        IDigitalAccountExternalService digitalAccountExternalService,
        IValidator<ParticipantLoginDto> validator)
    {
        _redisService = redisService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _validator = validator;
    }

    public async Task<ErrorOr<SendOtpResponseDto>> Execute(ParticipantLoginDto participantLoginDto,
        Func<string, string, string, ApplicationType?, string, Task<OtpReturnDto>> funcSendOtp)
    {
        var validationResult = await _validator.ValidateAsync(participantLoginDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var digitalAccount = await _digitalAccountExternalService.GetDigitalAccountByDocument(participantLoginDto.Username,
            participantLoginDto.AppType,
            participantLoginDto.TenantConfigId);

        if (digitalAccount == null)
            return Error.Validation("NO-REGISTRATION-FOUND", "O usuário não foi encontrado");

        if (!digitalAccount.HasRegistrationByVibe())
            return Error.Validation("NO-REGISTRATION-BY-VIBE", "O usuário não foi encontrado");

        var shouldUseAuthenticationFlow = digitalAccount.HasValidatedPhone();

        var response = await funcSendOtp(digitalAccount.GetCellphone(),
            digitalAccount.Id,
            shouldUseAuthenticationFlow ? "authentication" : "onboarding",
            participantLoginDto.AppType,
            participantLoginDto.TenantConfigId);

        if (response.IsTooManyRequest)
            return Error.Failure(description: ErrorConstants.TOO_MANY_CODES_REQUESTS);

        var result = new SendOtpResponseDto(response.OtpId);

        if (!shouldUseAuthenticationFlow)
            await _redisService.Set($"{Constants.GenerateOtp.REDIS_KEY_ONBOARDING_OTP_FLOW}_{response.OtpId}", result, HOURS_IN_SECONDS);

        return result;
    }
}
