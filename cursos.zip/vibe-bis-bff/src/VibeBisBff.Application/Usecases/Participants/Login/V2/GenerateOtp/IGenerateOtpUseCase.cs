﻿using ParticipantsDto = VibeBisBff.Dto.Participants;
using ErrorOr;
using VibeBisBff.Dto.Participants.V2.Request;
using VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.Application.Usecases.Participants.Login.V2.GenerateOtp;

public interface IGenerateOtpUseCase
{
    Task<ErrorOr<ParticipantsDto.SendOtpResponseDto>> Execute(ParticipantLoginDto participantLoginDto, Func<string, string, string,ApplicationType?,string, Task<OtpReturnDto>> funcSendOtp);
}
