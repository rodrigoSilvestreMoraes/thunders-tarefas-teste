﻿using ErrorOr;
using VibeBisBff.Application.Usecases.Participants.Login.V2.GenerateOtp;
using VibeBisBff.Dto.Participants.V2.Request;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using ParticipantsDto = VibeBisBff.Dto.Participants;

namespace VibeBisBff.Application.Usecases.Participants.Login.V2.SendOtp;

public class SendOtpLoginUseCase : ISendOtpLoginUseCase
{
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly IGenerateOtpUseCase _generateOtpUseCase; 
    public SendOtpLoginUseCase(
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        IGenerateOtpUseCase generateOtpUseCase)
    {
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _generateOtpUseCase = generateOtpUseCase;
    }
    public async Task<ErrorOr<ParticipantsDto.SendOtpResponseDto>> Execute(ParticipantLoginDto participantLoginDto)
        => await _generateOtpUseCase.Execute(participantLoginDto, _identityAccessManagementExternalService.SendCellphoneOtp);
}
