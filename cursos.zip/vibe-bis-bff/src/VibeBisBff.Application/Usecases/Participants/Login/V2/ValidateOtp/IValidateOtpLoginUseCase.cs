﻿using ErrorOr;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;
using VibeBisBff.Dto.Participants.V2.Request;

namespace VibeBisBff.Application.Usecases.Participants.Login.V2.ValidateOtp;

public interface IValidateOtpLoginUseCase
{
    Task<ErrorOr<AccessTokenResponseDto>> Execute(ParticipantLoginOtpDto participantLoginOtpDto);
}
