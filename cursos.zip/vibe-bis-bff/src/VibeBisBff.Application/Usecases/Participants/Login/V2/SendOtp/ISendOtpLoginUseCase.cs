﻿using ParticipantsDto = VibeBisBff.Dto.Participants;
using ErrorOr;
using VibeBisBff.Dto.Participants.V2.Request;

namespace VibeBisBff.Application.Usecases.Participants.Login.V2.SendOtp;

public interface ISendOtpLoginUseCase
{
    Task<ErrorOr<ParticipantsDto.SendOtpResponseDto>> Execute(ParticipantLoginDto participantLoginDto);
}
