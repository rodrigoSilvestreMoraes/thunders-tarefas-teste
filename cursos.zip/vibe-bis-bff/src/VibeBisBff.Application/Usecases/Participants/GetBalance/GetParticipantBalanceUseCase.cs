﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Vertem.WalletVertem;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Participants.GetBalance;

public class GetParticipantBalanceUseCase : IGetParticipantBalanceUseCase
{
    private readonly IWalletVertemExternalService _walletVertemExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly ITenantService _tenantService;

    public GetParticipantBalanceUseCase(IWalletVertemExternalService walletVertemExternalService,
        AuthenticatedUser authenticatedUser,
        ITenantService tenantService)
    {
        _walletVertemExternalService = walletVertemExternalService;
        _authenticatedUser = authenticatedUser;
        _tenantService = tenantService;
    }

    public async Task<decimal> Execute()
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            throw new BusinessException("Erro ao buscar o identificador do usuário");

        var walletConfiguration = await _tenantService.GetWalletConfiguration();

        return await _walletVertemExternalService.GetBalance(digitalAccountId.Value,
            walletConfiguration.VirtualCoinsAccountingLedgerId);
    }
}
