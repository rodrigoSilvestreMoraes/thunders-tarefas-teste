﻿namespace VibeBisBff.Application.Usecases.Participants.GetBalance;

public interface IGetParticipantBalanceUseCase
{
    Task<decimal> Execute();
}
