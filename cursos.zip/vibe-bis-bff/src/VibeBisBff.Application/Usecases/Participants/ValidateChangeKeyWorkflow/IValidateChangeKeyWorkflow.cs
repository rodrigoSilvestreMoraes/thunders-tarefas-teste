﻿using ErrorOr;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.Application.Usecases.Participants.ValidateChangeKeyWorkflow;

public interface IValidateChangeKeyWorkflow
{
    Task<ErrorOr<Success>> Execute(string changeKeyWorkflowId, string pin, string newValue, ApplicationType? appType = null, string tenantConfigId = null);
}
