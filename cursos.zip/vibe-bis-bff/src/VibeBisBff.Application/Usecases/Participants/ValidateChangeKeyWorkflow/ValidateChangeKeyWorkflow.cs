﻿using ErrorOr;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;

namespace VibeBisBff.Application.Usecases.Participants.ValidateChangeKeyWorkflow;

public class ValidateChangeKeyWorkflow : IValidateChangeKeyWorkflow
{
    private readonly IChangeKeyWorkflowRepository _changeKeyWorkflowRepository;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;

    public ValidateChangeKeyWorkflow(IChangeKeyWorkflowRepository changeKeyWorkflowRepository,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService)
    {
        this._changeKeyWorkflowRepository = changeKeyWorkflowRepository;
        this._identityAccessManagementExternalService = identityAccessManagementExternalService;
    }

    public async Task<ErrorOr<Success>> Execute(string changeKeyWorkflowId, string pin, string newValue, ApplicationType? appType = null, string tenantConfigId = null)
    {
        var workflow = await _changeKeyWorkflowRepository.GetById(changeKeyWorkflowId);

        if (workflow is null)
            return Error.Validation(description: "Foi enviado um processo de validação não existente");

        var validationResult = await ValidatePin(pin, workflow, newValue, appType, tenantConfigId);

        if (validationResult.IsError)
            return validationResult.Errors;

        if (!validationResult.Value.Success)
            return Error.Validation(description: "PIN inválido");

        workflow.SetOtpValidated();

        await _changeKeyWorkflowRepository.Update(workflow);

        return Result.Success;
    }

    private async Task<ErrorOr<ValidateOtpResponseDto>> ValidatePin(string pin, Domain.Entities.ChangeKeyWorkflow workflow,
        string newValue, ApplicationType? appType = null, string tenantConfigId = null)
    {
        // TODO: Pensar em uma melhor abordagem
        if (workflow.Workflow == ChangeKeyWorkflowType.ForgotPassword)
            return await _identityAccessManagementExternalService.ValidateOtpCodeForForgotPassword(workflow.OtpId, pin, newValue, appType, tenantConfigId);
        return await _identityAccessManagementExternalService.ValidateOtpCode(workflow.OtpId, pin, appType: appType, tenantConfigId: tenantConfigId);
    }
}
