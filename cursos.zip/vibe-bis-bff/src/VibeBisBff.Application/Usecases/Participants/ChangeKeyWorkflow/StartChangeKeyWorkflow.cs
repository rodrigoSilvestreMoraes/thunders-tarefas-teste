﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Extensions;
using EChangeKeyWorkflow = VibeBisBff.Domain.Entities.ChangeKeyWorkflow;

namespace VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflow;

public class StartChangeKeyWorkflow : IStartChangeKeyWorkflow
{
    private readonly IChangeKeyWorkflowRepository _changeKeyWorkflowRepository;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public StartChangeKeyWorkflow(IChangeKeyWorkflowRepository changeKeyWorkflowRepository,
        IDigitalAccountExternalService digitalAccountExternalService,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        AuthenticationProvider authenticationProvider)
    {
        _changeKeyWorkflowRepository = changeKeyWorkflowRepository;
        _digitalAccountExternalService = digitalAccountExternalService;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
    }

    public async Task<ErrorOr<string>> Execute(ChangeKeyWorkflowType workflow)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);
        return await CreateChangeKeyWorkflow(digitalAccountId.Value, workflow, digitalAccount);
    }

    public async Task<ErrorOr<string>> ExecuteWithParticipantDocument(string participantDocument,
        ChangeKeyWorkflowType workflow,
        ApplicationType? appType = null, string tenantConfigId = null)
    {
        var digitalAccount =
            await _digitalAccountExternalService.GetDigitalAccountByDocument(participantDocument, appType,
                tenantConfigId);

        return await CreateChangeKeyWorkflow(digitalAccount.Id, workflow, digitalAccount, appType, tenantConfigId);
    }

    private async Task<ErrorOr<string>> CreateChangeKeyWorkflow(string digitalAccountId, ChangeKeyWorkflowType workflow,
        DigitalAccountParticipantDetail digitalAccount, ApplicationType? appType = null, string tenantConfigId = null)
    {
        OtpReturnDto otp;

        // TODO: Pensar em uma abordagem melhor
        if (workflow == ChangeKeyWorkflowType.ForgotPassword)
        {
            otp = new OtpReturnDto(digitalAccount.HasValidatedPhone()
                ? await _identityAccessManagementExternalService
                    .SendCellphoneForForgotPassword(digitalAccount.GetCellphone(), appType, tenantConfigId)
                : await _identityAccessManagementExternalService.RequestForgotPasswordOtpForNonIdentifierPhone(
                    digitalAccount.GetCellphone(), digitalAccountId,
                    appType, tenantConfigId), false);
        }
        else
            otp = await _identityAccessManagementExternalService.SendCellphoneOtp(digitalAccount.GetCellphone(),
                digitalAccountId, appType: appType, tenantConfigId: tenantConfigId);

        if (otp.IsTooManyRequest)
            return Error.Failure(code: "TooManyRequest");

        var changeKeyWorkflow = new EChangeKeyWorkflow(digitalAccountId, otp.OtpId, workflow);

        await _changeKeyWorkflowRepository.Insert(changeKeyWorkflow);

        return changeKeyWorkflow.Id;
    }
}
