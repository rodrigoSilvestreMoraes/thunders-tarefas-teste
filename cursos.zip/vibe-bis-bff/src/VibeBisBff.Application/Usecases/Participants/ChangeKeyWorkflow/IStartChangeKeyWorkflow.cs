﻿using ErrorOr;
using VibeBisBff.CrossCutting.Enums;

namespace VibeBisBff.Application.Usecases.Participants.ChangeKeyWorkflow;

public interface IStartChangeKeyWorkflow
{
    Task<ErrorOr<string>> Execute(ChangeKeyWorkflowType workflow);
    Task<ErrorOr<string>> ExecuteWithParticipantDocument(string participantDocument, ChangeKeyWorkflowType workflow,
        ApplicationType? appType = null, string tenantConfigId = null);
}
