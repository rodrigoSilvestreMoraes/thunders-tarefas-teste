﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Usecases.Participants.ChangeParticipantsAddress;

public interface IChangeParticipantsAddressUseCase
{
    Task<ErrorOr<Success>> Execute(ParticipantAddressDto newAddress);
}
