﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Dto;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Participants.ChangeParticipantsAddress;

public class ChangeParticipantsAddressUseCase : IChangeParticipantsAddressUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public ChangeParticipantsAddressUseCase(IDigitalAccountExternalService digitalAccountExternalService,
        AuthenticationProvider authenticationProvider)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
    }

    public async Task<ErrorOr<Success>> Execute(ParticipantAddressDto newAddress)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var user = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        if (user.DigitalAccountAddresses.Count == 0)
            return Result.Success;

        var currentDigitalAccountAddress = user.DigitalAccountAddresses[0];

        var newDigitalAccountAddress = new DigitalAccountAddressDto()
        {
            Id = currentDigitalAccountAddress.Id,
            DigitalAccountId = digitalAccountId.Value,
            AddressTypeId = "62c7118af628272722a847b3",
            City = newAddress.City,
            Country = newAddress.Country,
            District = newAddress.District,
            Number = newAddress.Number,
            PostalCode = newAddress.PostalCode,
            Street = newAddress.Street,
            State = newAddress.State,
            Complement = newAddress.Complement
        };

        await _digitalAccountExternalService.UpdateAddress(newDigitalAccountAddress);

        return Result.Success;
    }
}
