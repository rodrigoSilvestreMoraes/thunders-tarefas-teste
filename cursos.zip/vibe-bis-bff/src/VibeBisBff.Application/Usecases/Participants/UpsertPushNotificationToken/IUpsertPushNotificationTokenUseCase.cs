﻿using ErrorOr;
using VibeBisBff.Dto.Participants;

namespace VibeBisBff.Application.Usecases.Participants.UpsertPushNotificationToken;

public interface IUpsertPushNotificationTokenUseCase
{
    Task<ErrorOr<Success>> Execute(UpsertPushNotificationTokenRequestDto requestDto,
        CancellationToken cancellationToken);
}
