﻿using Common.Core.Authentication.Models;
using ErrorOr;
using FluentValidation;
using VibeBisBff.Domain.Entities;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.Dto.Participants;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Participants.UpsertPushNotificationToken;

public class UpsertPushNotificationTokenUseCase : IUpsertPushNotificationTokenUseCase
{
    private readonly IValidator<UpsertPushNotificationTokenRequestDto> _validator;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IUserPushNotificationTokenRepository _userPushNotificationTokenRepository;

    public UpsertPushNotificationTokenUseCase(IValidator<UpsertPushNotificationTokenRequestDto> validator,
        AuthenticatedUser authenticatedUser,
        IUserPushNotificationTokenRepository userPushNotificationTokenRepository)
    {
        _validator = validator;
        _authenticatedUser = authenticatedUser;
        _userPushNotificationTokenRepository = userPushNotificationTokenRepository;
    }

    public async Task<ErrorOr<Success>> Execute(UpsertPushNotificationTokenRequestDto requestDto,
        CancellationToken cancellationToken)
    {
        var validationResult = await _validator.ValidateAsync(requestDto, cancellationToken);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        await _userPushNotificationTokenRepository.DeleteByToken(requestDto.Token, cancellationToken);

        await _userPushNotificationTokenRepository.Upsert(new UserPushNotificationToken(digitalAccountId.Value,
            requestDto.Token), cancellationToken);

        return Result.Success;
    }
}
