﻿namespace VibeBisBff.Application.Usecases.Participants.Delete;

public interface IDeleteParticipantUseCase
{
    Task Execute();
}
