﻿using Common.Core.Authentication.Models;
using Common.Core.Exceptions;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Participants.Delete;

public class DeleteParticipantUseCase : IDeleteParticipantUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public DeleteParticipantUseCase(IDigitalAccountExternalService digitalAccountExternalService, AuthenticatedUser authenticatedUser)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticatedUser;
    }

    public async Task Execute()
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            throw new BusinessException("Erro ao obter as informações do usuário");

        var digitalAccount =
            await _digitalAccountExternalService.GetParticipantDetailsById(_authenticatedUser.GetDigitalAccountId()
                .Value);

        if(digitalAccount is null)
            throw new BusinessException("Usuário não encontrado");

        await _digitalAccountExternalService.DeleteDigitalAccount(digitalAccountId.Value);
    }
}
