﻿using ErrorOr;
using VibeBisBff.Dto.Participants;

namespace VibeBisBff.Application.Usecases.Participants.EmailOtpValidation;

public interface IEmailOtpValidationUseCase
{
    Task<ErrorOr<SendOtpResponseDto>> Execute();
}
