﻿using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Participants.EmailOtpValidation
{
    public class EmailOtpValidationUseCase : IEmailOtpValidationUseCase
    {
        private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
        private readonly AuthenticatedUser _authenticatedUser;
        private readonly IDigitalAccountExternalService _digitalAccountExternalService;

        public EmailOtpValidationUseCase(
            IIdentityAccessManagementExternalService identityAccessManagementExternalService,
            AuthenticatedUser authenticatedUser,
            IDigitalAccountExternalService digitalAccountExternalService)
        {
            _identityAccessManagementExternalService = identityAccessManagementExternalService;
            _authenticatedUser = authenticatedUser;
            _digitalAccountExternalService = digitalAccountExternalService;
        }

        public async Task<ErrorOr<SendOtpResponseDto>> Execute()
        {
            var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

            if (digitalAccountId.IsError) return digitalAccountId.Errors;

            var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

            if (digitalAccount == null)
                return Error.Validation("DA-NOT-FOUND", "Erro ao consultar o usuário. Tente novamente, por favor");

            var email = digitalAccount.GetEmail();

            if (email is null)
                return Error.Validation("DA-NO-EMAIL", "Erro ao consultar o usuário. Tente novamente, por favor");

            if (digitalAccount.HasValidatedEmail())
                return Error.Validation("DA-EMAIL-VALIDATED", "O e-mail já foi validado");

            var otp = await _identityAccessManagementExternalService.SendEmailValidationOtp(email,
                digitalAccountId.Value);

            if (otp.IsTooManyRequest)
                return Error.Failure(description: ErrorConstants.TOO_MANY_CODES_REQUESTS);

            return new SendOtpResponseDto(otp.OtpId);
        }
    }
}
