﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;

namespace VibeBisBff.Application.Usecases.Participants.EmailOtpValidationConfirm;

public class EmailOtpValidationConfirmUseCase : IEmailOtpValidationConfirmUseCase
{
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;

    public EmailOtpValidationConfirmUseCase(
        IIdentityAccessManagementExternalService identityAccessManagementExternalService)
    {
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
    }

    public async Task<ErrorOr<Success>> Execute(EmailOtpCodeDto emailOtpCodeDto)
    {
        if (string.IsNullOrEmpty(emailOtpCodeDto.OtpId) || string.IsNullOrEmpty(emailOtpCodeDto.Code))
            return Error.Validation("O ID do OTP e o código são obrigatórios");

        var validationResult = await _identityAccessManagementExternalService.ValidateOtpCode(otpId: emailOtpCodeDto.OtpId,
            emailOtpCodeDto.Code);

        if (!validationResult.Success)
            return Error.Validation(description: "PIN inválido");

        return Result.Success;
    }
}
