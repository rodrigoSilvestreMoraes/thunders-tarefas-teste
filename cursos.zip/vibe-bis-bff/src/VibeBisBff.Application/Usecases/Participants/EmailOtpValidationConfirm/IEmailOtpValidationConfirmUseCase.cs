﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Usecases.Participants.EmailOtpValidationConfirm;

public interface IEmailOtpValidationConfirmUseCase
{
    Task<ErrorOr<Success>> Execute(EmailOtpCodeDto emailOtpCodeDto);
}
