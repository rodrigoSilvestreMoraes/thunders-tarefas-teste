﻿using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Vertem.WalletVertem;
using VibeBisBff.ExternalServices.Vertem.WalletVertem.Dto;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Participants.GetExtract;

public class GetParticipantExtractUseCase : IGetParticipantExtractUseCase
{
    private readonly IWalletVertemExternalService _walletVertemExternalService;
    private readonly ITenantService _tenantService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IMapper _mapper;

    public GetParticipantExtractUseCase(IWalletVertemExternalService walletVertemExternalService,
        AuthenticatedUser authenticatedUser,
        IMapper mapper,
        ITenantService tenantService)
    {
        _walletVertemExternalService = walletVertemExternalService;
        _authenticatedUser = authenticatedUser;
        _mapper = mapper;
        _tenantService = tenantService;
    }

    public async Task<ErrorOr<ParticipantExtractResponseDto>> Execute(DateTime? start, DateTime? end,
        ParticipantExtractType? type)
    {
        var dateValidation = ValidateStartAndEndDate(start, end);

        if (dateValidation.IsError)
            return dateValidation.Errors;

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var walletConfiguration = await _tenantService.GetWalletConfiguration();

        var participantExtractExternalService = await _walletVertemExternalService
            .GetExtract(digitalAccountId.Value, walletConfiguration.VirtualCoinsAccountingLedgerId, start, end);

        if (participantExtractExternalService.IsError)
            return participantExtractExternalService.Errors;

        var amountSaved = await GetTotalAmountSaved( digitalAccountId.Value,
            walletConfiguration.VirtualCoinsAccountingLedgerId);

        if (amountSaved.IsError)
            return amountSaved.Errors;

        if (participantExtractExternalService.Value.Items == null ||
            !participantExtractExternalService.Value.Items.Any())
            return new ParticipantExtractResponseDto()
            {
                AmountSaved = amountSaved.Value
            };

        var participantExtracts =
            _mapper.Map<List<ParticipantExtractItemExternalServiceResponseDto>, List<ParticipantExtractResponseDto>>
                (participantExtractExternalService.Value.Items);

        var participantExtract = participantExtracts.FirstOrDefault();

        var operations = type.HasValue
            ? participantExtract?.Operations?.Where(o => o.Type == type.Value)
            : participantExtract?.Operations;

        operations = operations?.OrderByDescending(x => x.Date);

        participantExtract!.Operations = ReplaceEncodedDescriptions(operations);

        participantExtract.AmountSaved = amountSaved.Value;

        return participantExtract;
    }

    private async Task<ErrorOr<decimal>> GetTotalAmountSaved(
        string digitalAccountId, string virtualCoinsAccountingLedgerId)
    {
        var totals =
            await _walletVertemExternalService.GetExtractConsolidated(digitalAccountId, virtualCoinsAccountingLedgerId);

        if (totals.IsError)
            return Error.Failure("AMOUNT-SAVED-CONSULT-ERROR", ErrorConstants.GENERIC_ERROR);

        return totals.Value.RedeemBalance;
    }

    private static List<ParticipantExtractOperationDto> ReplaceEncodedDescriptions(
        IEnumerable<ParticipantExtractOperationDto> operations)
    {
        var operationAsList = operations?.ToList();

        if (operationAsList is null || !operationAsList.Any())
            return null;

        foreach (var operation in operationAsList)
        {
            operation.Description = operation.Type switch
            {
                ParticipantExtractType.Deposit => "Crédito",
                ParticipantExtractType.Cancellation => "Cancelamento",
                ParticipantExtractType.Reversal => "Estorno",
                ParticipantExtractType.Expiration => "Expiração",
                _ => operation.Description
            };

            if (operation.Type == ParticipantExtractType.Expiration)
                operation.Type = ParticipantExtractType.Redemption;
        }

        return operationAsList;
    }

    private static ErrorOr<List<ParticipantExtractResponseDto>> ValidateStartAndEndDate(DateTime? start, DateTime? end)
    {
        if (!start.HasValue && !end.HasValue) return new ErrorOr<List<ParticipantExtractResponseDto>>();

        if (start.HasValue && start.Value > DateTime.Now)
            return Error.Validation(description: "A data de início não deve ser maior que a data de hoje");

        if (end.HasValue && end.Value > DateTime.Now)
            return Error.Validation(description: "A data de término não deve ser maior que a data de hoje");

        if (!start.HasValue || !end.HasValue) return new ErrorOr<List<ParticipantExtractResponseDto>>();

        if (start > end)
            return Error.Validation(description: "A data de início não deve ser maior que a data de término");

        return end.Value.Date.Subtract(start.Value.Date).TotalDays > 90
            ? Error.Validation(
                description: "O intervalo entre a data de ínício e de término não deve ser maior que 90 dias")
            : new ErrorOr<List<ParticipantExtractResponseDto>>();
    }
}
