﻿using ErrorOr;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Participants;

namespace VibeBisBff.Application.Usecases.Participants.GetExtract
{
    public interface IGetParticipantExtractUseCase
    {
        Task<ErrorOr<ParticipantExtractResponseDto>> Execute(DateTime? start, DateTime? end, ParticipantExtractType? type);    
    }
}
