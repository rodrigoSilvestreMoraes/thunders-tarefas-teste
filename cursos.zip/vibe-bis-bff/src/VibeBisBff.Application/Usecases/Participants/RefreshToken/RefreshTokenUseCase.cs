﻿using ErrorOr;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Vertem.IamClientCredentials;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;

namespace VibeBisBff.Application.Usecases.Participants.RefreshToken;

public class RefreshTokenUseCase : IRefreshTokenUseCase
{
    private readonly ITenantService _tenantService;
    private readonly IVertemIamTenantService _vertemIamTenantService;

    public RefreshTokenUseCase(ITenantService tenantService, IVertemIamTenantService vertemIamTenantService)
    {
        _tenantService = tenantService;
        _vertemIamTenantService = vertemIamTenantService;
    }

    public async Task<ErrorOr<AccessTokenResponseDto>> Execute(RefreshTokenRequestDto refreshTokenRequestDto)
    {
        var credential = await _tenantService.GetUserClientConfig(refreshTokenRequestDto.AppType,
            refreshTokenRequestDto.TenantConfigId);

        return await _vertemIamTenantService.RefreshToken(refreshTokenRequestDto.RefreshToken, credential);
    }
}
