﻿using AutoMapper;
using ErrorOr;
using Common.Core.Authentication.Models;
using VibeBisBff.CrossCuting.Dto.Participants.Response;
using VibeBisBff.Domain.Repositories.MongoDb.FavoriteVendor;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using Common.Core.Exceptions;
using FluentValidation;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.Application.Usecases.Banners.GetShowcaseByListExternalId;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCuting.Dto.Engagement;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Domain.Repositories.MongoDb.Banners;

namespace VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.ListFavoriteVendorCategories;

public class ListFavoriteVendorCategoriesUseCase : IListFavoriteVendorCategoriesUseCase
{
    private readonly IFavoriteVendorCategoriesRepository _favoriteVendorCategoriesRepository;
    private readonly ITradebackPromoExternalService _promoExternalService;
    private readonly IBannerShowcaseRepository _bannerShowcaseRepository;
    private readonly IMapper _mapper;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IValidator<PagingDataDto> _pagingDataValidator;

    public ListFavoriteVendorCategoriesUseCase(
        IFavoriteVendorCategoriesRepository favoriteVendorCategoriesRepository,
        ITradebackPromoExternalService tradebackPromoExternalService,
        AuthenticatedUser authenticatedUser,
        IBannerShowcaseRepository bannerShowcaseRepository,
        IMapper mapper, IValidator<PagingDataDto> pagingDataValidator)
    {
        _favoriteVendorCategoriesRepository = favoriteVendorCategoriesRepository;
        _promoExternalService = tradebackPromoExternalService;
        _authenticatedUser = authenticatedUser;
        _bannerShowcaseRepository = bannerShowcaseRepository;
        _mapper = mapper;
        _pagingDataValidator = pagingDataValidator;
    }

    //TODO: Tratar segmentação de participante na consulta dos banners
    public async Task<ErrorOr<PagingDataResponseDto<FavoriteCategoryDto>>> Execute(PagingDataDto pagingData,
        CancellationToken cancellationToken)
    {
        var paginationValidationResult = await _pagingDataValidator.ValidateAsync(pagingData, cancellationToken);

        if (!paginationValidationResult.IsValid)
            return paginationValidationResult.Errors.ToValidation();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return Error.Failure("NO-DIGITAL-ACCOUNT-ID", ErrorConstants.GENERIC_ERROR);

        var tenantConfigId = _authenticatedUser.GetTenantConfig();

        if (tenantConfigId.IsError)
            return Error.Failure("NO-TENANT-CONFIG-ID", ErrorConstants.GENERIC_ERROR);

        var participantCategories =
            await _favoriteVendorCategoriesRepository.ListCategoriesByParticipant(digitalAccountId.Value,
                tenantConfigId.Value);

        if (participantCategories == null || !participantCategories.Categories.Any())
            return GetDefaultResponse();

        var allCategories = await _promoExternalService.GetChainCategories(cancellationToken);

        if (allCategories.IsError) return GetDefaultResponse();

        var categories = allCategories.Value.Where(x => participantCategories.Categories.Contains(x.Id)).ToList();

        if (!categories.Any())
            return GetDefaultResponse();

        var totalOfCategories = categories.Count;

        categories = PaginateCategories(categories, pagingData);

        if (!categories.Any())
            return new PagingDataResponseDto<FavoriteCategoryDto>()
            {
                TotalItems = totalOfCategories,
                Items = new List<FavoriteCategoryDto>()
            };

        var bannersForCategoriesDictionary =
            await GetBannerShowcasesForCategories(categories.Select(x => x.Id).ToList(), tenantConfigId.Value,
                cancellationToken);

        var mappedResponse = categories.Select(x =>
        {
            bannersForCategoriesDictionary.TryGetValue(x.Id, out var banners);

            return new FavoriteCategoryDto
            {
                Id = x.Id,
                Name = x.Name,
                Banners = banners ?? new List<BannerItemDto>()
            };
        }).ToList();

        return new PagingDataResponseDto<FavoriteCategoryDto>()
        {
            TotalItems = totalOfCategories,
            Items = mappedResponse
        };
    }

    private async Task<Dictionary<string, List<BannerItemDto>>> GetBannerShowcasesForCategories(
        List<string> categoriesAsExternalIds, string tenantConfigId, CancellationToken cancellationToken)
    {
        var showcases =
            await _bannerShowcaseRepository.GetActiveByExternalIdentifiers(categoriesAsExternalIds, tenantConfigId,
                cancellationToken);

        return showcases.ToDictionary(x => x.ExternalId,
            showCase => showCase.Items.Select(bannerItem => _mapper.Map<BannerItemDto>(bannerItem)).ToList());
    }

    private static List<CategoryDto> PaginateCategories(List<CategoryDto> categories, PagingDataDto pagingData)
    {
        return categories.Skip(pagingData.PageSize!.Value * (pagingData.PageNumber!.Value - 1))
            .Take(pagingData.PageSize!.Value).ToList();
    }

    private static PagingDataResponseDto<FavoriteCategoryDto> GetDefaultResponse() =>
        new()
        {
            TotalItems = 0,
            Items = new List<FavoriteCategoryDto>()
        };
}
