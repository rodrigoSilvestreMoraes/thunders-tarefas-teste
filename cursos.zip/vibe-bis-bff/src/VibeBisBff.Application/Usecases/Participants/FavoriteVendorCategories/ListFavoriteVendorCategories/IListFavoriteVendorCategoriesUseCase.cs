﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto;
using VibeBisBff.CrossCuting.Dto.Participants.Response;

namespace VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.ListFavoriteVendorCategories;

public interface IListFavoriteVendorCategoriesUseCase
{
    Task<ErrorOr<PagingDataResponseDto<FavoriteCategoryDto>>> Execute(PagingDataDto pagingData,
        CancellationToken cancellationToken);
}
