﻿using Common.Core.Authentication.Models;
using ErrorOr;
using FluentValidation;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.Domain.Entities.FavoriteVendor;
using VibeBisBff.Domain.Repositories.MongoDb.FavoriteVendor;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.AddFavoriteVendorCategories;

public class AddFavoriteVendorCategoriesUseCase : IAddFavoriteVendorCategoriesUseCase
{
    private readonly IFavoriteVendorCategoriesRepository _favoriteVendorCategoriesRepository;
    private readonly IValidator<AddFavoriteVendorCategoryRequestDto> _validator;
    private readonly ITradebackPromoExternalService _promoExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public AddFavoriteVendorCategoriesUseCase(
        IFavoriteVendorCategoriesRepository favoriteVendorCategoriesRepository,
        AuthenticatedUser authenticatedUser, IValidator<AddFavoriteVendorCategoryRequestDto> validator,
        ITradebackPromoExternalService promoExternalService)
    {
        _favoriteVendorCategoriesRepository = favoriteVendorCategoriesRepository;
        _authenticatedUser = authenticatedUser;
        _validator = validator;
        _promoExternalService = promoExternalService;
    }

    public async Task<ErrorOr<bool>> Execute(AddFavoriteVendorCategoryRequestDto request,
        CancellationToken cancellationToken)
    {
        var validationResult = await _validator.ValidateAsync(request, cancellationToken);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return Error.Failure("NO-DIGITAL-ACCOUNT-ID", ErrorConstants.GENERIC_ERROR);

        var tenantConfigId = _authenticatedUser.GetTenantConfig();

        if (tenantConfigId.IsError)
            return Error.Failure("NO-TENANT-CONFIG", ErrorConstants.GENERIC_ERROR);

        var validCategoriesIds = (await _promoExternalService.GetChainCategories(cancellationToken)).Value.Select(x => x.Id);

        var notValidCategoriesIds = request.CategoryIds.Except(validCategoriesIds).ToArray();

        if(notValidCategoriesIds.Any())
            return Error.Validation("INVALID-CATEGORY-ID", $"Os seguintes ids de categoria de parceiro não são válidos: {string.Join(", ", notValidCategoriesIds)}");

        var entity = new ParticipantFavoriteVendorCategories
            { DigitalAccountId = digitalAccountId.Value, Categories = request.CategoryIds, TenantConfigId = tenantConfigId.Value };

        var result = await _favoriteVendorCategoriesRepository.SaveMany(entity, cancellationToken);

        if(!result)
            return Error.Failure("SAVE-BD-ERROR", ErrorConstants.GENERIC_ERROR);

        return true;
    }
}
