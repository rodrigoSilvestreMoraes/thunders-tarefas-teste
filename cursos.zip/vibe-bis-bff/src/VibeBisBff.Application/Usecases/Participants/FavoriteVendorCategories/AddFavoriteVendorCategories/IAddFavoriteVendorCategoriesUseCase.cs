﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.AddFavoriteVendorCategories;

public interface IAddFavoriteVendorCategoriesUseCase
{
    Task<ErrorOr<bool>> Execute(AddFavoriteVendorCategoryRequestDto request, CancellationToken cancellationToken);
}
