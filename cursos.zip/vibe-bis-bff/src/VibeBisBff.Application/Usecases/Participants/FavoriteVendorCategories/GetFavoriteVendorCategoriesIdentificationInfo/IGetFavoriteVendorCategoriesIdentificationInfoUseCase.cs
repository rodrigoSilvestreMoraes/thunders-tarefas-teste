﻿using ErrorOr;

namespace VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.GetFavoriteVendorCategoriesIdentificationInfo;

public interface IGetFavoriteVendorCategoriesIdentificationInfoUseCase
{
    Task<ErrorOr<HashSet<string>>> Execute(CancellationToken cancellationToken);
}
