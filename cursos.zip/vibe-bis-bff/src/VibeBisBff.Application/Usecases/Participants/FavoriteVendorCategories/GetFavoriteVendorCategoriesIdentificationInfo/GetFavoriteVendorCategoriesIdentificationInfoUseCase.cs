﻿using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.Domain.Entities.FavoriteVendor;
using VibeBisBff.Domain.Repositories.MongoDb.FavoriteVendor;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Participants.FavoriteVendorCategories.GetFavoriteVendorCategoriesIdentificationInfo;

public class GetFavoriteVendorCategoriesIdentificationInfoUseCase : IGetFavoriteVendorCategoriesIdentificationInfoUseCase
{
    private readonly IFavoriteVendorCategoriesRepository _favoriteVendorCategoriesRepository;
    private readonly AuthenticatedUser _authenticatedUser;

    public GetFavoriteVendorCategoriesIdentificationInfoUseCase(IFavoriteVendorCategoriesRepository favoriteVendorCategoriesRepository,
        AuthenticatedUser authenticatedUser)
    {
        _favoriteVendorCategoriesRepository = favoriteVendorCategoriesRepository;
        _authenticatedUser = authenticatedUser;
    }

    public async Task<ErrorOr<HashSet<string>>> Execute(CancellationToken cancellationToken)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var tenantConfigId = _authenticatedUser.GetTenantConfig();

        if (tenantConfigId.IsError)
            return tenantConfigId.Errors;

        var favoriteVendorCategoriesId =
            ParticipantFavoriteVendorCategories.BuildId(digitalAccountId.Value, tenantConfigId.Value);

        var categoriesIds =
            await _favoriteVendorCategoriesRepository.GetFavoriteCategoriesIds(favoriteVendorCategoriesId,
                cancellationToken);

        return categoriesIds ?? new HashSet<string>();
    }
}
