﻿using VibeBisBff.Dto.Participants;
using ErrorOr;

namespace VibeBisBff.Application.Usecases.Participants.ValidateRegisterKey;

public interface IValidateRegisterKeyUseCase
{
    Task<ErrorOr<bool>> Execute(ValidateKeyRequestDto validateKeyRequestDto);
}
