﻿using FluentValidation;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Participants;
using ErrorOr;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;

namespace VibeBisBff.Application.Usecases.Participants.ValidateRegisterKey;

//TODO: Implementar estrutura para personar token cross-tenant de acordo com o tenant da aplicação
public class ValidateRegisterKeyUseCase : IValidateRegisterKeyUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IValidator<ValidateKeyRequestDto> _validateKeyRequestValidator;

    public ValidateRegisterKeyUseCase(
        IDigitalAccountExternalService digitalAccountExternalService,
        IValidator<ValidateKeyRequestDto> validateKeyRequestValidator)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _validateKeyRequestValidator = validateKeyRequestValidator;
    }

    public async Task<ErrorOr<bool>> Execute(ValidateKeyRequestDto validateKeyRequestDto)
    {
        var validationResult = await _validateKeyRequestValidator.ValidateAsync(validateKeyRequestDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var digitalAccount = validateKeyRequestDto.KeyType switch
        {
            KeyType.Cellphone => await _digitalAccountExternalService.GetDigitalAccountByPhone(validateKeyRequestDto
                .Value),
            KeyType.Document => await _digitalAccountExternalService.GetDigitalAccountByDocument(validateKeyRequestDto
                .Value),
            KeyType.Email =>
                await _digitalAccountExternalService.GetDigitalAccountByEmail(validateKeyRequestDto.Value),
            _ => throw new ArgumentException("Tipo de identificador inválido")
        };

        return digitalAccount is null || !digitalAccount.HasRegistrationByVibe();
    }
}
