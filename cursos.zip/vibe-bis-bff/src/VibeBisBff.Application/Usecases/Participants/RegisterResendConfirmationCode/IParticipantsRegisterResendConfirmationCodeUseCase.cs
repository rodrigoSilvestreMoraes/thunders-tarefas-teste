﻿using VibeBisBff.Dto.Participants;
using ErrorOr;

namespace VibeBisBff.Application.Usecases.Participants.RegisterResendConfirmationCode;

public interface IParticipantsRegisterResendConfirmationCodeUseCase
{
    Task<ErrorOr<SendOtpResponseDto>> Execute(string digitalAccountId, ResendRegisterOtpRequestDto requestDto);
}
