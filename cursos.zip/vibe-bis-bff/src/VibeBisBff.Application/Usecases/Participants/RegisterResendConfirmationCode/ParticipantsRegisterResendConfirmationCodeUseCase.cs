﻿using Common.Core.Exceptions;
using ErrorOr;
using FluentValidation;

using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;

namespace VibeBisBff.Application.Usecases.Participants.RegisterResendConfirmationCode;

public class ParticipantsRegisterResendConfirmationCodeUseCase : IParticipantsRegisterResendConfirmationCodeUseCase
{
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IValidator<ResendRegisterOtpRequestDto> _resendRegisterOtpRequestValidator;

    public ParticipantsRegisterResendConfirmationCodeUseCase(
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        IDigitalAccountExternalService digitalAccountExternalService,
        IValidator<ResendRegisterOtpRequestDto> resendRegisterOtpRequestValidator)
    {
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _resendRegisterOtpRequestValidator = resendRegisterOtpRequestValidator;
    }

    public async Task<ErrorOr<SendOtpResponseDto>> Execute(string digitalAccountId,
        ResendRegisterOtpRequestDto requestDto)
    {
        var validationResult = await _resendRegisterOtpRequestValidator.ValidateAsync(requestDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId, requestDto.AppType, requestDto.TenantConfigId);

        if (digitalAccount is null)
            return Error.Validation(description: "Usuário não encontrado");

        VerifyIfItsAlreadyValidated(digitalAccount, requestDto.VerificationType!.Value);

        var otpId = requestDto.VerificationType == ParticipantVerificationType.Email
            ? await _identityAccessManagementExternalService
                .SendEmailValidationOtp(
                    digitalAccount.DigitalAccountEmails[0].Email,
                    digitalAccountId,
                    requestDto.AppType,
                    requestDto.TenantConfigId)
            : await _identityAccessManagementExternalService
                .SendWhatsappOtp(
                    digitalAccount.GetCellphone(),
                    digitalAccountId,
                    appType: requestDto.AppType,
                    tenantConfigId: requestDto.TenantConfigId);

        if (otpId.IsTooManyRequest)
            return Error.Failure(description: ErrorConstants.TOO_MANY_CODES_REQUESTS);

        return new SendOtpResponseDto(otpId.OtpId);
    }

    private static void VerifyIfItsAlreadyValidated(DigitalAccountParticipantDetail digitalAccount, ParticipantVerificationType verificationType)
    {
        if (digitalAccount.HasValidatedEmail() && verificationType == ParticipantVerificationType.Email)
            throw new BusinessException("Email já validado");

        if(digitalAccount.HasValidatedPhone() && verificationType == ParticipantVerificationType.Cellphone)
            throw new BusinessException("Telefone já validado");
    }
}
