﻿#nullable enable
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.MessageWorker;
using VibeBisBff.ExternalServices.ServiceNow;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;

namespace VibeBisBff.Application.Usecases.Participants.CreateUserServiceNow;

public class GenerateServiceNowUserUseCase : IGenerateServiceNowUserUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IServiceNowExternalService _serviceNowExternalService;

    public GenerateServiceNowUserUseCase(IDigitalAccountExternalService digitalAccountExternalService,
        IServiceNowExternalService serviceNowExternalService)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _serviceNowExternalService = serviceNowExternalService;
    }

    public async Task Execute(ServiceNowUserCreateMessageDto serviceNowUserCreateMessage)
    {
        var participantDetails = await _digitalAccountExternalService
            .GetParticipantDetailsById(serviceNowUserCreateMessage.DigitalAccountId, serviceNowUserCreateMessage.AppType,
                serviceNowUserCreateMessage.TenantConfigId);

        if (!participantDetails.HasServiceNowId())
            await CreateServiceNowUserAndLinkToDigitalAccount(participantDetails, serviceNowUserCreateMessage.AppType,
                serviceNowUserCreateMessage.TenantConfigId);
    }

    private async Task CreateServiceNowUserAndLinkToDigitalAccount(DigitalAccountParticipantDetail participantDetails,
        ApplicationType appType, string? tenantConfigId = null)
    {
        var serviceNowUserResult = await _serviceNowExternalService.CreateServiceNowUser(participantDetails);

        participantDetails.AddServiceNowId(serviceNowUserResult.Result.sys_id);

        await _digitalAccountExternalService.Update(participantDetails, appType, tenantConfigId);
    }
}
