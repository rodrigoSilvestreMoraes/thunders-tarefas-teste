﻿using VibeBisBff.Dto.MessageWorker;

namespace VibeBisBff.Application.Usecases.Participants.CreateUserServiceNow;

public interface IGenerateServiceNowUserUseCase
{
    public Task Execute(ServiceNowUserCreateMessageDto serviceNowUserCreateMessage);
}
