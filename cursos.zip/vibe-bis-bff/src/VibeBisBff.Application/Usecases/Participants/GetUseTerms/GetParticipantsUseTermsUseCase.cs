﻿#nullable enable
using Microsoft.Extensions.Options;

using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Vertem.Terms;

using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Repositories.MongoDb.Raffle;
using VibeBisBff.Dto.Participants;
using VibeBisBff.Infra.Files;

namespace VibeBisBff.Application.UseCases.Participants.GetUseTerms;

public class GetParticipantsUseTermsUseCase : IGetParticipantsUseTermsUseCase
{
    private readonly ITermsExternalService _termsExternalService;
    private readonly ExternalFileDownloader _externalFileDownloader;
    private readonly IRaffleRepository _raffleRepository;
    private readonly ITenantService _tenantService;

    public GetParticipantsUseTermsUseCase(ITermsExternalService termsExternalService,
        ExternalFileDownloader externalFileDownloader,
        IRaffleRepository raffleRepository,
        ITenantService tenantService)
    {
        _termsExternalService = termsExternalService;
        _externalFileDownloader = externalFileDownloader;
        _raffleRepository = raffleRepository;
        _tenantService = tenantService;
    }

    public async Task<GetParticipantUseTermsDto> Execute(ApplicationType appType, string? tenantConfigId = null)
    {
        var result = new GetParticipantUseTermsDto();

        var useTermsTermId = await _tenantService.GetUseTermsTermId(appType, tenantConfigId);
        var privacyPoliceTermId = await _tenantService.GetPrivacyPoliceTermId(appType, tenantConfigId);

        await Task.WhenAll(

            Task.Run(async () =>
            {
                (result.UseTermsContent, result.UseTermsUpdateDate) =
                    await GetTermContentAndUpdateDate(useTermsTermId, appType, tenantConfigId);
            }),

            Task.Run(async () =>
            {
                (result.PrivacyPolicyContent, result.PrivacyPolicyUpdateDate) =
                    await GetTermContentAndUpdateDate(privacyPoliceTermId, appType, tenantConfigId);
            }),

            appType != ApplicationType.VibeEmpresas ? Task.Run(async () =>
            {
                var activeRaffleGroup = await _raffleRepository.GetActive();

                (result.ActiveRaffleTermContent, result.ActiveRaffleTermUpdateDate) = await
                    GetTermContentAndUpdateDate(activeRaffleGroup.FullRegulationTermAsTxtId, appType, tenantConfigId);
            }) : Task.CompletedTask
        );

        return result;
    }

    private async Task<(string termContent, DateTime updatedDate)> GetTermContentAndUpdateDate(string termId, ApplicationType appType, string? tenantConfigId = null)
    {
        var term = await _termsExternalService
            .GetTermById(termId, appType, tenantConfigId);

        var (contentUrl, updateDate) = term.Data.GetFileUrlAndCreatedDateForLastVersion();

        return (await _externalFileDownloader.GetRemoteTextFileAndReadContent(
            contentUrl), updateDate);
    }
}
