﻿#nullable enable
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Participants;

namespace VibeBisBff.Application.UseCases.Participants.GetUseTerms;

public interface IGetParticipantsUseTermsUseCase
{
    Task<GetParticipantUseTermsDto> Execute(ApplicationType appType, string? tenantConfigId = null);
}
