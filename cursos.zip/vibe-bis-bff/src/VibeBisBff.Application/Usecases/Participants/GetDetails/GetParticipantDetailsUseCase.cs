﻿using AutoMapper;
using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;
using VibeBisBff.ExternalServices.Vertem.WalletVertem;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.UseCases.Participants.GetDetails;

public class GetParticipantDetailsUseCase : IGetParticipantDetailsUseCase
{
    private readonly IWalletVertemExternalService _walletVertemExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IMapper _mapper;
    private readonly ITenantService _tenantService;

    public GetParticipantDetailsUseCase(IWalletVertemExternalService walletVertemExternalService,
        IDigitalAccountExternalService digitalAccountExternalService,
        IMapper mapper,
        AuthenticatedUser authenticatedUser,
        ITenantService tenantService)
    {
        _walletVertemExternalService = walletVertemExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _mapper = mapper;
        _authenticatedUser = authenticatedUser;
        _tenantService = tenantService;
    }

    public async Task<ErrorOr<ParticipantDetailDto>> Execute()
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        return await Execute(digitalAccountId.Value);
    }

    public async Task<ErrorOr<ParticipantDetailDto>> Execute(string digitalAccountId)
    {
        var participantDetailsFromDigitalAccount =
            await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId);

        var walletConfiguration = await _tenantService.GetWalletConfiguration();

        var balanceForVirtualCoins = await _walletVertemExternalService.GetBalance(digitalAccountId,
            walletConfiguration.VirtualCoinsAccountingLedgerId);

        var result = _mapper.Map<DigitalAccountParticipantDetail, ParticipantDetailDto>(
            participantDetailsFromDigitalAccount,
            opt => opt.Items.Add("accountDetails", new ParticipantAccountDto
            {
                Balance = balanceForVirtualCoins,
                AvailableBenefitsQuantity = 0,
                TotalSavingsInMonetaryValue = 0
            }));

        result.ShortName = GetOnlyTwoFirstNames(result.Name);

        GetCompanyAdditionalAttributes(participantDetailsFromDigitalAccount, result);

        AppendValidatedFields(result, participantDetailsFromDigitalAccount);

        return result;
    }

    private static string GetOnlyTwoFirstNames(string participantName) =>
        participantName.Split(' ')[0];

    private static void GetCompanyAdditionalAttributes(
        DigitalAccountParticipantDetail participantDetailsFromDigitalAccount, ParticipantDetailDto result)
    {
        if (!participantDetailsFromDigitalAccount.HasCustomAttribute(nameof(DigitalAccountParticipantDetail.Name)))
            return;

        result.Owner = new CompanyOwnerDto
        {
            Name =
                participantDetailsFromDigitalAccount.GetCustomAttribute(nameof(DigitalAccountParticipantDetail.Name)),
            Document = participantDetailsFromDigitalAccount.GetCustomAttribute(nameof(DigitalAccountParticipantDetail
                .UserDocument))
        };

        result.BusinessArea = participantDetailsFromDigitalAccount.GetCustomAttribute("BusinessArea");
    }

    private static void AppendValidatedFields(ParticipantDetailDto participantDetailDto,
        DigitalAccountParticipantDetail digitalAccountParticipantDetail)
    {
        var hasValidatedPhoneNumber = digitalAccountParticipantDetail.HasValidatedPhone();

        var hasValidatedEmail = digitalAccountParticipantDetail.HasValidatedEmail();

        participantDetailDto.EmailValidated = hasValidatedEmail;
        participantDetailDto.PhoneValidated = hasValidatedPhoneNumber;
    }
}
