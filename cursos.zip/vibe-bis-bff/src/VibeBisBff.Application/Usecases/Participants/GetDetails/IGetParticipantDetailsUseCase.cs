﻿using VibeBisBff.Dto.Participants;
using ErrorOr;

namespace VibeBisBff.Application.UseCases.Participants.GetDetails;

public interface IGetParticipantDetailsUseCase
{
    Task<ErrorOr<ParticipantDetailDto>> Execute();
    Task<ErrorOr<ParticipantDetailDto>> Execute(string digitalAccountId);
}
