﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.Dto.Participants;

namespace VibeBisBff.Application.Usecases.Participants.Register;

public interface IParticipantsRegisterUseCase
{
    Task<ErrorOr<ParticipantRegisterResponseDto>> Execute(
        ParticipantsRegisterRequestDto participantsRegisterRequestDto,
        ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto);

    Task<ErrorOr<ParticipantRegisterResponseDto>> ExecuteV2(
        ParticipantsRegisterRequestDto participantsRegisterRequestDto,
        ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto);
}
