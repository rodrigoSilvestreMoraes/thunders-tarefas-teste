﻿using System.Text.Json;
using AutoMapper;
using Azure;
using Common.Core.Exceptions;
using ErrorOr;
using FluentValidation;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Mappers.Participant;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.MessageWorker;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;
using VibeBisBff.ExternalServices.Vertem.Terms;
using VibeBisBff.ExternalServices.Vertem.Terms.Dto;
using VibeBisBff.Infra.Cache;
using VibeBisBff.Infra.ServiceBus;

namespace VibeBisBff.Application.Usecases.Participants.Register;

public class ParticipantsRegisterUseCase : IParticipantsRegisterUseCase
{
    private readonly IValidator<ParticipantsRegisterRequestDto> _participantsRegisterRequestValidator;

    private readonly IValidator<ParticipantsRegisterRequestHeaderDto> _participantsRegisterRequestHeaderValidator;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly ITermsExternalService _termsExternalService;
    private readonly IMapper _mapper;
    private readonly VertemLogsLogger _logger;
    private readonly IServiceBus _serviceBus;
    private readonly ITenantService _tenantService;
    private readonly IRedisService _redisService;

    private const long HOURS_IN_SECONDS = 1200;

    public ParticipantsRegisterUseCase(IValidator<ParticipantsRegisterRequestDto> participantsRegisterRequestValidator,
        IValidator<ParticipantsRegisterRequestHeaderDto> participantsRegisterRequestHeaderValidator,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        IMapper mapper,
        IDigitalAccountExternalService digitalAccountExternalService,
        ITermsExternalService termsExternalService,
        VertemLogsLogger logger,
        IServiceBus serviceBus,
        ITenantService tenantService,
        IRedisService redisService)
    {
        _participantsRegisterRequestValidator = participantsRegisterRequestValidator;
        _participantsRegisterRequestHeaderValidator = participantsRegisterRequestHeaderValidator;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _mapper = mapper;
        _digitalAccountExternalService = digitalAccountExternalService;
        _termsExternalService = termsExternalService;
        _logger = logger;
        _serviceBus = serviceBus;
        _tenantService = tenantService;
        _redisService = redisService;
    }

    public async Task<ErrorOr<ParticipantRegisterResponseDto>> Execute(
        ParticipantsRegisterRequestDto participantsRegisterRequestDto,
        ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto)
    {
        var errorsOnInput =
            await HasValidationErrorsOnInputs(participantsRegisterRequestDto, participantsRegisterRequestHeaderDto);

        if (errorsOnInput.IsError)
            return errorsOnInput.Errors;

        var digitalAccountForPreRegisteredUser =
            await GetDigitalAccountForPreRegisteredUser(participantsRegisterRequestDto);

        var digitalAccountId = await LinkUserToIam(participantsRegisterRequestDto,
            digitalAccountForPreRegisteredUser);

        try
        {
            await AddComplementaryUserInformation(participantsRegisterRequestDto, digitalAccountId,
                digitalAccountForPreRegisteredUser);

            var lastVersionOfUser = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId,
                participantsRegisterRequestDto.AppType,
                participantsRegisterRequestDto.TenantConfigId);

            lastVersionOfUser.AddRegistrationByVibeAttribute();

            AddCompanyRegistrationAttribute(lastVersionOfUser, participantsRegisterRequestDto);

            if (digitalAccountForPreRegisteredUser is not null)
                AddAdditionalInfoWhenHasPreRegister(lastVersionOfUser, participantsRegisterRequestDto);

            await _digitalAccountExternalService.Update(lastVersionOfUser, participantsRegisterRequestDto.AppType,
                participantsRegisterRequestDto.TenantConfigId);

            var otpIdForCellphoneDispatchTask =
                Task.Run(async () =>
                    await SendValidationConfirmationCodeForCellPhone(digitalAccountId, participantsRegisterRequestDto));

            await Task.WhenAll(
                Task.Run(async () => await AcceptTermsForApp(participantsRegisterRequestHeaderDto, digitalAccountId,
                    participantsRegisterRequestDto.AppType, participantsRegisterRequestDto.TenantConfigId)),
                Task.Run(async () =>
                    await DispatchUserCreationOnServiceNow(digitalAccountId, participantsRegisterRequestDto.AppType,
                        participantsRegisterRequestDto.TenantConfigId)),
                otpIdForCellphoneDispatchTask);

            return new ParticipantRegisterResponseDto
            {
                DigitalAccountId = digitalAccountId,
                CellphonePinId = otpIdForCellphoneDispatchTask.Result,
                EmailPinId = "0"
            };
        }
        catch (Exception e)
        {
            _logger.LogError(new ExceptionLog(e));

            if (digitalAccountForPreRegisteredUser is null)
                await _digitalAccountExternalService.DeleteDigitalAccount(digitalAccountId,
                    participantsRegisterRequestDto.AppType, participantsRegisterRequestDto.TenantConfigId);

            return Error.Unexpected(e is not BusinessException
                ? "Erro ao criar o usuário. Tente novamente, por favor"
                : e.Message);
        }
    }

    public async Task<ErrorOr<ParticipantRegisterResponseDto>> ExecuteV2(
        ParticipantsRegisterRequestDto participantsRegisterRequestDto,
        ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto)
    {
        participantsRegisterRequestDto.IsV2Register = true;

        var errorsOnInput =
            await HasValidationErrorsOnInputs(participantsRegisterRequestDto, participantsRegisterRequestHeaderDto);

        if (errorsOnInput.IsError)
            return errorsOnInput.Errors;

        var digitalAccountForPreRegisteredUser =
            await GetDigitalAccountForPreRegisteredUser(participantsRegisterRequestDto);

        var digitalAccountIdForDeleteError = string.Empty;

        try
        {
            var lastVersionOfUser =
                digitalAccountForPreRegisteredUser ?? await CreateFullUserOnDigitalAccount(participantsRegisterRequestDto);

            lastVersionOfUser.AddRegistrationByVibeAttribute();

            digitalAccountIdForDeleteError = lastVersionOfUser.Id;

            AddCompanyRegistrationAttribute(lastVersionOfUser, participantsRegisterRequestDto);

            AddAdditionalInfoWhenHasPreRegister(lastVersionOfUser, participantsRegisterRequestDto);

            await _digitalAccountExternalService.Update(lastVersionOfUser, participantsRegisterRequestDto.AppType,
                participantsRegisterRequestDto.TenantConfigId);

            var otpIdForCellphoneDispatchTask =
                Task.Run(async () =>
                    await SendValidationConfirmationCodeForCellPhone(lastVersionOfUser.Id,
                        participantsRegisterRequestDto));

            await Task.WhenAll(
                Task.Run(async () => await AcceptTermsForApp(
                    participantsRegisterRequestHeaderDto,
                    lastVersionOfUser.Id,
                    participantsRegisterRequestDto.AppType, participantsRegisterRequestDto.TenantConfigId)),
                Task.Run(async () =>
                    await DispatchUserCreationOnServiceNow(
                        lastVersionOfUser.Id,
                        participantsRegisterRequestDto.AppType,
                        participantsRegisterRequestDto.TenantConfigId)),
                otpIdForCellphoneDispatchTask);

            await _redisService.Set(
                $"{Constants.GenerateOtp.REDIS_KEY_ONBOARDING_OTP_FLOW}_{otpIdForCellphoneDispatchTask.Result}",
                new VibeBisBff.Dto.Participants.SendOtpResponseDto(otpIdForCellphoneDispatchTask.Result),
                HOURS_IN_SECONDS);

            return new ParticipantRegisterResponseDto
            {
                DigitalAccountId = lastVersionOfUser.Id,
                CellphonePinId = otpIdForCellphoneDispatchTask.Result,
                EmailPinId = "0"
            };
        }
        catch (Exception e)
        {
            _logger.LogError(new ExceptionLog(e));

            if (digitalAccountForPreRegisteredUser is null)
                await _digitalAccountExternalService.DeleteDigitalAccount(digitalAccountIdForDeleteError,
                    participantsRegisterRequestDto.AppType, participantsRegisterRequestDto.TenantConfigId);

            return Error.Unexpected(e is not BusinessException
                ? "Erro ao criar o usuário. Tente novamente, por favor"
                : e.Message);
        }
    }

    private async Task<DigitalAccountParticipantDetail> CreateFullUserOnDigitalAccount(
        ParticipantsRegisterRequestDto participantsRegisterRequestDto)
    {
        var createParticipantRegister = ParticipantProfileV2.MapToDigitalAccountCreate(participantsRegisterRequestDto);

        await _digitalAccountExternalService.Create(createParticipantRegister, participantsRegisterRequestDto.AppType,
            participantsRegisterRequestDto.TenantConfigId);

        return await _digitalAccountExternalService
            .GetDigitalAccountByDocument(participantsRegisterRequestDto.Document,
                participantsRegisterRequestDto.AppType,
                participantsRegisterRequestDto.TenantConfigId);
    }

    private static void AddCompanyRegistrationAttribute(DigitalAccountParticipantDetail lastVersionOfUser,
        ParticipantsRegisterRequestDto participantsRegisterRequestDto)
    {
        if (participantsRegisterRequestDto.AppType != ApplicationType.VibeEmpresas) return;

        lastVersionOfUser.AddCustomRegistrationAttribute(nameof(DigitalAccountParticipantDetail.Name),
            participantsRegisterRequestDto.Owner.Name);

        lastVersionOfUser.AddCustomRegistrationAttribute(nameof(DigitalAccountParticipantDetail.UserDocument),
            participantsRegisterRequestDto.Owner.Document);

        lastVersionOfUser.AddCustomRegistrationAttribute(Constants.BUSINESS_AREA_VIBE_EMPRESAS_KEY,
            participantsRegisterRequestDto.BusinessArea);
    }

    private static void AddAdditionalInfoWhenHasPreRegister(DigitalAccountParticipantDetail participantDetailToUpdate,
        ParticipantsRegisterRequestDto participantsRegisterRequestDto)
    {
        participantDetailToUpdate.BirthDate = participantsRegisterRequestDto.BirthDate;

        participantDetailToUpdate.Name = participantsRegisterRequestDto.Name;

        participantDetailToUpdate.RandomKey = participantsRegisterRequestDto.Document;
    }

    private async Task<string> LinkUserToIam(ParticipantsRegisterRequestDto participantsRegisterRequestDto,
        DigitalAccountParticipantDetail preRegisteredParticipant)
    {
        if (preRegisteredParticipant is null)
            return await CreateParticipantOnIam(participantsRegisterRequestDto);

        await _identityAccessManagementExternalService.CreatePasswordForUser(new CreateUserPasswordRequestDto
            {
                DigitalAccountId = preRegisteredParticipant.Id,
                Password = participantsRegisterRequestDto.Password
            },
            participantsRegisterRequestDto.AppType,
            participantsRegisterRequestDto.TenantConfigId);

        return preRegisteredParticipant.Id;
    }

    private async Task<DigitalAccountParticipantDetail> GetDigitalAccountForPreRegisteredUser(
        ParticipantsRegisterRequestDto participantsRegisterRequestDto)
    {
        var existentUser = await _digitalAccountExternalService
            .GetDigitalAccountByDocument(participantsRegisterRequestDto.Document,
                participantsRegisterRequestDto.AppType,
                participantsRegisterRequestDto.TenantConfigId);

        if (existentUser is null)
            return null;

        if (existentUser.HasRegistrationByVibe())
            throw new BusinessException("Usuário já cadastrado");

        return existentUser;
    }

    private async Task DispatchUserCreationOnServiceNow(string digitalAccountId, ApplicationType appType,
        string tenantConfigId = null)
    {
        await _serviceBus.SendMessage(MessageBrokerEntitiesNames.CREATE_SERVICE_NOW_USER_QUEUE_NAME,
            JsonSerializer.Serialize(new ServiceNowUserCreateMessageDto
            {
                DigitalAccountId = digitalAccountId,
                AppType = appType,
                TenantConfigId = tenantConfigId
            }));
    }

    private async Task AddComplementaryUserInformation(
        ParticipantsRegisterRequestDto participantsRegisterRequestDto,
        string digitalAccountId, DigitalAccountParticipantDetail preRegisteredUser)
    {
        await UpsertEmailToDigitalAccount(digitalAccountId, participantsRegisterRequestDto.Email,
            preRegisteredUser?.GetEmail(), participantsRegisterRequestDto.AppType,
            participantsRegisterRequestDto.TenantConfigId);

        await UpsertAddressToDigitalAccount(digitalAccountId, participantsRegisterRequestDto.Address,
            preRegisteredUser?.GetAddress(), participantsRegisterRequestDto.AppType,
            participantsRegisterRequestDto.TenantConfigId);

        await UpsertPhoneToDigitalAccount(digitalAccountId,
            participantsRegisterRequestDto.Cellphone, preRegisteredUser?
                .DigitalAccountPhones.FirstOrDefault()?.Id, participantsRegisterRequestDto.AppType,
            participantsRegisterRequestDto.TenantConfigId);
    }

    private async Task<string> CreateParticipantOnIam(
        ParticipantsRegisterRequestDto participantsRegisterRequestDto)
    {
        var createUserWithPasswordRequestDto =
            _mapper.Map<CreateUserWithPasswordRequestDto>(participantsRegisterRequestDto);

        if (participantsRegisterRequestDto.AppType == ApplicationType.VibeEmpresas ||
            !string.IsNullOrWhiteSpace(participantsRegisterRequestDto.TenantConfigId))
        {
            createUserWithPasswordRequestDto.DocumentTypeEnumId = DocumentType.CNPJ;
        }

        var digitalAccountId = await _identityAccessManagementExternalService.CreateUserWithPassword(
            createUserWithPasswordRequestDto,
            participantsRegisterRequestDto.AppType, participantsRegisterRequestDto.TenantConfigId);

        return digitalAccountId;
    }

    private async Task UpsertEmailToDigitalAccount(string digitalAccountId, string newEmail,
        string preRegisteredUserEmailId, ApplicationType? appType = null, string tenantConfigId = null)
    {
        if (preRegisteredUserEmailId is not null)
        {
            await _digitalAccountExternalService.UpdateEmailFromDigitalAccount(newEmail, digitalAccountId,
                preRegisteredUserEmailId, appType, tenantConfigId);
            return;
        }

        await _digitalAccountExternalService.AddEmailToDigitalAccount(newEmail, digitalAccountId, appType,
            tenantConfigId);
    }

    private async Task UpsertPhoneToDigitalAccount(string digitalAccountId, string newPhone,
        string preRegisteredPhoneId, ApplicationType? appType = null, string tenantConfigId = null)
    {
        if (string.IsNullOrWhiteSpace(newPhone))
        {
            await _digitalAccountExternalService.UpdatePhoneNumberFromDigitalAccount(newPhone, digitalAccountId,
                preRegisteredPhoneId, appType, tenantConfigId);
            return;
        }

        await _digitalAccountExternalService.AddPhoneToDigitalAccount(newPhone, digitalAccountId, appType,
            tenantConfigId);
    }

    private async Task UpsertAddressToDigitalAccount(string digitalAccountId,
        ParticipantAddressDto participantsRegisterRequestDto, DigitalAccountAddressDto preRegisteredUserAddress,
        ApplicationType? appType = null, string tenantConfigId = null)
    {
        var digitalAccountAddressDto =
            _mapper.Map<ParticipantAddressDto, DigitalAccountAddressDto>(participantsRegisterRequestDto);

        digitalAccountAddressDto.DigitalAccountId = digitalAccountId;

        if (preRegisteredUserAddress != null)
        {
            digitalAccountAddressDto.Id = preRegisteredUserAddress.Id;
            await _digitalAccountExternalService.UpdateAddress(digitalAccountAddressDto, appType, tenantConfigId);
            return;
        }

        await _digitalAccountExternalService.CreateAddressForDigitalAccount(digitalAccountAddressDto, appType,
            tenantConfigId);
    }

    private async Task<string> SendValidationConfirmationCodeForCellPhone(
        string digitalAccountId,
        ParticipantsRegisterRequestDto participantsRegisterRequestDto)
    {
        return (await _identityAccessManagementExternalService.SendCellphoneOtp(
            participantsRegisterRequestDto.Cellphone,
            digitalAccountId,
            "onboarding",
            participantsRegisterRequestDto.AppType,
            participantsRegisterRequestDto.TenantConfigId)).OtpId;
    }

    private async Task AcceptTermsForApp(ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto,
        string digitalAccountId, ApplicationType appType, string tenantConfigId = null)
    {
        var defaultRequestForAcceptTerms = new AcceptTermsRequestDto
        {
            DigitalAccountId = digitalAccountId,
            UserAgent = new TermsUserAgentDto
            {
                Device = participantsRegisterRequestHeaderDto.Device,
                OperationalSystem = participantsRegisterRequestHeaderDto.OperationalSystem,
                Language = participantsRegisterRequestHeaderDto.Language,
                DeviceType = participantsRegisterRequestHeaderDto.DeviceType,
            },
            Geolocation = new TermsGeolocationDto
            {
                Latitude = participantsRegisterRequestHeaderDto.Latitude,
                Longitude = participantsRegisterRequestHeaderDto.Longitude
            },
            Ip = participantsRegisterRequestHeaderDto.Ip,
        };

        var useTermsTermId = await _tenantService.GetUseTermsTermId(appType, tenantConfigId);
        var privacyPoliceTermId = await _tenantService.GetPrivacyPoliceTermId(appType, tenantConfigId);

        await Task.WhenAll(
            _termsExternalService.AcceptTermsForLastVersion(defaultRequestForAcceptTerms with
            {
                TermId = useTermsTermId
            }, appType, tenantConfigId),
            _termsExternalService.AcceptTermsForLastVersion(defaultRequestForAcceptTerms with
            {
                TermId = privacyPoliceTermId
            }, appType, tenantConfigId));
    }

    private async Task<ErrorOr<bool>> HasValidationErrorsOnInputs(
        ParticipantsRegisterRequestDto participantsRegisterRequestDto,
        ParticipantsRegisterRequestHeaderDto participantsRegisterRequestHeaderDto)
    {
        var validationResultForBody =
            await _participantsRegisterRequestValidator.ValidateAsync(participantsRegisterRequestDto);

        var validationResultForHeaders =
            await _participantsRegisterRequestHeaderValidator.ValidateAsync(participantsRegisterRequestHeaderDto);

        if (!validationResultForBody.IsValid || !validationResultForHeaders.IsValid)
            return validationResultForBody.Errors.ToValidation()
                .Concat(validationResultForHeaders.Errors.ToValidation()).ToList();

        return true;
    }
}
