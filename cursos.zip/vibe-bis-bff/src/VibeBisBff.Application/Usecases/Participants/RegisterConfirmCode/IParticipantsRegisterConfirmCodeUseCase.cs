﻿using VibeBisBff.Dto.Participants;

namespace VibeBisBff.Application.UseCases.Participants.RegisterConfirmCode;

public interface IParticipantsRegisterConfirmCodeUseCase
{
    Task Execute(ConfirmOptCodeRequestDto confirmOptCodeRequestDto, string pinId);
}
