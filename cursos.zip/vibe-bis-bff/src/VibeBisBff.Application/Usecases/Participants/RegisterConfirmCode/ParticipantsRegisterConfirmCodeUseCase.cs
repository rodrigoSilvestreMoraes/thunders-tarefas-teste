﻿using Common.Core.Exceptions;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement.Dto;

namespace VibeBisBff.Application.UseCases.Participants.RegisterConfirmCode;

public class ParticipantsRegisterConfirmCodeUseCase : IParticipantsRegisterConfirmCodeUseCase
{
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;

    public ParticipantsRegisterConfirmCodeUseCase(IIdentityAccessManagementExternalService identityAccessManagementExternalService) =>
        _identityAccessManagementExternalService = identityAccessManagementExternalService;

    public async Task Execute(ConfirmOptCodeRequestDto confirmOptCodeRequestDto, string pinId)
    {
        if (string.IsNullOrWhiteSpace(confirmOptCodeRequestDto.Code))
            throw new BusinessException("O código deve ser informado");

        ValidateOtpResponseDto result;

        if(confirmOptCodeRequestDto.KeyType == TempConfirmOtpKeyType.Cellphone)
            result = await _identityAccessManagementExternalService.ValidateOtpCode(pinId, confirmOptCodeRequestDto.Code, "onboarding",
                appType: confirmOptCodeRequestDto.AppType, tenantConfigId: confirmOptCodeRequestDto.TenantConfigId);
        else
            result = await _identityAccessManagementExternalService.ValidateOtpCode(pinId, confirmOptCodeRequestDto.Code,
                appType: confirmOptCodeRequestDto.AppType, tenantConfigId: confirmOptCodeRequestDto.TenantConfigId);

        if (result.Success)
            return;

        throw new BusinessException(result.GetFriendlyErrorMessage()!);
    }
}
