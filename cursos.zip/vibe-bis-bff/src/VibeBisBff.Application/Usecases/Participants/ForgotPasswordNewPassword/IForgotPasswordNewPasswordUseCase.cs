﻿using ErrorOr;
using VibeBisBff.Dto.Participants;

namespace VibeBisBff.Application.Usecases.Participants.ForgotPasswordNewPassword;

public interface IForgotPasswordNewPasswordUseCase
{
    Task<ErrorOr<Success>> Execute(ForgotPasswordNewPasswordDto forgotPasswordNewPasswordDto);
}
