﻿using ErrorOr;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.Dto.Participants;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;

namespace VibeBisBff.Application.Usecases.Participants.ForgotPasswordNewPassword;

public class ForgotPasswordNewPasswordUseCase : IForgotPasswordNewPasswordUseCase
{
    private readonly IChangeKeyWorkflowRepository _changeKeyWorkflowRepository;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;

    public ForgotPasswordNewPasswordUseCase(IChangeKeyWorkflowRepository changeKeyWorkflowRepository,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService)
    {
        this._changeKeyWorkflowRepository = changeKeyWorkflowRepository;
        this._identityAccessManagementExternalService = identityAccessManagementExternalService;
    }

    public async Task<ErrorOr<Success>> Execute(ForgotPasswordNewPasswordDto forgotPasswordNewPasswordDto)
    {
        var workflow = await _changeKeyWorkflowRepository.GetById(forgotPasswordNewPasswordDto.ChangeKeyWorkflowId);

        if (workflow is null)
            return Error.Validation(description: "Foi enviado um processo de validação não existente");

        if(workflow.WorkflowDone)
            return Error.Validation(description: "Seção não disponível");

        workflow.SetWorkflowDone();

        // TODO: await _identityAccessManagementExternalService.ChangePassword();

        await _changeKeyWorkflowRepository.Update(workflow);

        return Result.Success;
    }
}
