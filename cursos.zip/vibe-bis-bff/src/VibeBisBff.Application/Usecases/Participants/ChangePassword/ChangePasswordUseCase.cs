﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Participants.ChangePassword;

public class ChangePasswordUseCase : IChangePasswordUseCase
{
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public ChangePasswordUseCase(IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        AuthenticationProvider authenticationProvider)
    {
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
    }

    public async Task<ErrorOr<Success>> Execute(ParticipantsChangePassword participantsChangePassword)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        await _identityAccessManagementExternalService.ChangePassword(participantsChangePassword, digitalAccountId.Value);

        return Result.Success;
    }
}
