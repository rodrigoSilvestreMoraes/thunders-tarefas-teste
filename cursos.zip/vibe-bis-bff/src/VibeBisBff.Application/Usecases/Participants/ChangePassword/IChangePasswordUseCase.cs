﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

namespace VibeBisBff.Application.Usecases.Participants.ChangePassword;

public interface IChangePasswordUseCase
{
    Task<ErrorOr<Success>> Execute(ParticipantsChangePassword participantsChangePassword);
}
