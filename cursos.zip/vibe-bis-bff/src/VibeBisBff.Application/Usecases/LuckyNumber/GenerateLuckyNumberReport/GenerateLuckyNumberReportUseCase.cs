﻿using System.Globalization;
using System.Text;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Specialized;
using Microsoft.Extensions.Options;
using Vertem.Logs.Logger;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Entities.LuckyNumber;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.Domain.Repositories.MongoDb.PromoCode;

namespace VibeBisBff.Application.Usecases.LuckyNumber.GenerateLuckyNumberReport;

public class GenerateLuckyNumberReportUseCase : IGenerateLuckyNumberReportUseCase
{
    private readonly IDistributedPromoCodeRepository _distributedPromoCodeRepository;
    private readonly IAutoIncrementControlRepository _autoIncrementControlRepository;
    private readonly BlobServiceClient _blobServiceClient;
    private readonly GeneratePromoCodeReportOptions _generatePromoCodeReportOptions;
    private readonly VertemLogsLogger _vertemLogsLogger;

    public GenerateLuckyNumberReportUseCase(IDistributedPromoCodeRepository distributedPromoCodeRepository,
        IAutoIncrementControlRepository autoIncrementControlRepository, BlobServiceClient blobServiceClient,
        IOptions<GeneratePromoCodeReportOptions> generatePromoCodeOptions,
        VertemLogsLogger vertemLogsLogger)
    {
        _distributedPromoCodeRepository = distributedPromoCodeRepository;
        _autoIncrementControlRepository = autoIncrementControlRepository;
        _blobServiceClient = blobServiceClient;
        _generatePromoCodeReportOptions = generatePromoCodeOptions.Value;
        _vertemLogsLogger = vertemLogsLogger;
    }

    public async Task Execute(CancellationToken cancellationToken = default)
    {
        var distributedPromoCodesForMonth =
            await _distributedPromoCodeRepository.GetAllFromPreviousMonth(cancellationToken);

        if (!distributedPromoCodesForMonth.Any())
            return;

        var stringBuilder = new StringBuilder();

        var identifierForFileVersion = await
            _autoIncrementControlRepository.GetNextSequence(AutoIncrementControl
                .DISTRIBUTED_LUCKY_NUMBER_REPORT_FILE_VERSION);

        var appendBlobClient = await GetAppendBlobClient(identifierForFileVersion);

        WriteHeaderLine(stringBuilder, identifierForFileVersion);

        //TODO: Elaborar estratégia para processamento em blocos para grandes volumes
        foreach (var distributedPromoCode in distributedPromoCodesForMonth)
            stringBuilder.AppendLine(
                RemoveDiacritics(
                    $"D{"",-3}{distributedPromoCode.Code.PadLeft(6, '0')}{distributedPromoCode.ParticipantName.Replace("-", ""),-42}" +
                    $"{distributedPromoCode.ParticipantDocument.PadLeft(15, '0')}" +
                    $"{"",-8}{distributedPromoCode.Id.ToString().PadLeft(11, '0')}{_generatePromoCodeReportOptions.CapitalizationUnitaryValue}"));

        stringBuilder.AppendLine($"T{distributedPromoCodesForMonth.Count.ToString().PadLeft(6, '0')}{"",-88}");

        await appendBlobClient.AppendBlockAsync(new MemoryStream(Encoding.UTF8
                .GetBytes(stringBuilder.ToString())),
            null, cancellationToken);

        _vertemLogsLogger.LogInformation("Generate Report Info",
            $"Relatorio de numeros da sorte gerado com sucesso e publicado no Blob com o nome {appendBlobClient.Name}.");
    }

    private void WriteHeaderLine(StringBuilder stringBuilder, int identifierFileVersion)
    {
        stringBuilder.AppendLine($"H{"ATIVOS",-10}{"",-15}{"",-15}{DateTime.UtcNow.Date.ToString("ddMMyyyy")}" +
                                 $"{identifierFileVersion.ToString().PadLeft(6, '0')}{_generatePromoCodeReportOptions.HeaderNegotiationCode,-20}{"",-20}");
    }

    private async Task<AppendBlobClient> GetAppendBlobClient(int identifierFileVersion)
    {
        var blobContainerClient =
            _blobServiceClient.GetBlobContainerClient(_generatePromoCodeReportOptions.GeneratedPromoCodeBlobContainer);

        var appendBlobClient =
            blobContainerClient.GetAppendBlobClient(
                $"ATIVOS{_generatePromoCodeReportOptions.HeaderNegotiationCode}{identifierFileVersion.ToString().PadLeft(6, '0')}.txt");

        await appendBlobClient.CreateAsync();

        return appendBlobClient;
    }

    private static string RemoveDiacritics(string content)
    {
        return new string(content.Normalize(NormalizationForm.FormD)
            .Where(ch => CharUnicodeInfo.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark).ToArray());
    }
}
