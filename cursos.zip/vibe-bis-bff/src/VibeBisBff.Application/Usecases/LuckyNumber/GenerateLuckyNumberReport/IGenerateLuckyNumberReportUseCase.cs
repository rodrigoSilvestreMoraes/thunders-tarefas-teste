﻿namespace VibeBisBff.Application.Usecases.LuckyNumber.GenerateLuckyNumberReport;

public interface IGenerateLuckyNumberReportUseCase
{
    Task Execute(CancellationToken cancellationToken = default);
}
