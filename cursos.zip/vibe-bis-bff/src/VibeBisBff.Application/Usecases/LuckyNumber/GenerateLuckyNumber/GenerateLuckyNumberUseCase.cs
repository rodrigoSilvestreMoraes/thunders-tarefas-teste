﻿using Microsoft.Extensions.Options;
using VibeBisBff.Application.Notification.Usecases;
using VibeBisBff.CrossCuting.Dto.Notification;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Extensions;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Entities;
using VibeBisBff.Domain.Entities.LuckyNumber;
using VibeBisBff.Domain.Entities.Notifications;
using VibeBisBff.Domain.Repositories.MongoDb;
using VibeBisBff.Domain.Repositories.MongoDb.PromoCode;
using VibeBisBff.Domain.Repositories.MongoDb.Raffle;
using VibeBisBff.Dto.MessageWorker;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Tradeback.Authorizer;
using VibeBisBff.ExternalServices.Tradeback.Authorizer.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount.Entities;

namespace VibeBisBff.Application.Usecases.LuckyNumber.GenerateLuckyNumber;

public class GenerateLuckyNumberUseCase : IGenerateLuckyNumberUsecase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly ITradebackAuthorizerExternalService _tradebackAuthorizerExternalService;
    private readonly IAutoIncrementControlRepository _autoIncrementControlRepository;
    private readonly IDistributedPromoCodeRepository _distributedPromoCodeRepository;
    private readonly ITenantService _tenantService;
    private readonly NotificationOptions _notificationOptions;
    private readonly INotificationUseCase _notificationUseCase;
    private readonly IRaffleRepository _raffleRepository;

    public GenerateLuckyNumberUseCase(IDigitalAccountExternalService digitalAccountExternalService,
        ITradebackAuthorizerExternalService tradebackAuthorizerExternalService,
        IAutoIncrementControlRepository autoIncrementControlRepository,
        IDistributedPromoCodeRepository distributedPromoCodeRepository,
        ITenantService tenantService,
        IOptionsSnapshot<NotificationOptions> notificationOptions,
        INotificationUseCase notificationUseCase,
        IRaffleRepository raffleRepository)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _tradebackAuthorizerExternalService = tradebackAuthorizerExternalService;
        _autoIncrementControlRepository = autoIncrementControlRepository;
        _distributedPromoCodeRepository = distributedPromoCodeRepository;
        _tenantService = tenantService;
        _notificationOptions = notificationOptions.Value;
        _notificationUseCase = notificationUseCase;
        _raffleRepository = raffleRepository;
    }

    public async Task Execute(LuckyNumberGenerateMessageDto luckyNumberGenerateMessage)
    {
        var participantDetails =
            await _digitalAccountExternalService.GetParticipantDetailsById(luckyNumberGenerateMessage.DigitalAccountId,
                luckyNumberGenerateMessage.AppType, luckyNumberGenerateMessage.TenantConfigId);

        var luckyNumberOptions = await _tenantService.GetLuckyNumberOptions(luckyNumberGenerateMessage.AppType,
            luckyNumberGenerateMessage.TenantConfigId);

        var transactionResponse = await _tradebackAuthorizerExternalService.GenerateAndConfirmBenefit(
            participantDetails.UserDocument,
            luckyNumberOptions.MerchantId,
            new[] { luckyNumberOptions.CampaignId },
            luckyNumberGenerateMessage.Products.Select(product => new CartProductItemDto
            {
                Quantity = 1,
                UnitaryValue = product.BurnQuantityOfVirtualCoins,
                ProductCode = product.Id
            }),
            Guid.NewGuid().ToString(),
            appType: luckyNumberGenerateMessage.AppType,
            tenantConfigId: luckyNumberGenerateMessage.TenantConfigId);

        if (transactionResponse.Benefits.IsNullOrEmpty())
            return;

        var codes = transactionResponse.Benefits
            .Select(x => x.PromotionalCode)
            .ToArray();

        foreach (var code in codes)
            await InsertDistributedCode(participantDetails, code);

        await SendEmail(luckyNumberOptions,
            participantDetails,
            luckyNumberGenerateMessage,
            transactionResponse.TransactionId,
            participantDetails.GetEmail(),
            codes.ToList());
    }

    private async Task SendEmail(LuckyNumberOptions luckyNumberOptions,
        DigitalAccountParticipantDetail digitalAccountParticipantDetail,
        LuckyNumberGenerateMessageDto luckyNumberGenerateMessage,
        string correlationId,
        string email, List<string> codes)
    {
        var correspondentRaffleByDateForReceivedNumber = await _raffleRepository.GetRaffleByDate(DateTime.UtcNow.Date);

        var messageValues = new List<KeyValuePair<string, string>>
        {
            new("luckyNumber", string.Join(", ", codes)),
            new("name", digitalAccountParticipantDetail.Name),
            new("raffleName", correspondentRaffleByDateForReceivedNumber?.Name),
            new("announcementDate",
                correspondentRaffleByDateForReceivedNumber?.AnnouncementDate.ToString("dd/MM/yyyy") ?? ""),
            new("raffleDate", correspondentRaffleByDateForReceivedNumber?.RaffleDate.ToString("dd/MM/yyyy") ?? "")
        };

        var emailNotification = new NotificationEmail(
            templateId: _notificationOptions.LuckyNumberGeneratedEmailTemplateId,
            subject: luckyNumberOptions.NotificationEmailSubject,
            to: new List<string> { email },
            messageValues: messageValues);

        var requestNotification = new NotificationRequestDto
        {
            CorrelationId = correlationId,
            DigitalAccountId = luckyNumberGenerateMessage.DigitalAccountId,
            SourceEvent = NotificationSourceEvent.GeneratedLuckyNumber,
            Title = "Você ganhou números da sorte!",
            Description = "Você está concorrendo a 10 MIL REAIS", //TODO: Tornar dinâmico com base no sorteio corrente
            TenantConfigId = luckyNumberGenerateMessage.TenantConfigId
        };

        await _notificationUseCase.SendNotification(requestNotification, emailNotification);
    }

    private async Task InsertDistributedCode(DigitalAccountParticipantDetail participantDetails, string code)
    {
        var sequenceForCurrentProcess =
            await _autoIncrementControlRepository.GetNextSequence(AutoIncrementControl
                .DISTRIBUTED_LUCKY_NUMBER_IDENTIFIER);

        var distributedPromoCode = new DistributedPromoCode(sequenceForCurrentProcess, participantDetails.Name,
            participantDetails.UserDocument,
            code, participantDetails.Id);

        await _distributedPromoCodeRepository.InsertOneAsync(distributedPromoCode);
    }
}
