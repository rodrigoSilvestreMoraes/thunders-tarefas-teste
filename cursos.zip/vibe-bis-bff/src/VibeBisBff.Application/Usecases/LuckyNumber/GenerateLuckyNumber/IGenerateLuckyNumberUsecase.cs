﻿using VibeBisBff.Dto.MessageWorker;

namespace VibeBisBff.Application.Usecases.LuckyNumber.GenerateLuckyNumber
{
    public interface IGenerateLuckyNumberUsecase
    {
        public Task Execute(LuckyNumberGenerateMessageDto luckyNumberGenerateMessage);
    }
}
