﻿using ErrorOr;
using VibeBisBff.Dto.Benefit.BenefitRedemption;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2.Dto;

namespace VibeBisBff.Application.Usecases.Benefits.RedemptionConfirmation;

public interface IBenefitRedemptionConfirmationUseCase
{
    Task<ErrorOr<VoucherResponseDto>> Execute(
        BenefitRedemptionPinVerificationRequestDto benefitRedemptionPinVerificationRequestDto);

    Task<ErrorOr<VoucherResponseDto>> Execute(string digitalAccountId,
        AuthorizerV2TransactionRequestDto benefitRequest);
}
