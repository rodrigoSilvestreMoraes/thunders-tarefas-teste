﻿using System.Text.Json;
using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using Common.Core.Exceptions;
using ErrorOr;
using Microsoft.Extensions.Options;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Application.Extensions;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Entities;
using VibeBisBff.Domain.Entities.Benefit;
using VibeBisBff.Domain.Repositories.MongoDb.Benefit;
using VibeBisBff.Dto.Benefit.BenefitRedemption;
using VibeBisBff.Dto.MessageWorker;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.PartnerHub.Voucher;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2;
using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2.Dto;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Cache;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.Infra.ServiceBus;

namespace VibeBisBff.Application.Usecases.Benefits.RedemptionConfirmation;

public class BenefitRedemptionConfirmationUseCase : IBenefitRedemptionConfirmationUseCase
{
    private readonly AuthTokenAccessor _tokenAccessor;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly IAccomplishedBenefitsRepository _accomplishedBenefitsRepository;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly VoucherOptions _voucherOptions;
    private readonly IVoucherHubExternalService _voucherHubHubExternalService;
    private readonly IServiceBus _messageBroker;
    private readonly VertemLogsLogger _logger;
    private readonly ITradebackAuthorizerV2ExternalService _tradebackAuthorizerV2ExternalService;
    private readonly IRedisService _redisService;
    private readonly ITradebackPromoExternalService _tradebackPromoExternalService;
    private readonly ITenantService _tenantService;

    public BenefitRedemptionConfirmationUseCase(
        AuthTokenAccessor tokenAccessor,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        IAccomplishedBenefitsRepository accomplishedBenefitsRepository,
        AuthenticationProvider authenticationProvider,
        IOptionsSnapshot<VoucherOptions> voucherOptions,
        IServiceBus messageBroker,
        IVoucherHubExternalService voucherHubExternalService,
        VertemLogsLogger logger,
        ITradebackAuthorizerV2ExternalService tradebackAuthorizerV2ExternalService,
        IRedisService redisService,
        ITradebackPromoExternalService tradebackPromoExternalService,
        ITenantService tenantService)
    {
        _tokenAccessor = tokenAccessor;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _accomplishedBenefitsRepository = accomplishedBenefitsRepository;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
        _voucherOptions = voucherOptions.Value;
        _voucherHubHubExternalService = voucherHubExternalService;
        _messageBroker = messageBroker;
        _logger = logger;
        _tradebackAuthorizerV2ExternalService = tradebackAuthorizerV2ExternalService;
        _redisService = redisService;
        _tradebackPromoExternalService = tradebackPromoExternalService;
        _tenantService = tenantService;
    }

    public async Task<ErrorOr<VoucherResponseDto>> Execute(
        BenefitRedemptionPinVerificationRequestDto benefitRedemptionPinVerificationRequestDto)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var result = await _identityAccessManagementExternalService.ValidateOtpCode(
            benefitRedemptionPinVerificationRequestDto.PinId,
            benefitRedemptionPinVerificationRequestDto.Pin);

        if (!result.Success)
            throw new BusinessException(result.GetFriendlyErrorMessage());

        var benefitRequestAsString = await _redisService.Get(benefitRedemptionPinVerificationRequestDto.PinId);

        if (benefitRequestAsString is null)
            throw new BusinessException("Erro ao encontrar o benefício para resgate");

        var benefitRequest = JsonSerializer.Deserialize<AuthorizerV2TransactionRequestDto>(benefitRequestAsString);

        return await Execute(digitalAccountId.Value, benefitRequest);
    }

    public async Task<ErrorOr<VoucherResponseDto>> Execute(string digitalAccountId,
        AuthorizerV2TransactionRequestDto benefitRequest)
    {
        var generatedBenefitTransaction =
            await _tradebackAuthorizerV2ExternalService.GenerateTransaction(benefitRequest);

        if (!generatedBenefitTransaction.HasBenefits)
        {
            _logger.LogError(new ExceptionLog(new Exception(generatedBenefitTransaction.Messages?.Default ?? "A transação gerada do resgate de benefício não possui benefícios")));
            throw new BusinessException("Resgate de benefício não autorizado.");
        }

        var voucherHubBenefit = generatedBenefitTransaction.Benefits.FirstOrDefault(x => x.VoucherHub != null);

        if (voucherHubBenefit is null)
            throw new BusinessException("Resgate de benefício não autorizado.");

        try
        {
            var advertisementResponse = await _tradebackPromoExternalService
                .SearchAdvertisements(new AdvertisementSearchRequestDto(new PromoPaginationDto(1, 1),
                    new AdvertisementSearchFilterDto
                    {
                        SaleIds = new[] { voucherHubBenefit.SaleId }
                    }));

            var advertisement = advertisementResponse.Value.Data[0];

            var accomplished = new AccomplishedBenefit
            {
                CategoryId = advertisement.Store.Chain.CategoryInfo?.Id,
                CategoryName = advertisement.Store.Chain.CategoryInfo?.Name,
                ProductId = voucherHubBenefit.VoucherHub.SkuId.ToString(),
                Cost = advertisement.ActivationCondition.FirstLevelCondition.AvailableWalletBalance.AvailableAmount
                    .Amount,
                Description = advertisement.Description,
                Name = advertisement.Name,
                TransactionId = generatedBenefitTransaction.TransactionId,
                DigitalAccountId = _authenticatedUser.GetDigitalAccountId().Value,
                VoucherHubOrderId = voucherHubBenefit.VoucherHub.OrderId,
                VendorId = benefitRequest.Merchant.Id,
                IsFromEngagement = true,
                VendorName = advertisement.Store.Chain.Name,
                Images = advertisement.Store.Chain.Images.Select(x => new GenericImage
                {
                    Tag = x.Tag,
                    Url = x.Url
                }).ToList()
            };

            await _accomplishedBenefitsRepository.Insert(accomplished);

            var hasRaffle = await _tenantService.HasRaffle();
            if(hasRaffle)
                await DispatchBenefitRedeemedEvent(
                    accomplished.Cost, advertisement.EligibleProduct.Products[0].Code,
                    digitalAccountId);
        }
        catch (Exception ex)
        {
            _logger.LogError(new ExceptionLog(ex));
        }

        var benefitVoucher = await _voucherHubHubExternalService.GetVoucher(
            voucherHubBenefit.VoucherHub.SkuId.ToString(),
            voucherHubBenefit.VoucherHub.OrderId.ToString(),
            _tokenAccessor.AccessToken);

        return benefitVoucher.ToVoucherResponse(DateTime.UtcNow, _voucherOptions.ExpirationDays);
    }

    private async Task DispatchBenefitRedeemedEvent(decimal priceInVirtualCoins, string sku, string digitalAccountId)
    {
        var luckyNumberGenerateMessage = new LuckyNumberGenerateMessageDto
        {
            DigitalAccountId = digitalAccountId,
            AppType = await _tenantService.GetAppType(),
            TenantConfigId = _authenticatedUser.GetScope(Constants.Auth.TENANT_CONFIG_ID).Value,
            Products = new List<ProductsWithVibesBurnedDto>
            {
                new()
                {
                    BurnQuantityOfVirtualCoins = priceInVirtualCoins,
                    Id = sku
                }
            }
        };

        await _messageBroker.SendMessage(MessageBrokerEntitiesNames.REDEEMED_BENEFIT_QUEUE_NAME,
            JsonSerializer.Serialize(luckyNumberGenerateMessage));
    }
}
