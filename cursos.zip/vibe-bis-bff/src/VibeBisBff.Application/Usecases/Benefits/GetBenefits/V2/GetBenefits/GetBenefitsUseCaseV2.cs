﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using Common.Core.Exceptions;
using ErrorOr;
using FluentValidation;
using Microsoft.Extensions.Options;
using VibeBisBff.ExternalServices.Tradeback.Promo;
using VibeBisBff.ExternalServices.Tradeback.Promo.Dto;
using VibeBisBff.CrossCutting.Constants;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Extensions;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Repositories.MongoDb.Benefit;
using VibeBisBff.Domain.Repositories.MongoDb.Engagement;
using VibeBisBff.Dto.Benefit;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.Infra.Helpers;
using System;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;

namespace VibeBisBff.Application.Usecases.Benefits.GetBenefits.V2.GetBenefits;

public class GetBenefitsUseCaseV2 : IGetBenefitsUseCaseV2
{
    private readonly IValidator<GetBenefitsRequestDto> _validation;
    private readonly IAccomplishedBenefitsRepository _accomplishedBenefitsRepository;
    private readonly ITradebackPromoExternalService _promoExternalService;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IBannerRepository _bannerRepository;
    private readonly StorageAccountOptions _storageAccountOptions;

    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private const string DEFAULT_ERROR_MESSAGE = "Erro ao buscar os benefícios. Tente novamente em alguns minutos.";

    public GetBenefitsUseCaseV2(IValidator<GetBenefitsRequestDto> validation,
        IAccomplishedBenefitsRepository accomplishedBenefitsRepository,
        AuthenticationProvider authenticationProvider,
        ITradebackPromoExternalService promoExternalService,
        IBannerRepository bannerRepository,
        IOptionsSnapshot<StorageAccountOptions> storageAccountOptions,
        IDigitalAccountExternalService digitalAccountExternalService)
    {
        _validation = validation;
        _accomplishedBenefitsRepository = accomplishedBenefitsRepository;
        _promoExternalService = promoExternalService;
        _bannerRepository = bannerRepository;
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
        _storageAccountOptions = storageAccountOptions.Value;
    }

    public async Task<ErrorOr<List<GetBenefitsResponseV2Dto>>> Execute(GetBenefitsRequestDto getBenefitsRequestDto)
    {
        var validationResult = await _validation.ValidateAsync(getBenefitsRequestDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        if (getBenefitsRequestDto.Status == BenefitStatus.Available)
            return await GetAvailableBenefits(getBenefitsRequestDto.ListType!.Value);

        return await GetRedeemedBenefits();
    }

    private async Task<ErrorOr<List<GetBenefitsResponseV2Dto>>> GetAvailableBenefits(BenefitListType listType)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var userOnDigitalAccount =
            await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        return listType switch
        {
            BenefitListType.All => await GetAllAvailableBenefits(userOnDigitalAccount!.UserDocument),
            BenefitListType.HomeSection => await GetHomeSectionAvailableBenefits(userOnDigitalAccount!.UserDocument),
            BenefitListType.Banner => await GetBannersAvailableBenefits(userOnDigitalAccount!.UserDocument),
            _ => throw new BusinessException("O tipo de lista informado para consulta de benefícios é inválida")
        };
    }

    private async Task<List<GetBenefitsResponseV2Dto>> GetRedeemedBenefits()
    {
        var accomplishedBenefits =
            await _accomplishedBenefitsRepository.GetByDigitalAccount(_authenticatedUser.GetDigitalAccountId().Value);

        if (accomplishedBenefits == null || !accomplishedBenefits.Any())
            return new List<GetBenefitsResponseV2Dto>();

        var orderAccomplishedBenefits = accomplishedBenefits
                                        .OrderByDescending(x => x.RedeemedDate)
                                        .ToList();

        return orderAccomplishedBenefits.Select(accomplishedBenefit => new GetBenefitsResponseV2Dto()
        {
            CategoryId = accomplishedBenefit.IsFromEngagement
                ? accomplishedBenefit.CategoryId
                : accomplishedBenefit.Product.CategoryId,
            CategoryName = accomplishedBenefit.IsFromEngagement
                ? accomplishedBenefit.CategoryName
                : accomplishedBenefit.Product.CategoryName,
            Id = accomplishedBenefit.Id,
            Cost = accomplishedBenefit.IsFromEngagement
                ? accomplishedBenefit.Cost
                : accomplishedBenefit.Product.SellingPrice,
            Name = accomplishedBenefit.Name ?? accomplishedBenefit.Product.Name,
            Description = accomplishedBenefit.IsFromEngagement
                ? accomplishedBenefit.Description
                : MarketplaceProductHelper.GetFormattedDescriptionAsMarkdownWithFeatures(
                    accomplishedBenefit.Description ?? accomplishedBenefit.Product.Name,
                    accomplishedBenefit.Features),
            Image = accomplishedBenefit.IsFromEngagement
                ? accomplishedBenefit.Images.Find(x => x.Tag == BenefitConstants.CARD_IMAGE_TAG)?.Url
                : GetProductImageUrlFromSku(accomplishedBenefit.Product.Sku, "card"),
            DetailImage = accomplishedBenefit.IsFromEngagement
                ? accomplishedBenefit.Images.Find(x => x.Tag == BenefitConstants.DETAIL_IMAGE_TAG)?.Url
                : GetProductImageUrlFromSku(accomplishedBenefit.Product.Sku, "detail"),
            BannerImage = accomplishedBenefit.IsFromEngagement
                ? accomplishedBenefit.Images.Find(x => x.Tag == BenefitConstants.BANNER_IMAGE_TAG)?.Url
                : GetProductImageUrlFromSku(accomplishedBenefit.Product.Sku, "banner"),
            ListImage = accomplishedBenefit.IsFromEngagement ?
                accomplishedBenefit.Images.Find(x => x.Tag == BenefitConstants.LIST_IMAGE_TAG)?.Url
                : GetProductImageUrlFromSku(accomplishedBenefit.Product.Sku, "list"),
            Vendor = new BenefitVendorDto
            {
                Id = long.Parse((accomplishedBenefit.IsFromEngagement
                    ? accomplishedBenefit.VendorId
                    : accomplishedBenefit.Product.VendorId) ?? "0"),
                Name = accomplishedBenefit.IsFromEngagement
                    ? accomplishedBenefit.VendorName
                    : accomplishedBenefit.Product.VendorName
            }
        }).ToList();
    }

    private async Task<List<GetBenefitsResponseV2Dto>> GetAllAvailableBenefits(string userDocument)
    {
        var result = await GetBenefitsFromTradebackPromo(userDocument);

        RankAvailableBenefits(ref result);

        return result.ToList();
    }

    private async Task<List<GetBenefitsResponseV2Dto>> GetHomeSectionAvailableBenefits(string userDocument)
    {
        var result = await GetBenefitsFromTradebackPromo(userDocument);

        RankAvailableBenefits(ref result);

        return result.Take(10).ToList();
    }

    private async Task<IEnumerable<GetBenefitsResponseV2Dto>> GetBenefitsFromTradebackPromo(string userDocument)
    {
        var categoriesFromCompanies = await _promoExternalService.GetChainCategories();

        if (categoriesFromCompanies.IsError)
            throw new BusinessException(DEFAULT_ERROR_MESSAGE);

        var response = await _promoExternalService.SearchAdvertisements(new AdvertisementSearchRequestDto(
            new PromoPaginationDto(100, 1), new AdvertisementSearchFilterDto
            {
                ParticipantIdentifier = userDocument,
                Chain = new AdvertisementChainFilterDto()
                {
                    Categories = categoriesFromCompanies.Value.Where(x => x.Name != Constants.QUEST_CATEGORY_NAME)
                        .Select(x => x.Id).ToList()
                }
            }));

        if (response.IsError)
            throw new BusinessException(DEFAULT_ERROR_MESSAGE);

        return response.Value.Data.Select(BuildResponseItem).ToList();
    }

    private async Task<List<GetBenefitsResponseV2Dto>> GetBannersAvailableBenefits(string userDocument)
    {
        var benefitsBanners = await _bannerRepository.GetBannersByType(BannerType.BenefitSale);

        if (!benefitsBanners.Any())
            throw new BusinessException(DEFAULT_ERROR_MESSAGE);

        var response = await _promoExternalService.SearchAdvertisements(new AdvertisementSearchRequestDto(
            new PromoPaginationDto(benefitsBanners.Count, 1), new AdvertisementSearchFilterDto
            {
                ParticipantIdentifier = userDocument,
                SaleIds = benefitsBanners.Select(x => x.EngagementEntityId)
            }));

        if (response.IsError)
            throw new BusinessException(DEFAULT_ERROR_MESSAGE);

        var result = response.Value.Data.Select(BuildResponseItem);

        RankAvailableBenefits(ref result);

        return result.ToList();
    }

    private static GetBenefitsResponseV2Dto BuildResponseItem(AdvertisementDataDto advertisement) =>
        new()
        {
            Id = advertisement.EligibleProduct.Products[0].Code,
            Description = advertisement.Description,
            Name = advertisement.Name,
            Order = int.Parse(advertisement.Attributes.Find(attribute => attribute.Key == "ranking")?.Value.RemoveHtmlTags() ?? "9999"),
            Image = advertisement.Store?.Chain?.Images?.Find(image => image.Tag == BenefitConstants.CARD_IMAGE_TAG)?.Url,
            CategoryId = advertisement.Store?.Chain?.CategoryInfo?.Id,
            CategoryName = advertisement.Store?.Chain?.CategoryInfo?.Name,
            Cost = advertisement.ActivationCondition?.FirstLevelCondition?.AvailableWalletBalance?.AvailableAmount?.Amount ?? 0,
            BannerImage = advertisement.Store?.Chain?.Images?.Find(image => image.Tag == BenefitConstants.BANNER_IMAGE_TAG)?.Url,
            DetailImage = advertisement.Store?.Chain?.Images?.Find(image => image.Tag == BenefitConstants.DETAIL_IMAGE_TAG)?.Url,

            Vendor = new BenefitVendorDto
            {
                Name = advertisement.Store?.Chain?.Name,
                Id = long.Parse(advertisement.Store?.Chain?.Id ?? "0")
            }
        };


    private string GetProductImageUrlFromSku(string skuId, string imageDestiny) =>
        $"{_storageAccountOptions?.ProductImageBaseUrlForBenefits}/{skuId}_{imageDestiny}.png";

    private static void RankAvailableBenefits(ref IEnumerable<GetBenefitsResponseV2Dto> availableBenefits)
    {
        availableBenefits = availableBenefits
            .OrderBy(x => x.Order)
            .ThenByDescending(x => x.Cost)
            .ThenBy(x => x.Id);
    }
}
