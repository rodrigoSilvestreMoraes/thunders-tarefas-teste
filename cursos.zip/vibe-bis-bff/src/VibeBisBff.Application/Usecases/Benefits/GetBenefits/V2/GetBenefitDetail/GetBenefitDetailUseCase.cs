﻿using Common.Core.Authentication.Models;
using ErrorOr;
using System.Text.Json;
using VibeBisBff.Application.Mappers.Benefits;
using VibeBisBff.Application.Usecases.Offers.GenerateRules;
using VibeBisBff.Application.Usecases.Offers.GetOfferDetail;
using VibeBisBff.Application.Usecases.Tags.GetTag;
using VibeBisBff.Dto.Benefit.V2;
using VibeBisBff.Infra.Cache;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Benefits.GetBenefits.V2.GetBenefitDetail;

public class GetBenefitDetailUseCase : IGetBenefitDetailUseCase
{
    private readonly IGetTagUseCase _getTagUseCase;
    private readonly IGetOfferDetailUseCase _getOfferDetailUseCase;
    private readonly IGenerateRulesUseCase _generateRulesUseCase;

    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IRedisService _redisService;

    private static long HOURS_IN_SECONDS = 3600;

    public GetBenefitDetailUseCase(
        IGetTagUseCase getTagUseCase,
        IGetOfferDetailUseCase getOfferDetailUseCase,
        IGenerateRulesUseCase generateRulesUseCase,
        AuthenticatedUser authenticatedUser,
        IRedisService redisService)
    {
        _getTagUseCase = getTagUseCase;
        _getOfferDetailUseCase = getOfferDetailUseCase;
        _generateRulesUseCase = generateRulesUseCase;

        _authenticatedUser = authenticatedUser;
        _redisService = redisService;
    }

    public async Task<ErrorOr<BenefitDetailV2Dto>> Execute(string benefitId, CancellationToken cancellationToken)
    {
        var CACHE_KEY = $"v2-get-benefit-detail-{benefitId}";
        var dataRedis = await _redisService.Get(CACHE_KEY);

        if (dataRedis != null)
            return JsonSerializer.Deserialize<BenefitDetailV2Dto>(dataRedis);

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();
        if (digitalAccountId.IsError)
            return digitalAccountId.Errors;

        var benefit = await _getOfferDetailUseCase.Execute(benefitId, cancellationToken);

        if (benefit.IsError)
            return benefit.Errors;

        var (tag, isSoldOff) = await _getTagUseCase.Execute(
            benefit.Value.TagId,
            benefit.Value.TagIdSoldOff,
            benefit.Value.TagIdExpiration,
            benefit.Value.ExpirationDate, cancellationToken);

        var (rules, descripionV1) = await _generateRulesUseCase.Execute(benefit.Value.Description, cancellationToken);
        var response = BenefitV2Profile.MapBenefit(benefit.Value, tag, isSoldOff, rules, descripionV1);

        await _redisService.Set(CACHE_KEY, response, HOURS_IN_SECONDS * 3);

        return response;
    }
}
