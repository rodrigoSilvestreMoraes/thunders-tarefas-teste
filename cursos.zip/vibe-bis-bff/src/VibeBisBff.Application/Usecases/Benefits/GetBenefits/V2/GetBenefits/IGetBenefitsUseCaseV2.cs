﻿using VibeBisBff.Dto.Benefit;
using ErrorOr;

namespace VibeBisBff.Application.Usecases.Benefits.GetBenefits.V2.GetBenefits;

public interface IGetBenefitsUseCaseV2
{
    Task<ErrorOr<List<GetBenefitsResponseV2Dto>>> Execute(GetBenefitsRequestDto getBenefitsRequestDto);
}
