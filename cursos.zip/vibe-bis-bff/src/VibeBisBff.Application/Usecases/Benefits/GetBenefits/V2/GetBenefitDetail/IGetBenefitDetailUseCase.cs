﻿using ErrorOr;
using VibeBisBff.Dto.Benefit.V2;

namespace VibeBisBff.Application.Usecases.Benefits.GetBenefits.V2.GetBenefitDetail;

public interface IGetBenefitDetailUseCase
{
    Task<ErrorOr<BenefitDetailV2Dto>> Execute(string benefitId, CancellationToken cancellationToken);
}
