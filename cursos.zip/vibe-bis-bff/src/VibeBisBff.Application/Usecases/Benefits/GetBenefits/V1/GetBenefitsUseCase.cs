﻿using System.Collections.Concurrent;
using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using FluentValidation;
using Microsoft.Extensions.Options;
using Vertem.Logs.Except.Models;
using Vertem.Logs.Logger;
using VibeBisBff.Infra.Helpers;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Entities;
using VibeBisBff.Domain.Repositories.MongoDb.Benefit;
using VibeBisBff.Dto.Benefit;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;
using VibeBisBff.Infra.Auth;
using VibeBisBff.Infra.Extensions;
using VibeBisBff.Domain.Entities.Benefit.Mapper;
using VibeBisBff.ExternalServices.TenantConfigService;

namespace VibeBisBff.Application.Usecases.Benefits.GetBenefits.V1;

[Obsolete("Utilizar a estrutura de vendors para benefícios")]
public class GetBenefitsUseCase : IGetBenefitsUseCase
{
    private readonly IValidator<GetBenefitsRequestDto> _validation;
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly AuthTokenAccessor _tokenAccessor;
    private readonly VertemLogsLogger _logger;
    private readonly IAccomplishedBenefitsRepository _accomplishedBenefitsRepository;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly StorageAccountOptions _storageAccountOptions;
    private readonly ITenantService _tenantService;

    public GetBenefitsUseCase(IValidator<GetBenefitsRequestDto> validation,
        IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        AuthTokenAccessor tokenAccessor,
        VertemLogsLogger logger,
        IAccomplishedBenefitsRepository accomplishedBenefitsRepository,
        AuthenticationProvider authenticationProvider,
        IOptionsSnapshot<StorageAccountOptions> storageAccountOptions,
        ITenantService tenantService)
    {
        _validation = validation;
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _tokenAccessor = tokenAccessor;
        _logger = logger;
        _accomplishedBenefitsRepository = accomplishedBenefitsRepository;
        _tenantService = tenantService;
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
        _storageAccountOptions = storageAccountOptions.Value;
    }

    public async Task<ErrorOr<List<BenefitResponseDto>>> Execute(GetBenefitsRequestDto getBenefitsRequestDto)
    {
        var validationResult = await _validation.ValidateAsync(getBenefitsRequestDto);

        if (!validationResult.IsValid)
            return validationResult.Errors.ToValidation();

        if (getBenefitsRequestDto.Status == BenefitStatus.Available)
            return await GetAvailableBenefits(getBenefitsRequestDto.ListType);

        return await GetRedeemedBenefits();
    }

    private async Task<List<BenefitResponseDto>> GetAvailableBenefits(BenefitListType? listType)
    {
        var marketplaceOptions = await _tenantService.GetMarketplaceOptions();

        var resultFromMarketplace =
            await _vertemMarketplaceExternalService.GetProductsByShowCase<ShowCaseProductDto>(
                GetShowCaseIdByListType(listType!.Value, marketplaceOptions),
                _tokenAccessor.AccessToken,
                marketplaceOptions.CampaignId);

        var availableProducts = await GetAvailableProductsAndAppendPrice(resultFromMarketplace.Products);

        var productsToFilter = new List<string>(availableProducts.Select(x => x.Sku));

        return availableProducts.GroupBy(product =>
                new { product.Subcategory.Category.Id, product.Subcategory.Category.Name })
            .Select(x => new BenefitResponseDto
            {
                CategoryId = x.Key.Id.ToString(),
                CategoryName = x.Key.Name,
                Benefits = x
                    .Where(showCaseProduct => productsToFilter.Contains(showCaseProduct.Sku))
                    .Select(product => new BenefitDto
                    {
                        Id = product.Sku,
                        Cost = product.Price,
                        Name = product.Name,
                        Description = product.Description,
                        Image = GetProductImageUrlFromSku(product.Sku, "card"),
                        DetailImage = GetProductImageUrlFromSku(product.Sku, "detail"),
                        BannerImage = GetProductImageUrlFromSku(product.Sku, "banner"),
                        Vendor = new BenefitVendorDto
                        {
                            Id = product.Vendor.Id,
                            Name = product.Vendor.Name
                        }
                    }).ToList()
            }).ToList();
    }

    private async Task<List<BenefitResponseDto>> GetRedeemedBenefits()
    {
        var accomplishedBenefits =
            await _accomplishedBenefitsRepository.GetByDigitalAccount(_authenticatedUser.GetDigitalAccountId().Value);

        if (accomplishedBenefits == null || !accomplishedBenefits.Any())
            return new List<BenefitResponseDto>();

        return accomplishedBenefits.GroupBy(accomplishedBenefit =>
                new
                {
                    accomplishedBenefit.Product?.CategoryId,
                    accomplishedBenefit.Product?.CategoryName
                })
            .Select(x => new BenefitResponseDto
            {
                CategoryId = x.Key.CategoryId,
                CategoryName = x.Key.CategoryName,
                Benefits = x
                    .Select(accomplishedBenefit => new BenefitDto
                    {
                        Id = accomplishedBenefit.TransactionId,
                        Cost = accomplishedBenefit.Product.SellingPrice,
                        Name = accomplishedBenefit.Product.Name,
                        Description = MarketplaceProductHelper.GetFormattedDescriptionAsMarkdownWithFeatures(accomplishedBenefit.Description ?? accomplishedBenefit.Product.Name,
                            accomplishedBenefit.Features),
                        Image = GetProductImageUrlFromSku(accomplishedBenefit.Product.Sku, "card"),
                        DetailImage = GetProductImageUrlFromSku(accomplishedBenefit.Product.Sku, "detail"),
                        BannerImage = GetProductImageUrlFromSku(accomplishedBenefit.Product.Sku, "banner"),
                        Vendor = new BenefitVendorDto
                        {
                            Id = long.Parse(accomplishedBenefit.Product.VendorId),
                            Name = accomplishedBenefit.Product.VendorName
                        }
                    }).ToList()
            }).ToList();
    }

    private async Task<ConcurrentBag<ShowCaseProductDto>> GetAvailableProductsAndAppendPrice(
        IEnumerable<ShowCaseProductDto> benefits)
    {
        var availableProducts = new ConcurrentBag<ShowCaseProductDto>();

        await Parallel.ForEachAsync(benefits, async (product, cancellationToken) =>
        {
            if (cancellationToken.IsCancellationRequested)
                return;

            try
            {
                var productAvailabilityResultTask = _vertemMarketplaceExternalService.GetAvailabilityAndPriceBySku(
                    new ProductAvailabilityRequestDto
                    {
                        Sku = product.Sku,
                        OriginalId = product.OriginalId,
                        VendorId = product.Vendor.Id.ToString()
                    }, _tokenAccessor.AccessToken);

                var productDetailTask =
                    _vertemMarketplaceExternalService.GetProductDetail(product.Sku, _tokenAccessor.AccessToken);

                await Task.WhenAll(new List<Task>
                {
                    productAvailabilityResultTask,
                    productDetailTask
                });

                if (productAvailabilityResultTask.Result.Available)
                {
                    product.Price = productAvailabilityResultTask.Result.Price;
                    product.Available = true;
                    product.Availability = productAvailabilityResultTask.Result;
                    product.Name = productDetailTask.Result.Value.Name;
                    product.Description = MarketplaceProductHelper
                        .GetFormattedDescriptionAsMarkdownWithFeatures(productDetailTask.Result.Value.Description, FeatureProfile.Map(productDetailTask.Result.Value.Features));
                    availableProducts.Add(product);
                }
            }
            catch (Exception exception)
            {
                _logger.LogError(new ExceptionLog(exception));
            }
        });

        return availableProducts;
    }

    private string GetProductImageUrlFromSku(string skuId, string imageDestiny) => $"{_storageAccountOptions.ProductImageBaseUrlForBenefits}/{skuId}_{imageDestiny}.png";

    private static string GetShowCaseIdByListType(BenefitListType listType, MarketplaceOptions marketplaceOptions)
    {
        return listType switch
        {
            BenefitListType.All => marketplaceOptions.ShowCaseIdForAll,
            BenefitListType.Banner => marketplaceOptions.ShowCaseIdForBanners,
            BenefitListType.HomeSection => marketplaceOptions.ShowCaseIdForHomeSection,
            _ => throw new ArgumentException("Tipo de listagem de benefícios inválida", nameof(listType))
        };
    }
}
