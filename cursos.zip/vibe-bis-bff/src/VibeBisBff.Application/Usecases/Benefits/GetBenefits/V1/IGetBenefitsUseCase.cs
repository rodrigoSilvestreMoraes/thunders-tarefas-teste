﻿using ErrorOr;
using VibeBisBff.Dto.Benefit;

namespace VibeBisBff.Application.Usecases.Benefits.GetBenefits.V1;

public interface IGetBenefitsUseCase
{
    Task<ErrorOr<List<BenefitResponseDto>>> Execute(GetBenefitsRequestDto getBenefitsRequestDto);
}
