﻿using ErrorOr;
using Microsoft.Extensions.Options;
using VibeBisBff.Application.Extensions;
using VibeBisBff.CrossCutting.Options;
using VibeBisBff.Domain.Entities.Benefit;
using VibeBisBff.Domain.Repositories.MongoDb.Benefit;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.PartnerHub.Voucher;
using VibeBisBff.Infra.Auth;

namespace VibeBisBff.Application.Usecases.Benefits.GetVoucher;

public class GetVoucherUseCase : IGetVoucherUseCase
{
    private readonly IVoucherHubExternalService _voucherHubExternalService;
    private readonly AuthTokenAccessor _authTokenAccessor;
    private readonly IAccomplishedBenefitsRepository _accomplishedBenefitsRepository;
    private readonly VoucherOptions _voucherOptions;

    public GetVoucherUseCase(IVoucherHubExternalService voucherHubExternalService, AuthTokenAccessor authTokenAccessor,
        IAccomplishedBenefitsRepository accomplishedBenefitsRepository,
        IOptionsSnapshot<VoucherOptions> voucherOptions)
    {
        _voucherHubExternalService = voucherHubExternalService;
        _authTokenAccessor = authTokenAccessor;
        _accomplishedBenefitsRepository = accomplishedBenefitsRepository;
        _voucherOptions = voucherOptions.Value;
    }

    public async Task<ErrorOr<VoucherResponseDto>> Execute(string benefitId)
    {
        var benefit = await _accomplishedBenefitsRepository.GetById(benefitId);

        if (benefit is null)
            return Error.NotFound(description: "Beneficio resgatado não encontrado");

        var (voucherHubOrderId, skuId) = GetBenefitDetailsForVoucher(benefit);

        var voucherBenefit = await _voucherHubExternalService.GetVoucher(skuId,
            voucherHubOrderId, _authTokenAccessor.AccessToken);

        return voucherBenefit.ToVoucherResponse(benefit.RedeemedDate, _voucherOptions.ExpirationDays);
    }

    private static (string voucherHubOrderId, string skuId) GetBenefitDetailsForVoucher(
        AccomplishedBenefit accomplishedBenefit)
    {
        return accomplishedBenefit.IsFromEngagement
            ? (accomplishedBenefit.VoucherHubOrderId.ToString(), accomplishedBenefit.ProductId)
            : (accomplishedBenefit.Product.VendorOrderId, accomplishedBenefit.Product.ProductCode);
    }
}
