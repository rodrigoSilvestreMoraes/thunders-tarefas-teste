﻿using ErrorOr;
using VibeBisBff.Dto.Shop;

namespace VibeBisBff.Application.Usecases.Benefits.GetVoucher
{
    public interface IGetVoucherUseCase
    {
        Task<ErrorOr<VoucherResponseDto>> Execute(string benefitId);
    }
}
