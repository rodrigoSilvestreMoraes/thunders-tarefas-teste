﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;

namespace VibeBisBff.Application.Usecases.Benefits.ResendRedemptionOtpCode;

public interface IResendRedemptionOtpCodeUseCase
{
    Task<ErrorOr<OtpReturnDto>> Execute();
}
