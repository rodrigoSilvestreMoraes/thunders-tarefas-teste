﻿using Common.Core.Authentication.Models;
using Common.Core.Authentication.Providers;
using ErrorOr;
using VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Benefits.ResendRedemptionOtpCode;

public class ResendRedemptionOtpCodeUseCase : IResendRedemptionOtpCodeUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public ResendRedemptionOtpCodeUseCase(
        AuthenticationProvider authenticationProvider,
        IDigitalAccountExternalService digitalAccountExternalService,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService)
    {
        _authenticatedUser = authenticationProvider.GetAuthenticatedUser();
        _digitalAccountExternalService = digitalAccountExternalService;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
    }

    public async Task<ErrorOr<OtpReturnDto>> Execute()
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        return await _identityAccessManagementExternalService.SendCellphoneOtp(digitalAccount.GetCellphone(), digitalAccountId.Value);
    }
}
