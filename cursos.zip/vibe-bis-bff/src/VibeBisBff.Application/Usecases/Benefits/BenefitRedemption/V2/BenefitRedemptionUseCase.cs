﻿using Common.Core.Authentication.Models;
using ErrorOr;
using VibeBisBff.Application.Mappers.Benefits;
using VibeBisBff.Application.Usecases.Benefits.RedemptionConfirmation;
using VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;
using VibeBisBff.Dto.Benefit.BenefitRedemption;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.TenantConfigService;
using VibeBisBff.ExternalServices.Tradeback.AuthorizerV2.Dto;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.Infra.Cache;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Benefits.BenefitRedemption.V2;

public class BenefitRedemptionUseCase : IBenefitRedemptionUseCase
{
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IBenefitRedemptionConfirmationUseCase _benefitRedemptionConfirmationUseCase;
    private readonly AuthenticatedUser _authenticatedUser;
    private readonly IRedisService _redisService;
    private readonly ITenantService _tenantService;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private const long HOURS_IN_SECONDS = 3600;

    public BenefitRedemptionUseCase(IDigitalAccountExternalService digitalAccountExternalService,
        AuthenticatedUser authenticatedUser,
        IBenefitRedemptionConfirmationUseCase benefitRedemptionConfirmationUseCase,
        IRedisService redisService,
        ITenantService tenantService,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService)
    {
        _digitalAccountExternalService = digitalAccountExternalService;
        _authenticatedUser = authenticatedUser;
        _benefitRedemptionConfirmationUseCase = benefitRedemptionConfirmationUseCase;
        _redisService = redisService;
        _tenantService = tenantService;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
    }

    public async Task<ErrorOr<BenefitRedemptionResponseDto>> Execute(string vendorId, string id)
    {
        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        var benefitRequest = TradebackAuthorizerV2TransactionRequestProfile.MapToBenefitRequest(digitalAccount,
            vendorId, id);

        if (!await _tenantService.Has2Fa()) return await ConfirmBenefitRedemption(digitalAccountId.Value, benefitRequest);

        var sendOtpResult = await SendOtp(digitalAccountId.Value, digitalAccount.GetCellphone());

        if(sendOtpResult.IsError)
            return sendOtpResult.Errors;

        await _redisService.Set(sendOtpResult.Value.Otp!.OtpId, benefitRequest, HOURS_IN_SECONDS * 2);

        return sendOtpResult;
    }

    private async Task<ErrorOr<BenefitRedemptionResponseDto>> SendOtp(string digitalAccountId, string cellPhone)
    {
        var otp = await _identityAccessManagementExternalService.SendCellphoneOtp(cellPhone, digitalAccountId);

        return new BenefitRedemptionResponseDto
        {
            Has2Fa = true,
            Otp = new OtpReturnDto(otp.OtpId, otp.IsTooManyRequest)
        };
    }

    private async Task<ErrorOr<BenefitRedemptionResponseDto>> ConfirmBenefitRedemption(string digitalAccountId, AuthorizerV2TransactionRequestDto benefitRequest)
    {
        var voucherResponse = await _benefitRedemptionConfirmationUseCase.Execute(digitalAccountId, benefitRequest);

        if (voucherResponse.IsError)
            return voucherResponse.Errors;

        return new BenefitRedemptionResponseDto
        {
            Has2Fa = false,
            Voucher = new VoucherResponseDto(voucherResponse.Value)
        };
    }
}
