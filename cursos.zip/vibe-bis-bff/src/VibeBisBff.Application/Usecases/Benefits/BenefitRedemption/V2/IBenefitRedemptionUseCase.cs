﻿using VibeBisBff.Dto.Benefit.BenefitRedemption;
using ErrorOr;

namespace VibeBisBff.Application.Usecases.Benefits.BenefitRedemption.V2;

public interface IBenefitRedemptionUseCase
{
    Task<ErrorOr<BenefitRedemptionResponseDto>> Execute(string vendorId, string id);
}
