﻿using ErrorOr;
using VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;
using VibeBisBff.Dto.Benefit.BenefitRedemption;

namespace VibeBisBff.Application.Usecases.Benefits.BenefitRedemption.V1;

public interface IBenefitRedemptionUseCase
{
    Task<ErrorOr<OtpReturnDto>> Execute(BenefitRedemptionRequestDto benefitRedemptionRequestDto, string id, string accessToken);
}
