﻿using Common.Core.Authentication.Models;
using ErrorOr;

using VibeBisBff.CrossCuting.Dto.IdentityAccessManagement;
using VibeBisBff.CrossCuting.Dto.Participants.Request;

using VibeBisBff.Dto.Benefit.BenefitRedemption;
using VibeBisBff.ExternalServices.Vertem.DigitalAccount;
using VibeBisBff.ExternalServices.Vertem.IdentityAccessManagement;
using VibeBisBff.ExternalServices.Vertem.Marketplace;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Mapper;
using VibeBisBff.Infra.Extensions;

namespace VibeBisBff.Application.Usecases.Benefits.BenefitRedemption.V1;

public class BenefitRedemptionUseCase : IBenefitRedemptionUseCase
{
    private readonly IVertemMarketplaceExternalService _vertemMarketplaceExternalService;
    private readonly IDigitalAccountExternalService _digitalAccountExternalService;
    private readonly IIdentityAccessManagementExternalService _identityAccessManagementExternalService;
    private readonly AuthenticatedUser _authenticatedUser;

    public BenefitRedemptionUseCase(IVertemMarketplaceExternalService vertemMarketplaceExternalService,
        IDigitalAccountExternalService digitalAccountExternalService,
        IIdentityAccessManagementExternalService identityAccessManagementExternalService,
        AuthenticatedUser authenticatedUser)
    {
        _vertemMarketplaceExternalService = vertemMarketplaceExternalService;
        _digitalAccountExternalService = digitalAccountExternalService;
        _identityAccessManagementExternalService = identityAccessManagementExternalService;
        _authenticatedUser = authenticatedUser;
    }

    [Obsolete("Use V2.BenefitRedemptionUseCase.Execute() instead")]
    public async Task<ErrorOr<OtpReturnDto>> Execute(BenefitRedemptionRequestDto benefitRedemptionRequestDto,
        string id,
        string accessToken)
    {
        var cart = await _vertemMarketplaceExternalService.GetCartItems(accessToken);

        var deleteActions = cart.Items.Select(x => _vertemMarketplaceExternalService.DeleteCartItem(x.Sku, accessToken));

        await Task.WhenAll(deleteActions);

        var digitalAccountId = _authenticatedUser.GetDigitalAccountId();

        if (digitalAccountId.IsError) return digitalAccountId.Errors;

        var digitalAccount = await _digitalAccountExternalService.GetParticipantDetailsById(digitalAccountId.Value);

        await _vertemMarketplaceExternalService.AddCartItem(id, 1, digitalAccount.GetEmail(), accessToken);

        var participantAddress = digitalAccount.DigitalAccountAddresses.FirstOrDefault();
        var addressCart = new ParticipantAddressDto
        {
            City = participantAddress.City,
            Country = participantAddress.Country,
            Complement = participantAddress.Complement,
            District = participantAddress.District,
            Number = participantAddress.Number,
            PostalCode = participantAddress.PostalCode,
            Reference = participantAddress.Reference,
            State = participantAddress.State,
            Street = participantAddress.Street
        };

        var cartRequestAddressDto = CartAddAddressProfile.Map(digitalAccount, addressCart, _authenticatedUser.IsVibeTenant().Value);
        var addCartResponse = await _vertemMarketplaceExternalService.AddCartAddress(cartRequestAddressDto, accessToken);

        if (addCartResponse.IsError)
            return addCartResponse.Errors;

        return await _identityAccessManagementExternalService.SendCellphoneOtp(digitalAccount.GetCellphone(), digitalAccountId.Value);
    }
}
