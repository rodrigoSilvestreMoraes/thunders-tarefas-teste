﻿using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.PartnerHub.Voucher.Dto;

namespace VibeBisBff.Application.Extensions;

public static class VoucherDataDtoExtensions
{
    public static VoucherResponseDto ToVoucherResponse(this VoucherDataDto benefitVoucher, DateTime redeemedDate,
        int expirationDays)
    {
        var hasVoucherCode = !string.IsNullOrEmpty(benefitVoucher?.Data?.VoucherCode);

        return new VoucherResponseDto
        {
            HasVoucherCode = hasVoucherCode,
            VoucherCode = !hasVoucherCode ? "Código do cupom enviado por e-mail." : benefitVoucher.Data.VoucherCode,
            StartDate = redeemedDate,
            ExpirationDays = expirationDays
        };
    }
}
