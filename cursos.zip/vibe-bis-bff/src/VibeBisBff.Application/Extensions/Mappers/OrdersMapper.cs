﻿using VibeBisBff.CrossCuting.Dto.Participants.Request;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Domain.Entities.Shop;
using VibeBisBff.Dto.Shop;
using VibeBisBff.ExternalServices.Vertem.Marketplace.Dto;

namespace VibeBisBff.Application.Extensions.Mappers;

public static class OrdersMapper
{
    private static readonly int[] TrackingErrorStatus =
    {
        6
    };

    public static OrderDetailsDto MapToOrderDetails(Order order,
        ShippingTrackingResponseDto trackingResponseDto,
        OrderProduct orderProduct)
    {
        return new OrderDetailsDto
        {
            OrderId = order.ParentOrderId,
            Product = new OrderProductDetailsDto
            {
                Name = orderProduct.Name,
                DeliveryDate = trackingResponseDto?.DeliveryForecast,
                ImageUrl = orderProduct.ImageUrl,
                Cost = orderProduct.SellingPrice,
                TrackingEvents = trackingResponseDto?.Statuses?.OrderBy(x => x.Status).Select(status =>
                    new ProductTrackingEventDto
                    {
                        Date = status.When,
                        Message = status.Name,
                        IconType = GetIconTypeByTrackingStatus(status.Status, status.When)
                    }).ToList()
            },
            CoinsValue = order.TotalInPoints,
            PurchaseValue = orderProduct.GetProductCostWithMarkupApplied(order.Markup, order.TotalInPoints),
            ShippingCost = order.GetShippingCostWithMarkupApplied(),
            PurchaseTotalValue = order.FinalPriceInMonetaryValueWithTax,

            CardBrandImageUrl = order.OrderPayment.CardBrandImageUrl,
            CreditCardLastDigits = order.OrderPayment.CreditCardLastDigits,
            Installments = order.OrderPayment.Installments,
            InstallmentValue = order.OrderPayment.InstallmentValue,

            Address = new ParticipantAddressDto
            {
                Street = order.DeliveryAddress.AddressText,
                Number = int.TryParse(order.DeliveryAddress.Number, out var number) ? number : 0,
                Complement = order.DeliveryAddress.Complement,
                District = order.DeliveryAddress.District,
                City = order.DeliveryAddress.City,
                State = order.DeliveryAddress.State,
                PostalCode = order.DeliveryAddress.ZipCode,
                Reference = order.DeliveryAddress.Reference,
            }
        };
    }

    public static List<OrderDto> MapToOrders(this MarketplaceOrdersResponseDto marketplaceOrders)
    {
        return marketplaceOrders.Orders.SelectMany(parentOrder => parentOrder.VendorOrderModel.SelectMany(vendorOrder =>
            vendorOrder.Items.Select(item => new OrderDto
            {
                ProductSkuId = item.ProductSkuId,
                VendorOrderId = vendorOrder.VendorOrderId,
                Title = item.Name,
                Date = parentOrder.OrderDate,
                VendorId = vendorOrder.VendorId,
                Id = parentOrder.ParentOrderId,
                Status = vendorOrder.StatusGroupDescription,
                Image = item.ImageUrl
            }))).ToList();
    }
    private static TrackingIconType GetIconTypeByTrackingStatus(int trackingStatus, DateTime? statusDate)
    {
        if (TrackingErrorStatus.Contains(trackingStatus))
            return TrackingIconType.Error;

        if (statusDate is null || DateTime.UtcNow < statusDate.Value.ToUniversalTime())
            return TrackingIconType.Awaiting;

        return TrackingIconType.Success;
    }
}
