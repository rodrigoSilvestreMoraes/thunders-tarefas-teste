﻿using FluentValidation;
using VibeBisBff.Dto.ContactUs;

namespace VibeBisBff.Application.Validations.ContactUs
{
    public class ContactUsLoggedUserRequestDtoValidation : AbstractValidator<ContactUsLoggedUserRequestDto>
    {
        public ContactUsLoggedUserRequestDtoValidation()
        {
            RuleFor(x => x.Subject)
               .NotEmpty()
               .WithMessage("O campo assunto é obrigatório");

            RuleFor(x => x.Message)
               .NotEmpty()
               .WithMessage("O campo mensagem é obrigatório");

            RuleFor(x => x.File)
               .SetValidator(new ImageExtensionValidator());
        }
    }
}
