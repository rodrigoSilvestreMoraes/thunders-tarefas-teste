﻿using FluentValidation;
using VibeBisBff.Dto.ContactUs;

namespace VibeBisBff.Application.Validations.ContactUs
{
    public class ContactUsLoggedOutUserRequestDtoValidation : AbstractValidator<ContactUsLoggedOutUserRequestDto>
    {
        public ContactUsLoggedOutUserRequestDtoValidation()
        {
            RuleFor(x => x.Name)
                .NotEmpty()
                .WithMessage("O campo nome é obrigatório");

            RuleFor(x => x.CellPhone)
                .NotEmpty()
                .WithMessage("O campo celular é obrigatório");

            RuleFor(x => x.Email)
               .NotEmpty()
               .WithMessage("O campo e-mail é obrigatório")
               .EmailAddress()
               .WithMessage("O campo e-mail é inválido");

            RuleFor(x => x.Subject)
               .NotEmpty()
               .WithMessage("O campo assunto é obrigatório");

            RuleFor(x => x.Message)
               .NotEmpty()
               .WithMessage("O campo mensagem é obrigatório");
        }
    }
}
