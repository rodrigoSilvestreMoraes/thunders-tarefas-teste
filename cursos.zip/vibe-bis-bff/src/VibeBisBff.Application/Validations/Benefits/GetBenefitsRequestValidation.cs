﻿using FluentValidation;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Dto.Benefit;

namespace VibeBisBff.Application.Validations.Benefits;

public class GetBenefitsRequestValidation : AbstractValidator<GetBenefitsRequestDto>
{
    public GetBenefitsRequestValidation()
    {
        RuleFor(x => x.Status)
            .NotEmpty()
            .WithMessage("O status dos benefícios deve ser informado")
            .IsInEnum()
            .WithMessage("O status informado é inválido");

        RuleFor(x => x.ListType)
            .NotEmpty()
            .WithMessage("O tipo de listagem de benefícios deve ser informado")
            .IsInEnum()
            .WithMessage("O tipo de listagem de benefícios informada é inválida")
            .When(x => x.Status != BenefitStatus.Redeemed);
    }
}
