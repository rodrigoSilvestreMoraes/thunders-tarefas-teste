﻿using FluentValidation;
using Microsoft.AspNetCore.Http;

namespace VibeBisBff.Application.Validations
{
    public class ImageExtensionValidator : AbstractValidator<IFormFile>
    {
        public ImageExtensionValidator()
        {
            RuleFor(ff => ff.FileName)
                .Must(fn => fn.EndsWith(".jpeg") || fn.EndsWith(".jpg") || fn.EndsWith(".png"))
                .When(ff => ff != null)
                .WithMessage("O arquivo deve ser uma imagem com a extensão jpeg, jpg ou png");
        }
    }
}
