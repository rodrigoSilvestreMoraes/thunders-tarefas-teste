﻿using FluentValidation;
using VibeBisBff.CrossCuting.Dto.Quiz.Register;

namespace VibeBisBff.Application.Validations.Quiz;

public class QuizRegisterValidation : AbstractValidator<QuizRegisterAnswerRequest>
{
    public QuizRegisterValidation()
    {
        RuleFor(x => x.Id).NotEmpty().WithMessage("O Id do quiz é obrigatório");
        RuleFor(x => x.QuestId).NotEmpty().WithMessage("O QuestId da missão é obrigatório");

        RuleFor(x => x.Answers)
            .NotEmpty()
            .WithMessage("A lista de respostas não pode ser vazia.")
            .When(x => !x.Survey.Any());

        RuleFor(x => x.Survey)
            .NotEmpty()
            .WithMessage("A lista de respostas não pode ser vazia.")
            .When(x => !x.Answers.Any());
    }
}
