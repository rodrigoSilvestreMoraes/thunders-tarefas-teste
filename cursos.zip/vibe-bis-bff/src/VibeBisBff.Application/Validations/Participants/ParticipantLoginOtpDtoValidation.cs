﻿using FluentValidation;
using VibeBisBff.Dto.Participants.V2.Request;

namespace VibeBisBff.Application.Validations.Participants;

public class ParticipantLoginOtpDtoValidation : AbstractValidator<ParticipantLoginOtpDto>
{
    public ParticipantLoginOtpDtoValidation()
    {
        RuleFor(x => x.OtpId).NotNull().WithMessage("O ID do OTP deve ser informado");

        RuleFor(x => x.Code).NotNull().WithMessage("O código recebido deve ser informado");

        RuleFor(x => x.TenantConfigId).NotNull().WithMessage("O ID do tenant deve ser informado").When(x => x.AppType is null);

        RuleFor(x => x.AppType).NotNull().WithMessage("O tipo do app deve ser informado").When(x => x.TenantConfigId is null);
    }
}
