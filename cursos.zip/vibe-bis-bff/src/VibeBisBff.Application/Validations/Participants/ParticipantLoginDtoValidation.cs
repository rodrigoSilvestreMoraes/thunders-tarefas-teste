﻿using FluentValidation;
using VibeBisBff.Dto.Participants.V2.Request;

namespace VibeBisBff.Application.Validations.Participants;

public class ParticipantLoginDtoValidation : AbstractValidator<ParticipantLoginDto>
{
    public ParticipantLoginDtoValidation()
    {
        RuleFor(x => x.Username).NotNull().WithMessage("O documento deve ser informado");

        RuleFor(x => x.TenantConfigId).NotNull().WithMessage("O id do tenant deve ser informado").When(x => x.AppType is null);

        RuleFor(x => x.AppType).NotNull().WithMessage("O tipo do app deve ser informado").When(x => x.TenantConfigId is null);
    }
}
