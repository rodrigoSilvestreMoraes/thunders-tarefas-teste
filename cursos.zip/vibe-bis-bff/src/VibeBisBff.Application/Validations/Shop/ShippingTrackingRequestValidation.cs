﻿using FluentValidation;
using VibeBisBff.Dto.Shop;

namespace VibeBisBff.Application.Validations.Shop;

public class ShippingTrackingRequestValidation : AbstractValidator<ShippingTrackingRequestDto>
{
    public ShippingTrackingRequestValidation()
    {
        RuleFor(x => x.VendorId).NotEmpty().WithMessage("O ID do fornecedor é obrigatório");
        RuleFor(x => x.ProductCode).NotEmpty().WithMessage("O SKU do produto é obrigatório");
    }
}
