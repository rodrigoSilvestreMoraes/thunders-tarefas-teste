﻿using ErrorOr;
using FluentValidation;
using VibeBisBff.Application.Notification.Mappers;
using VibeBisBff.CrossCuting.Dto.Notification;
using VibeBisBff.CrossCutting.Enums;
using VibeBisBff.Domain.Entities.Notifications;
using VibeBisBff.Domain.Repositories.MongoDb.Notifications;
using VibeBisBff.ExternalServices.Vertem.Notification;
using VibeBisBff.ExternalServices.Vertem.Notification.Dto;

namespace VibeBisBff.Application.Notification.Usecases;

public class NotificationUseCase : INotificationUseCase
{
    private readonly IValidator<NotificationEmail> _validationEmail;
    private readonly IValidator<NotificationPush> _validationPush;
    private readonly IValidator<NotificationRequestDto> _validationRequest;

    private readonly INotificationExternalService _notificationExternalService;
    private readonly INotificationRepository _notificationRepository;

    public NotificationUseCase(
        INotificationRepository notificationRepository,
        INotificationExternalService notificationExternalService,
        IValidator<NotificationEmail> validationEmail,
        IValidator<NotificationPush> validationPush,
        IValidator<NotificationRequestDto> validatorRequest)
    {
        _notificationExternalService = notificationExternalService;
        _notificationRepository = notificationRepository;
        _validationEmail = validationEmail;
        _validationPush = validationPush;
        _validationRequest = validatorRequest;
    }

    /// <summary>
    /// Recebe uma solicitação de notificação, validaa os dado de entrada, cria na base de dados, envia para o Vertem Notification
    /// </summary>
    /// <param name="request"></param>
    /// <param name="notificationDestination"></param>
    /// <returns></returns>
    public async Task<ErrorOr<NotificationResponse>> SendNotification(NotificationRequestDto request,
        NotificationDestination notificationDestination)
    {
        var validationRequest = await _validationRequest.ValidateAsync(request);

        if (!validationRequest.IsValid)
            return validationRequest.Errors.ToValidation();

        return notificationDestination switch
        {
            NotificationEmail email => await SendEmail(request, email),
            NotificationPush push => await SendPush(request, push),
            _ => Error.Validation(code: "Tipo não reconhecido", "Tipo da mensagem não reconhecido")
        };
    }

    private async Task<ErrorOr<NotificationResponse>> SendEmail(NotificationRequestDto request,
        NotificationEmail notificationEmail)
    {
        var resultValidation = await _validationEmail.ValidateAsync(notificationEmail);

        if (!resultValidation.IsValid)
            return resultValidation.Errors.ToValidation();

        var notification = NotificationProfile.Map(request, notificationEmail);

        await _notificationRepository.Create(notification);

        var (success, errorMessage) = await _notificationExternalService.SendEmail(new SendEmailRequestDto
        {
            TemplateId = notificationEmail.TemplateId,
            Parameters = notificationEmail.MessageValues,
            Subject = notificationEmail.Subject,
            To = notificationEmail.To,
        }, appType: null, tenantConfigId: request.TenantConfigId);

        notification.Destination.Status =
            success ? NotificationDestinationSentStatus.Success : NotificationDestinationSentStatus.Error;

        notification.Destination.SetErrorMessage(errorMessage);

        await _notificationRepository.Update(notification);

        if (errorMessage != null)
            return Error.Failure("Erro ao enviar a notificação: " + errorMessage);

        return new NotificationResponse { Id = notification.Id };
    }

    private async Task<ErrorOr<NotificationResponse>> SendPush(NotificationRequestDto request,
        NotificationPush notificationPush)
    {
        var resultValidation = await _validationPush.ValidateAsync(notificationPush);

        if (!resultValidation.IsValid)
            return resultValidation.Errors.ToValidation();

        var notification = NotificationProfile.Map(request, notificationPush);

        notification.Destination = notificationPush;

        await _notificationRepository.Create(notification);

        var (success, errorMessage) = await _notificationExternalService.SendPushNotification(
            new SendPushNotificationRequestDto
            {
                TemplateId = notificationPush.TemplateId,
                Parameters = notificationPush.MessageValues,
                ImageUrl = request.ImageUrl,
                Title = notificationPush.Title,
                Token = notificationPush.Token
            }, appType: null, tenantConfigId: request.TenantConfigId);

        notification.Destination.Status =
            success ? NotificationDestinationSentStatus.Success : NotificationDestinationSentStatus.Error;

        notification.Destination.SetErrorMessage(errorMessage);

        if (errorMessage != null)
            return Error.Failure("Erro ao enviar a notificação: " + errorMessage);

        await _notificationRepository.Update(notification);

        return new NotificationResponse { Id = notification.Id };
    }
}
