﻿using VibeBisBff.CrossCuting.Dto.Notification;
using ErrorOr;
using VibeBisBff.Domain.Entities.Notifications;

namespace VibeBisBff.Application.Notification.Usecases;

public interface INotificationUseCase
{
    Task<ErrorOr<NotificationResponse>> SendNotification(NotificationRequestDto request, NotificationDestination notificationDestination);
}
