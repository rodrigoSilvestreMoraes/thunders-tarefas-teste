﻿using VibeBisBff.CrossCuting.Dto.Notification;
using DomainNotification = VibeBisBff.Domain.Entities.Notifications;

namespace VibeBisBff.Application.Notification.Mappers;

public static class NotificationProfile
{
    public static DomainNotification.Notification Map(NotificationRequestDto request, DomainNotification.NotificationDestination messageDestination)
    {
        var notification = new DomainNotification.Notification(
            digitalAccountId: request.DigitalAccountId,
            sourceEvent: request.SourceEvent,
            title: request.Title,

            correlationId: request.CorrelationId,
            tenantConfigId: request.TenantConfigId)
        {
            Destination = messageDestination,
            Description = request.Description,
            Image = request.ImageUrl
        };

        return notification;
    }
}
