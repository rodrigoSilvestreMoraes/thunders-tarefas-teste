﻿using FluentValidation;
using VibeBisBff.CrossCuting.Dto.Notification;

namespace VibeBisBff.Application.Notification.Validations;

public class NotificationRequestDtoValidation : AbstractValidator<NotificationRequestDto>
{
    public NotificationRequestDtoValidation()
    {
        RuleFor(x => x.DigitalAccountId).NotEmpty().WithMessage("O campo de DigitalAccountId é obrigatório.");
        RuleFor(x => x.SourceEvent).IsInEnum().WithMessage("O campo de SourceEvent é obrigatório.");
        RuleFor(x => x.Title).NotEmpty().WithMessage("O campo de Title é obrigatório.");
        RuleFor(x => x.CorrelationId).NotEmpty().WithMessage("O campo de CorrelationId é obrigatório.");
        RuleFor(x => x.TenantConfigId).NotEmpty().WithMessage("O campo de TenantConfigId é obrigatório.");
    }
}
