﻿using FluentValidation;
using VibeBisBff.Domain.Entities.Notifications;

namespace VibeBisBff.Application.Notification.Validations;

public class NotificationPushValidation : AbstractValidator<NotificationPush>
{
    public NotificationPushValidation()
    {
        RuleFor(x => x.MessageValues).NotEmpty().WithMessage("O campo de MessageValues é obrigatório.");
        RuleFor(x => x.Title).NotEmpty().WithMessage("O campo de Title é obrigatório.");
        RuleFor(x => x.TemplateId).NotEmpty().WithMessage("O campo de TemplatId é obrigatório.");
        RuleFor(x => x.Token).NotEmpty().WithMessage("O campo de Token é obrigatório.");
        RuleFor(x => x.Type).IsInEnum().WithMessage("O campo de Type é obrigatório.");
        RuleFor(x => x.Status).IsInEnum().WithMessage("O campo de Status é obrigatório.");
    }
}
